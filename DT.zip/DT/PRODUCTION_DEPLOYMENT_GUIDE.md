# Production Deployment Guide for HR Assistant

## Overview
This guide provides comprehensive instructions for deploying the HR Assistant service in a production environment with enterprise-grade features.

## Production Features Implemented

### 🔒 **Security**
- **API Key Authentication**: Multiple API keys support
- **JWT Token Support**: User-based authentication with role management
- **Input Sanitization**: Protection against injection attacks
- **HTTPS/TLS**: SSL certificate support
- **Security Headers**: HSTS, X-Frame-Options, CSP
- **Rate Limiting**: Token bucket algorithm with Redis backend

### ⚡ **Performance & Scalability**
- **Async/Await**: Full async support for high concurrency
- **Connection Pooling**: Database and Redis connection pools
- **Caching**: Multi-layer caching with Redis
- **Circuit Breakers**: Prevent cascade failures
- **Retry Logic**: Exponential backoff for external services
- **Load Balancing**: Nginx reverse proxy support
- **Horizontal Scaling**: Stateless architecture

### 📊 **Monitoring & Observability**
- **Prometheus Metrics**: Custom metrics and exporters
- **Grafana Dashboards**: Pre-configured visualizations
- **Distributed Tracing**: OpenTelemetry with Jaeger
- **Health Checks**: Liveness, readiness, and dependency checks
- **Structured Logging**: JSON formatted logs with correlation IDs
- **Request Tracking**: Unique request IDs for debugging

### 🔄 **Reliability**
- **Graceful Shutdown**: Proper cleanup of resources
- **Error Recovery**: Automatic retry with circuit breakers
- **Fallback Mechanisms**: Degraded mode operation
- **Data Persistence**: Redis AOF and PostgreSQL backups
- **Timeout Management**: Configurable timeouts for all operations

## Prerequisites

- Docker 20.10+
- Docker Compose 2.0+
- 8GB RAM minimum (16GB recommended)
- 20GB disk space
- SSL certificates for HTTPS

## Quick Start

### 1. Clone and Setup

```bash
# Clone repository
git clone <repository-url>
cd DT

# Copy environment template
cp backend/.env.production.template backend/.env.production

# Edit configuration
vim backend/.env.production
```

### 2. Configure Environment

Essential variables to configure:

```bash
# Security - MUST CHANGE
SECRET_KEY=<generate-strong-key>
JWT_SECRET=<generate-strong-key>
API_KEYS=["key1","key2","key3"]

# Database
POSTGRES_USER=hruser
POSTGRES_PASSWORD=<strong-password>

# Redis
REDIS_PASSWORD=<strong-password>

# LLM Provider
LLM_API_KEY=<your-openai-key>

# Translation
TRANSLATION_API_KEY=<your-deepl-key>
```

### 3. Deploy with Docker Compose

```bash
# Build and start all services
docker-compose -f docker-compose.production.yml up -d

# View logs
docker-compose -f docker-compose.production.yml logs -f hr_assistant

# Check health
curl http://localhost:8000/hr/v1/health
```

## Production Configuration

### Database Setup

Initialize database with pgvector:

```sql
-- Create vector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Create documents table
CREATE TABLE documents (
    id SERIAL PRIMARY KEY,
    doc_id VARCHAR(255) UNIQUE NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    page INTEGER DEFAULT 0,
    collection VARCHAR(100),
    language VARCHAR(10) DEFAULT 'en',
    embedding vector(1024),
    metadata JSONB,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Create index for vector similarity search
CREATE INDEX ON documents USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);

-- Create feedback table
CREATE TABLE hr_feedback (
    feedback_id UUID PRIMARY KEY,
    user_id VARCHAR(255),
    query TEXT,
    response_id VARCHAR(255),
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    feedback_text TEXT,
    was_helpful BOOLEAN,
    created_at TIMESTAMP DEFAULT NOW()
);
```

### SSL/TLS Configuration

1. Generate certificates:
```bash
# Self-signed for testing
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout nginx/ssl/private.key \
  -out nginx/ssl/certificate.crt
```

2. Configure Nginx:
```nginx
server {
    listen 443 ssl http2;
    server_name yourdomain.com;
    
    ssl_certificate /etc/nginx/ssl/certificate.crt;
    ssl_certificate_key /etc/nginx/ssl/private.key;
    
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    
    location / {
        proxy_pass http://hr_assistant:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### Monitoring Setup

#### Prometheus Configuration

```yaml
# monitoring/prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'hr-assistant'
    static_configs:
      - targets: ['hr_assistant:8000']
    metrics_path: '/metrics'
```

#### Grafana Dashboard

Import pre-configured dashboards:
1. Navigate to http://localhost:3000
2. Login (admin/changeme)
3. Import dashboard from `monitoring/grafana/dashboards/`

#### Alerts Configuration

```yaml
# monitoring/alerts.yml
groups:
  - name: hr_assistant
    rules:
      - alert: HighErrorRate
        expr: rate(hr_assistant_errors_total[5m]) > 0.1
        for: 5m
        annotations:
          summary: "High error rate detected"
          
      - alert: HighLatency
        expr: histogram_quantile(0.95, hr_assistant_query_duration_seconds) > 5
        for: 5m
        annotations:
          summary: "High query latency detected"
```

## API Usage

### Authentication

#### API Key
```bash
curl -H "X-API-Key: your-api-key" \
     https://api.yourdomain.com/hr/v1/query \
     -d '{"query": "How many days of paid leave?"}'
```

#### JWT Token
```bash
# Get token
TOKEN=$(curl -X POST https://api.yourdomain.com/auth/token \
  -d '{"username": "user", "password": "pass"}' | jq -r .access_token)

# Use token
curl -H "Authorization: Bearer $TOKEN" \
     https://api.yourdomain.com/hr/v1/query \
     -d '{"query": "What are the benefits?"}'
```

### Rate Limits

Default limits per API key:
- 60 requests per minute
- 1,000 requests per hour
- 10,000 requests per day

Response headers:
```
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 45
X-RateLimit-Reset: 1234567890
```

## Scaling Strategies

### Horizontal Scaling

```yaml
# docker-compose.production.yml
hr_assistant:
  deploy:
    replicas: 4
    update_config:
      parallelism: 2
      delay: 10s
    restart_policy:
      condition: on-failure
```

### Kubernetes Deployment

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: hr-assistant
spec:
  replicas: 3
  selector:
    matchLabels:
      app: hr-assistant
  template:
    metadata:
      labels:
        app: hr-assistant
    spec:
      containers:
      - name: hr-assistant
        image: hr-assistant:latest
        resources:
          requests:
            memory: "2Gi"
            cpu: "1"
          limits:
            memory: "4Gi"
            cpu: "2"
        readinessProbe:
          httpGet:
            path: /hr/v1/ready
            port: 8000
          initialDelaySeconds: 10
          periodSeconds: 5
        livenessProbe:
          httpGet:
            path: /hr/v1/health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
```

## Performance Tuning

### PostgreSQL Optimization

```sql
-- postgresql.conf
shared_buffers = 2GB
work_mem = 10MB
maintenance_work_mem = 512MB
effective_cache_size = 6GB
random_page_cost = 1.1

-- Vector search optimization
SET ivfflat.probes = 10;
```

### Redis Optimization

```conf
# redis.conf
maxmemory 2gb
maxmemory-policy allkeys-lru
save 900 1
save 300 10
save 60 10000
```

### Application Tuning

```python
# Gunicorn workers
workers = multiprocessing.cpu_count() * 2 + 1
worker_class = "uvicorn.workers.UvicornWorker"
worker_connections = 1000
keepalive = 5
```

## Backup and Recovery

### Database Backup

```bash
# Automated backup script
#!/bin/bash
BACKUP_DIR="/backups"
DATE=$(date +%Y%m%d_%H%M%S)

# PostgreSQL backup
docker exec hr_postgres pg_dump -U hruser hrdb | \
  gzip > $BACKUP_DIR/postgres_$DATE.sql.gz

# Redis backup
docker exec hr_redis redis-cli --rdb /data/dump.rdb
cp /var/lib/docker/volumes/redis_data/_data/dump.rdb \
   $BACKUP_DIR/redis_$DATE.rdb

# Keep last 7 days
find $BACKUP_DIR -mtime +7 -delete
```

### Recovery Procedure

```bash
# Restore PostgreSQL
gunzip < backup.sql.gz | docker exec -i hr_postgres psql -U hruser hrdb

# Restore Redis
docker cp redis_backup.rdb hr_redis:/data/dump.rdb
docker restart hr_redis
```

## Security Best Practices

### 1. **Secrets Management**
- Use environment variables for secrets
- Consider HashiCorp Vault or AWS Secrets Manager
- Rotate API keys regularly

### 2. **Network Security**
- Use private networks for internal services
- Implement firewall rules
- Enable SSL/TLS for all external connections

### 3. **Access Control**
- Implement RBAC for API access
- Use strong passwords
- Enable 2FA for admin accounts

### 4. **Monitoring**
- Set up intrusion detection
- Monitor for unusual patterns
- Regular security audits

## Troubleshooting

### Common Issues

#### High Memory Usage
```bash
# Check memory usage
docker stats hr_assistant

# Increase limits
docker update --memory="4g" hr_assistant
```

#### Slow Queries
```sql
-- Check slow queries
SELECT query, mean_exec_time, calls
FROM pg_stat_statements
ORDER BY mean_exec_time DESC
LIMIT 10;
```

#### Connection Issues
```bash
# Check connections
docker exec hr_postgres psql -U hruser -c "SELECT count(*) FROM pg_stat_activity;"

# Check Redis connections
docker exec hr_redis redis-cli info clients
```

### Debug Mode

Enable debug logging:
```bash
LOG_LEVEL=DEBUG
DEBUG=true
```

View detailed logs:
```bash
docker logs -f --tail 100 hr_assistant | jq '.'
```

## Maintenance

### Regular Tasks

- **Daily**: Check logs for errors
- **Weekly**: Review metrics and performance
- **Monthly**: Update dependencies
- **Quarterly**: Security audit

### Health Monitoring

```bash
# Health check script
#!/bin/bash
HEALTH=$(curl -s http://localhost:8000/hr/v1/health)
if [ $(echo $HEALTH | jq -r .status) != "healthy" ]; then
  echo "Service unhealthy: $HEALTH"
  # Send alert
fi
```

## Support

For production support:
- Check logs: `docker-compose logs hr_assistant`
- View metrics: http://localhost:3000 (Grafana)
- Trace requests: http://localhost:16686 (Jaeger)
- Database admin: http://localhost:5050 (PgAdmin)

## License

[Your License]

## Contact

[Your Contact Information]
