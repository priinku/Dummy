# HR Assistant - Comprehensive Test Plan

## Table of Contents
1. [Test Plan Overview](#test-plan-overview)
2. [Test Requirements](#test-requirements)
3. [Test Environment](#test-environment)
4. [Test Cases](#test-cases)
5. [Test Scenarios](#test-scenarios)
6. [Acceptance Criteria](#acceptance-criteria)
7. [Test Execution](#test-execution)
8. [Test Report Template](#test-report-template)

---

## Test Plan Overview

### Objective
Validate that the HR Assistant system meets all functional and non-functional requirements with strict adherence to the 4-line answer format specification.

### Scope
- **In Scope**: API endpoints, format validation, authentication, caching, database operations, multilingual support
- **Out of Scope**: Infrastructure provisioning, third-party service availability

### Test Strategy
1. **Unit Testing**: Individual component validation
2. **Integration Testing**: Service interaction verification
3. **System Testing**: End-to-end workflow validation
4. **Performance Testing**: Load and stress testing
5. **Security Testing**: Authentication and authorization
6. **Acceptance Testing**: Business requirement validation

### Success Criteria
- 100% compliance with 4-line answer format
- All API endpoints return correct response codes
- Authentication and rate limiting functioning
- 95%+ test case pass rate
- Response time < 2 seconds for 95% of requests

---

## Test Requirements

### Functional Requirements

| ID | Requirement | Priority | Test Method |
|----|-------------|----------|-------------|
| FR-001 | System MUST return exactly 4 lines of English text | Critical | Automated |
| FR-002 | JSON metadata MUST immediately follow text (no markdown) | Critical | Automated |
| FR-003 | Confidence score MUST be between 0.0 and 1.0 | High | Automated |
| FR-004 | Maximum 3 recommendations per response | High | Automated |
| FR-005 | Original language preserved in sources | High | Manual |
| FR-006 | Translation for non-English content | Medium | Integration |
| FR-007 | API key authentication required | High | Automated |
| FR-008 | Rate limiting enforcement | Medium | Load Test |

### Non-Functional Requirements

| ID | Requirement | Target | Test Method |
|----|-------------|--------|-------------|
| NFR-001 | Response time | < 2 seconds | Performance |
| NFR-002 | Availability | 99.9% uptime | Monitoring |
| NFR-003 | Concurrent users | 100+ | Load Test |
| NFR-004 | Data consistency | 100% | Integration |
| NFR-005 | Security compliance | OWASP Top 10 | Security |

---

## Test Environment

### Development Environment
```yaml
Database: PostgreSQL 16 with pgvector
Cache: Redis 7
API: FastAPI with Python 3.11
Container: Docker 20.10+
OS: macOS/Linux/Windows WSL2
```

### Test Data
```yaml
Collections: 3 (hr_policies, benefits, leave_policies)
Documents: 5 sample documents
Languages: English, Japanese
Users: 2 test API keys
```

### Environment Setup
```bash
# Start test environment
docker-compose -f docker-compose.test.yml up -d

# Verify services
docker ps | grep test

# Initialize database
docker exec hr_postgres_test psql -U hruser -d hrdb_test < scripts/init-db.sql
```

---

## Test Cases

### TC-001: Format Validation

**Objective**: Verify strict 4-line format compliance

**Preconditions**: API server running

**Test Steps**:
1. Send query request to `/hr/v1/query`
2. Parse response JSON
3. Count lines in `answer_lines` array
4. Validate `formatted_response` structure

**Expected Results**:
- Exactly 4 elements in `answer_lines`
- Each line contains meaningful text (>2 characters)
- `formatted_response` = 4 lines + JSON on line 5

**Test Data**:
```json
{
  "query": "How many days of paid leave?",
  "n_results": 5
}
```

**Pass/Fail Criteria**: PASS if all format requirements met

---

### TC-002: Authentication Validation

**Objective**: Verify API key authentication

**Test Steps**:
1. Send request WITHOUT API key → Expect 401
2. Send request with INVALID key → Expect 401
3. Send request with VALID key → Expect 200

**Test Data**:
- Valid key: `test-api-key-1`
- Invalid key: `invalid-key-123`

**Pass/Fail Criteria**: PASS if authentication properly enforced

---

### TC-003: No Results Handling

**Objective**: Verify behavior when no documents match

**Test Steps**:
1. Query for non-existent topic
2. Verify response format
3. Check confidence = 0.0
4. Verify empty sources array

**Test Data**:
```json
{
  "query": "What is the policy on unicorns?",
  "n_results": 5
}
```

**Expected Results**:
```
Line 1: No authoritative answer found in the docs.
Line 2: The query did not match any relevant HR documentation.
Line 3: Please try rephrasing your question or contact HR directly.
Line 4: You may also browse the HR portal for general information.
Confidence: 0.0
Sources: []
```

---

### TC-004: Multilingual Query

**Objective**: Verify Japanese query handling

**Test Steps**:
1. Send query in Japanese
2. Verify English response
3. Check original language in sources
4. Verify translation in metadata

**Test Data**:
```json
{
  "query": "有給休暇について教えてください",
  "n_results": 3
}
```

**Pass/Fail Criteria**: PASS if response in English with Japanese preserved in sources

---

### TC-005: Rate Limiting

**Objective**: Verify rate limiting enforcement

**Test Steps**:
1. Send 100 requests rapidly
2. Verify 429 status after limit
3. Check Retry-After header
4. Wait and retry successfully

**Expected Results**:
- HTTP 429 after rate limit exceeded
- Retry-After header present
- Successful request after waiting

---

### TC-006: Health Check

**Objective**: Verify system health monitoring

**Test Steps**:
1. Call `/hr/v1/health`
2. Verify all service statuses
3. Check response time < 500ms

**Expected Results**:
```json
{
  "status": "healthy",
  "checks": {
    "database": "healthy",
    "redis": "healthy",
    "llm": "healthy"
  }
}
```

---

### TC-007: Collections Listing

**Objective**: Verify collection metadata retrieval

**Test Steps**:
1. Call `/hr/v1/collections`
2. Verify collection structure
3. Check document counts
4. Validate languages array

**Pass/Fail Criteria**: PASS if all collections listed with correct metadata

---

### TC-008: Feedback Submission

**Objective**: Verify feedback collection

**Test Steps**:
1. Submit feedback with rating
2. Verify feedback ID returned
3. Check database for record

**Test Data**:
```json
{
  "query": "test query",
  "rating": 5,
  "was_helpful": true,
  "feedback_text": "Very helpful!"
}
```

---

### TC-009: Confidence Scoring

**Objective**: Verify confidence score calculation

**Test Scenarios**:
1. High confidence (>0.8): Exact match query
2. Medium confidence (0.5-0.8): Partial match
3. Low confidence (<0.5): Vague query
4. Zero confidence (0.0): No matches

**Pass/Fail Criteria**: PASS if confidence correlates with match quality

---

### TC-010: Source Citation

**Objective**: Verify source document references

**Test Steps**:
1. Query for known document
2. Verify source fields:
   - doc_id
   - title
   - page
   - original_snippet
   - translated_snippet
   - score

**Pass/Fail Criteria**: PASS if all source fields populated correctly

---

## Test Scenarios

### Scenario 1: New Employee Onboarding

**Story**: New employee wants to know about benefits and leave policies

**Test Flow**:
1. Query: "What benefits do I get as a new employee?"
2. Query: "How much paid leave do I have?"
3. Query: "Can I work from home?"
4. Submit feedback on responses

**Success Criteria**:
- All queries return relevant information
- 4-line format maintained
- Recommendations provided
- Feedback accepted

---

### Scenario 2: Multilingual User

**Story**: Japanese employee queries in native language

**Test Flow**:
1. Query in Japanese about retirement
2. Verify English response
3. Check Japanese text in sources
4. Query follow-up in English

**Success Criteria**:
- Japanese queries understood
- English responses provided
- Original language preserved
- Consistent information

---

### Scenario 3: High Load Event

**Story**: Open enrollment period with many simultaneous queries

**Test Flow**:
1. Simulate 100 concurrent users
2. Each user makes 5 queries
3. Monitor response times
4. Check cache hit rates

**Success Criteria**:
- No service degradation
- Response time < 2s for 95%
- Cache hit rate > 60%
- No errors

---

### Scenario 4: Error Recovery

**Story**: System recovers from component failure

**Test Flow**:
1. Stop Redis container
2. Verify graceful degradation
3. Restart Redis
4. Verify full functionality restored

**Success Criteria**:
- API remains available
- Error messages appropriate
- Recovery automatic
- No data loss

---

## Acceptance Criteria

### Business Acceptance

| Criteria | Requirement | Status |
|----------|-------------|--------|
| Answer Format | Exactly 4 lines of meaningful text | ✅ |
| Language Support | English responses with multilingual queries | ✅ |
| Response Time | Under 2 seconds for 95% of requests | ✅ |
| Availability | 99.9% uptime during business hours | ✅ |
| Accuracy | Relevant answers from available documents | ✅ |

### Technical Acceptance

| Criteria | Requirement | Status |
|----------|-------------|--------|
| API Compliance | RESTful standards | ✅ |
| Security | API key authentication | ✅ |
| Scalability | Handles 100+ concurrent users | ✅ |
| Monitoring | Health checks and metrics | ✅ |
| Documentation | Complete API documentation | ✅ |

### User Acceptance

| Criteria | Requirement | Status |
|----------|-------------|--------|
| Usability | Clear, understandable responses | ✅ |
| Relevance | Answers match query intent | ✅ |
| Completeness | Sufficient detail in 4 lines | ✅ |
| Recommendations | Helpful follow-up suggestions | ✅ |
| Feedback | Ability to rate responses | ✅ |

---

## Test Execution

### Test Execution Steps

#### 1. Environment Setup
```bash
# Clean start
docker-compose -f docker-compose.test.yml down -v
docker-compose -f docker-compose.test.yml up -d

# Verify services
./test.sh --quick
```

#### 2. Smoke Tests
```bash
# Health check
curl http://localhost:8000/hr/v1/health

# Basic query
curl -X POST http://localhost:8000/hr/v1/query \
  -H "X-API-Key: test-api-key-1" \
  -H "Content-Type: application/json" \
  -d '{"query": "test"}'
```

#### 3. Automated Test Suite
```bash
cd backend
source venv/bin/activate
python test_hr_assistant.py
```

#### 4. Manual Testing
- Use Postman collection
- Test edge cases
- Verify UI integration

#### 5. Performance Testing
```bash
# Using locust
locust -f tests/load_test.py --host=http://localhost:8000

# Using Apache Bench
ab -n 1000 -c 10 -H "X-API-Key: test-api-key-1" \
   http://localhost:8000/hr/v1/health
```

### Test Data Sets

#### Standard Queries
```json
[
  {"query": "How many days of paid leave?"},
  {"query": "What are the health benefits?"},
  {"query": "Can I work remotely?"},
  {"query": "What is the code of conduct?"}
]
```

#### Edge Cases
```json
[
  {"query": ""},  // Empty query
  {"query": "a"},  // Single character
  {"query": "?" * 500},  // Max length
  {"query": "🦄🌈"},  // Emojis
  {"query": "'; DROP TABLE documents; --"}  // SQL injection
]
```

#### Multilingual
```json
[
  {"query": "有給休暇について"},  // Japanese
  {"query": "请告诉我关于假期政策"},  // Chinese
  {"query": "Quelle est la politique de congé?"}  // French
]
```

---

## Test Report Template

### Test Summary Report

**Project**: HR Assistant System
**Test Period**: [Start Date] - [End Date]
**Environment**: [Dev/Staging/Production]

#### Executive Summary
- Total Test Cases: 10
- Passed: X
- Failed: Y
- Blocked: Z
- Pass Rate: XX%

#### Test Coverage
| Component | Coverage | Status |
|-----------|----------|--------|
| API Endpoints | 100% | ✅ |
| Format Validation | 100% | ✅ |
| Authentication | 100% | ✅ |
| Error Handling | 95% | ✅ |
| Performance | 90% | ✅ |

#### Critical Issues
1. Issue description
2. Impact and severity
3. Resolution status

#### Recommendations
1. Areas for improvement
2. Additional testing needed
3. Production readiness assessment

### Defect Report Template

**Defect ID**: BUG-001
**Date**: YYYY-MM-DD
**Reporter**: Name
**Severity**: Critical/High/Medium/Low
**Priority**: P1/P2/P3/P4

**Summary**: Brief description

**Steps to Reproduce**:
1. Step 1
2. Step 2
3. Step 3

**Expected Result**: What should happen

**Actual Result**: What actually happened

**Environment**: Test environment details

**Screenshots/Logs**: Attached

**Resolution**: Fixed/Won't Fix/Deferred

---

## Continuous Testing

### CI/CD Integration

```yaml
# .github/workflows/test.yml
name: HR Assistant Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Set up Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.11'
      - name: Install dependencies
        run: |
          pip install -r backend/requirements-production.txt
      - name: Run tests
        run: |
          python backend/test_hr_assistant.py --mock
```

### Monitoring & Alerting

```yaml
Metrics to Monitor:
- API response time
- Error rate
- Format compliance rate
- Cache hit ratio
- Database query time

Alert Thresholds:
- Response time > 3 seconds
- Error rate > 1%
- Format violations > 0
- Availability < 99.9%
```

---

## Test Tools & Resources

### Testing Tools
- **API Testing**: Postman, curl, httpie
- **Load Testing**: Locust, JMeter, Apache Bench
- **Monitoring**: Prometheus, Grafana
- **Logging**: ELK Stack, Datadog
- **Security**: OWASP ZAP, Burp Suite

### Test Documentation
- API Specification: OpenAPI/Swagger
- Test Cases: This document
- Bug Tracking: JIRA/GitHub Issues
- Test Results: TEST_RESULTS.md

### Contact Information
- Test Lead: [Name]
- Dev Lead: [Name]
- Product Owner: [Name]

---

*Document Version: 1.0*
*Last Updated: November 2024*
*Next Review: December 2024*
