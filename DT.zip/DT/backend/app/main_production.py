"""
Production FastAPI Application
Full-featured production application with all middleware and monitoring
"""

import logging
import sys
from contextlib import asynccontextmanager
from datetime import datetime

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
from prometheus_fastapi_instrumentator import Instrumentator
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.sdk.resources import Resource
import redis.asyncio as redis
import structlog

from core.hr_config import hr_settings, validate_settings
from api.hr_assistant_api import router as hr_router
from api.search_api import router as search_router
from middleware.auth_middleware import AuthMiddleware
from middleware.rate_limit_middleware import RateLimitMiddleware
from services.hr_assistant_production import get_hr_assistant

# Configure structured logging
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer() if hr_settings.LOG_JSON_FORMAT else structlog.dev.ConsoleRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger()

# Global Redis client
redis_client = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan manager
    Handles startup and shutdown
    """
    global redis_client
    
    # Startup
    try:
        logger.info("Starting HR Assistant Application", 
                   version=hr_settings.APP_VERSION,
                   environment=hr_settings.ENVIRONMENT)
        
        # Validate configuration
        validate_settings()
        logger.info("Configuration validated successfully")
        
        # Initialize Redis
        if hr_settings.CACHE_ENABLED:
            redis_client = redis.Redis(
                connection_pool=redis.ConnectionPool.from_url(
                    hr_settings.REDIS_URL,
                    password=hr_settings.REDIS_PASSWORD,
                    ssl=hr_settings.REDIS_SSL,
                    max_connections=hr_settings.REDIS_POOL_SIZE
                )
            )
            await redis_client.ping()
            logger.info("Redis connection established")
        
        # Initialize HR Assistant service
        hr_assistant = await get_hr_assistant()
        logger.info("HR Assistant service initialized")
        
        # Initialize OpenTelemetry tracing
        if hr_settings.TRACING_ENABLED:
            resource = Resource.create({
                "service.name": hr_settings.TRACING_SERVICE_NAME,
                "service.version": hr_settings.APP_VERSION,
                "deployment.environment": hr_settings.ENVIRONMENT
            })
            
            tracer_provider = TracerProvider(resource=resource)
            trace.set_tracer_provider(tracer_provider)
            
            otlp_exporter = OTLPSpanExporter(
                endpoint=hr_settings.TRACING_ENDPOINT,
                insecure=True
            )
            
            span_processor = BatchSpanProcessor(otlp_exporter)
            tracer_provider.add_span_processor(span_processor)
            
            logger.info("OpenTelemetry tracing initialized")
        
        logger.info("Application startup complete")
        
    except Exception as e:
        logger.error("Startup failed", error=str(e), exc_info=True)
        sys.exit(1)
    
    yield
    
    # Shutdown
    try:
        logger.info("Starting application shutdown")
        
        # Close HR Assistant
        await hr_assistant.close()
        
        # Close Redis
        if redis_client:
            await redis_client.close()
        
        logger.info("Application shutdown complete")
        
    except Exception as e:
        logger.error("Shutdown error", error=str(e))

# Create FastAPI application
app = FastAPI(
    title=hr_settings.APP_NAME,
    version=hr_settings.APP_VERSION,
    description="Production HR Assistant API with RAG capabilities",
    docs_url="/docs" if hr_settings.DEBUG else None,
    redoc_url="/redoc" if hr_settings.DEBUG else None,
    openapi_url="/openapi.json" if hr_settings.DEBUG else None,
    lifespan=lifespan
)

# Add middleware in correct order (outermost to innermost)

# Trusted Host middleware (security)
if hr_settings.ENVIRONMENT == "production":
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=["*.yourdomain.com", "localhost"]
    )

# CORS middleware
if hr_settings.ENABLE_CORS:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=hr_settings.ALLOWED_ORIGINS,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        allow_headers=["*"],
        expose_headers=["X-RateLimit-Limit", "X-RateLimit-Remaining", "X-RateLimit-Reset"]
    )

# GZip compression
app.add_middleware(GZipMiddleware, minimum_size=1000)

# Authentication middleware
app.add_middleware(AuthMiddleware)

# Rate limiting middleware
if hr_settings.RATE_LIMIT_ENABLED:
    @app.on_event("startup")
    async def setup_rate_limiting():
        rate_limit_middleware = RateLimitMiddleware(app, redis_client)
        app.add_middleware(lambda app: rate_limit_middleware)

# Prometheus metrics
if hr_settings.METRICS_ENABLED:
    instrumentator = Instrumentator(
        should_group_status_codes=True,
        should_group_untemplated=True,
        should_respect_env_var=False,
        should_instrument_requests_inprogress=True,
        excluded_handlers=[".*health.*", ".*metrics.*"],
        inprogress_name="hr_assistant_requests_inprogress",
        inprogress_labels=True
    )
    instrumentator.instrument(app).expose(app, endpoint="/metrics")

# OpenTelemetry instrumentation
if hr_settings.TRACING_ENABLED:
    FastAPIInstrumentor.instrument_app(app)

# Include routers
app.include_router(hr_router, prefix=hr_settings.API_PREFIX)
app.include_router(search_router, prefix=hr_settings.API_PREFIX)

# Root endpoint
@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": hr_settings.APP_NAME,
        "version": hr_settings.APP_VERSION,
        "environment": hr_settings.ENVIRONMENT,
        "status": "operational",
        "timestamp": datetime.utcnow().isoformat()
    }

# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler for unhandled errors"""
    logger.error("Unhandled exception", 
                error=str(exc),
                path=request.url.path,
                method=request.method,
                exc_info=True)
    
    # Don't expose internal errors in production
    if hr_settings.ENVIRONMENT == "production":
        return JSONResponse(
            status_code=500,
            content={
                "error": "Internal server error",
                "message": "An unexpected error occurred",
                "timestamp": datetime.utcnow().isoformat()
            }
        )
    else:
        return JSONResponse(
            status_code=500,
            content={
                "error": type(exc).__name__,
                "message": str(exc),
                "timestamp": datetime.utcnow().isoformat()
            }
        )

# Request ID middleware
@app.middleware("http")
async def add_request_id(request: Request, call_next):
    """Add unique request ID for tracing"""
    import uuid
    request_id = str(uuid.uuid4())
    
    # Add to request state
    request.state.request_id = request_id
    
    # Add to logging context
    structlog.contextvars.bind_contextvars(request_id=request_id)
    
    # Process request
    response = await call_next(request)
    
    # Add to response headers
    response.headers["X-Request-ID"] = request_id
    
    # Clear context
    structlog.contextvars.clear_contextvars()
    
    return response

# Request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log all requests and responses"""
    start_time = datetime.utcnow()
    
    # Log request
    logger.info("Request received",
               method=request.method,
               path=request.url.path,
               client=request.client.host if request.client else None)
    
    # Process request
    response = await call_next(request)
    
    # Calculate duration
    duration = (datetime.utcnow() - start_time).total_seconds()
    
    # Log response
    logger.info("Request completed",
               method=request.method,
               path=request.url.path,
               status_code=response.status_code,
               duration_seconds=duration)
    
    return response

if __name__ == "__main__":
    import uvicorn
    
    # Production server configuration
    uvicorn.run(
        "main_production:app",
        host="0.0.0.0",
        port=8000,
        workers=4,
        loop="uvloop",
        log_config={
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "default": {
                    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                },
                "json": {
                    "()": "pythonjsonlogger.jsonlogger.JsonFormatter",
                    "format": "%(asctime)s %(name)s %(levelname)s %(message)s"
                }
            },
            "handlers": {
                "default": {
                    "formatter": "json" if hr_settings.LOG_JSON_FORMAT else "default",
                    "class": "logging.StreamHandler",
                    "stream": "ext://sys.stdout"
                }
            },
            "root": {
                "level": hr_settings.LOG_LEVEL,
                "handlers": ["default"]
            }
        },
        access_log=True,
        use_colors=False,
        server_header=False,
        date_header=False,
        limit_concurrency=1000,
        timeout_keep_alive=5,
        ssl_keyfile=None,  # Add SSL in production
        ssl_certfile=None  # Add SSL in production
    )
