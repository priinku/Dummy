# HR Assistant Implementation

## Overview
This implementation provides a retrieval-augmented HR assistant that follows strict formatting rules to deliver precise, structured answers based on document retrieval with multilingual support.

## System Architecture

### Core Components

1. **HR Assistant Service** (`services/hr_assistant_service.py`)
   - Main orchestration service
   - Implements the complete RAG pipeline
   - Enforces strict formatting rules
   - Manages confidence scoring

2. **Translation Service** (`services/translation_service.py`)
   - Language detection (Japanese, Chinese, Korean, Arabic, Cyrillic)
   - Translation capabilities with caching
   - Preserves original language citations

3. **Models** (`models/hr_assistant_models.py`)
   - Pydantic models for request/response validation
   - Ensures exactly 4-line answers
   - Validates JSON metadata structure

4. **API Endpoints** (`api/search_api.py`)
   - `/hr/query` - Main query endpoint
   - `/hr/collections` - List available collections
   - `/hr/document` - Upload documents
   - `/hr/feedback` - Submit user feedback

## Format Compliance

### Strict Output Format
```
Line 1: Main answer to the question
Line 2: Supporting details or conditions
Line 3: Additional context or exceptions
Line 4: Final information or next steps
{"sources":[...],"recommendations":[...],"confidence":0.00}
```

### Key Requirements Met
✅ **Exactly 4 lines** of meaningful English text  
✅ **JSON metadata** immediately after (no markdown)  
✅ **Source preservation** in original language  
✅ **Translation** of non-English content for reasoning  
✅ **Confidence scoring** based on evidence (0.0-1.0)  
✅ **Recommendations** limited to 3 items  
✅ **Temperature 0.0** for deterministic responses  
✅ **Conflict handling** with reduced confidence  

## Pipeline Flow

1. **Retrieval Phase**
   - Query vectorization
   - Top-k passage retrieval from vector DB
   - Relevance scoring

2. **Processing Phase**
   - Language detection for each passage
   - Translation to English if needed
   - Original text preservation

3. **Generation Phase**
   - Context preparation from sources
   - LLM prompt with strict instructions
   - Temperature 0.0 generation

4. **Formatting Phase**
   - Extract 4-line answer
   - Calculate confidence score
   - Generate recommendations
   - Create JSON metadata

## Multilingual Support

### Language Detection
- Japanese (Hiragana, Katakana, Kanji)
- Chinese (CJK Ideographs)
- Korean (Hangul)
- Arabic
- Cyrillic

### Translation Handling
```python
# Original Japanese text preserved
"original_snippet": "有給休暇は年間15日"

# Translated for reasoning
"translated_snippet": "[Translated from ja] Paid leave is 15 days per year"
```

## Confidence Scoring

### High Confidence (0.8-1.0)
- Strong evidence from multiple sources
- Clear, unambiguous information
- Recent, authoritative documents

### Medium Confidence (0.5-0.8)
- Single source or older documents
- Some ambiguity in interpretation
- Partial answer to query

### Low Confidence (0.0-0.5)
- Conflicting sources
- No direct evidence
- Extrapolation required

## Error Handling

### No Results Found
```
No authoritative answer found in the docs.
The query did not match any relevant HR documentation.
Please try rephrasing your question or contact HR directly.
You may also browse the HR portal for general information.
{"sources":[],"recommendations":[...],"confidence":0.0}
```

### Conflicting Information
```
Multiple documents show different leave entitlements.
The most recent policy indicates 15 days for full-time.
Older documents may reflect previous policies.
Please verify with HR for your specific contract terms.
{"sources":[multiple],"recommendations":[...],"confidence":0.65}
```

## API Usage

### Query Request
```json
POST /hr/query
{
    "query": "How many days of paid leave?",
    "collection_name": "hr_policies",
    "n_results": 5,
    "language": "en"
}
```

### Response Format
```json
{
    "answer_lines": [
        "Line 1 of answer",
        "Line 2 of answer",
        "Line 3 of answer",
        "Line 4 of answer"
    ],
    "metadata": {
        "sources": [...],
        "recommendations": [...],
        "confidence": 0.85
    },
    "formatted_response": "Complete 4-line answer\n{JSON metadata}"
}
```

## Testing

Run the example script to see format compliance:
```bash
python app/examples/hr_assistant_example.py
```

## Integration Points

### Required Services
- Vector database (pgvector)
- LLM service (inference endpoint)
- Translation API (optional, for production)

### Environment Variables
```bash
TRANSLATION_API_KEY=your_api_key
LLM_ENDPOINT=http://localhost:8080
DB_CONNECTION_STRING=postgresql://...
```

## Production Considerations

1. **Caching**
   - Translation results cached
   - Frequent queries cached
   - Vector embeddings cached

2. **Performance**
   - Batch translation for efficiency
   - Parallel retrieval operations
   - Connection pooling for DB

3. **Monitoring**
   - Query latency tracking
   - Confidence score distribution
   - User feedback analysis

4. **Security**
   - API authentication
   - Rate limiting
   - Input sanitization
   - PII detection and masking

## Compliance Summary

This implementation strictly adheres to all specifications:
- ✅ Retrieval from vector DB
- ✅ Multilingual support with translation
- ✅ No hallucination (evidence-based only)
- ✅ Exactly 4-line English answers
- ✅ Strict JSON metadata format
- ✅ Original language preservation
- ✅ Confidence scoring
- ✅ Maximum 3 recommendations
- ✅ Temperature 0.0 (deterministic)
- ✅ Conflict handling
- ✅ Conservative approach
