# HR Assistant Testing Guide

## Quick Start Testing

### 1. **Mock Testing** (No services required)
Test the response format validation without starting any services:

```bash
cd backend
source test_venv/bin/activate  # Virtual environment we created
python test_hr_assistant.py --mock
```

✅ **Result**: Validates the 4-line answer format and JSON metadata structure.

### 2. **Quick Testing** (Minimal services)
Start minimal services and run tests:

```bash
./test.sh --quick
```

This will:
- Start PostgreSQL with pgvector
- Start Redis for caching  
- Start mock LLM service
- Run the test suite
- Clean up afterward

### 3. **Manual Testing with Curl**
If services are running, test individual endpoints:

```bash
# Health check
curl -X GET http://localhost:8000/hr/v1/health

# Query endpoint
curl -X POST http://localhost:8000/hr/v1/query \
  -H "X-API-Key: test-api-key-1" \
  -H "Content-Type: application/json" \
  -d '{"query": "How many days of paid leave?", "n_results": 5}'
```

### 4. **Full Production Stack Testing**
For complete production testing:

```bash
# 1. Set up environment
cp backend/.env.production.template backend/.env.production
# Edit .env.production with your API keys

# 2. Start full stack
docker-compose -f docker-compose.production.yml up -d

# 3. Wait for services to be ready
docker-compose -f docker-compose.production.yml ps

# 4. Run tests
python3 backend/test_hr_assistant.py
```

## Test Files Created

| File | Purpose |
|------|---------|
| `test_hr_assistant.py` | Main test suite with format validation |
| `test_curl.sh` | Manual curl commands for testing |
| `test.sh` | Automated test runner |
| `.env.test` | Test environment configuration |
| `docker-compose.test.yml` | Minimal test stack |

## Expected Response Format

The API strictly returns:
```
Line 1: Main answer to the question
Line 2: Supporting details or conditions
Line 3: Additional context or exceptions
Line 4: Final information or next steps
{"sources":[...],"recommendations":[...],"confidence":0.85}
```

## Test Coverage

✅ **Format Validation**
- Exactly 4 answer lines
- Valid JSON metadata
- Confidence score (0.0-1.0)
- Maximum 3 recommendations

✅ **API Endpoints**
- `/hr/v1/health` - Health check
- `/hr/v1/query` - Main query endpoint
- `/hr/v1/collections` - List collections
- `/hr/v1/feedback` - Submit feedback

✅ **Production Features**
- Authentication (API key)
- Rate limiting
- Error handling
- Multilingual support

## Troubleshooting

### Services won't start
```bash
# Check Docker status
docker ps
docker-compose -f docker-compose.test.yml logs

# Clean up and retry
./test.sh --clean
./test.sh --quick
```

### API won't start
```bash
# Check port availability
lsof -i :8000

# Check Python dependencies
source backend/test_venv/bin/activate
pip install -r backend/requirements-production.txt
```

### Tests fail
```bash
# Run with verbose output
LOG_LEVEL=DEBUG python3 backend/test_hr_assistant.py

# Check individual services
curl http://localhost:8000/hr/v1/health
docker exec hr_redis_test redis-cli ping
docker exec hr_postgres_test psql -U hruser -c "SELECT 1"
```

## Next Steps

1. **Add real LLM**: Replace mock LLM with actual OpenAI/Anthropic API
2. **Load test data**: Import actual HR documents into PostgreSQL
3. **Configure monitoring**: Access Grafana at http://localhost:3000
4. **Run load tests**: Use locust for performance testing
5. **Deploy to production**: Follow PRODUCTION_DEPLOYMENT_GUIDE.md
