# HR Assistant - Complete Deployment & Operations Guide

## Table of Contents
1. [System Overview](#system-overview)
2. [Prerequisites](#prerequisites)
3. [Installation Guide](#installation-guide)
4. [Running the Application](#running-the-application)
5. [Configuration](#configuration)
6. [API Documentation](#api-documentation)
7. [Troubleshooting](#troubleshooting)
8. [Maintenance](#maintenance)

---

## System Overview

The HR Assistant is a production-grade retrieval-augmented generation (RAG) system designed to provide precise, structured answers to HR-related queries.

### Key Features
- **Strict Format Compliance**: Exactly 4 lines of English text + JSON metadata
- **Multilingual Support**: Automatic translation with original language preservation
- **Vector Search**: PostgreSQL with pgvector for semantic search
- **Caching**: Redis for performance optimization
- **Security**: API key authentication, rate limiting, input sanitization
- **Monitoring**: Prometheus metrics, health checks, distributed tracing

### Architecture
```
┌─────────────┐     ┌──────────────┐     ┌───────────────┐
│   Client    │────▶│  API Gateway │────▶│  HR Assistant │
└─────────────┘     └──────────────┘     └───────────────┘
                            │                      │
                            ▼                      ▼
                    ┌──────────────┐      ┌───────────────┐
                    │    Redis     │      │  PostgreSQL   │
                    │    Cache     │      │  + pgvector   │
                    └──────────────┘      └───────────────┘
```

---

## Prerequisites

### System Requirements
- **OS**: Linux/macOS/Windows with WSL2
- **RAM**: Minimum 8GB (16GB recommended)
- **Disk**: 20GB free space
- **CPU**: 4+ cores recommended

### Software Requirements
- Docker Desktop 20.10+
- Docker Compose 2.0+
- Python 3.11+
- Git

### Required API Keys (for production)
- LLM Provider (OpenAI/Anthropic)
- Translation Service (DeepL/Google)

---

## Installation Guide

### 1. Clone Repository
```bash
git clone <repository-url>
cd DT
```

### 2. Set Up Environment

#### Development/Testing
```bash
# Copy test environment configuration
cp backend/.env.test backend/.env

# Create Python virtual environment
cd backend
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements-production.txt
cd ..
```

#### Production
```bash
# Copy and configure production environment
cp backend/.env.production.template backend/.env.production

# Edit with your actual values
vim backend/.env.production
```

### 3. Verify Installation
```bash
# Check Docker
docker --version
docker-compose --version

# Check Python
python --version

# Verify Docker is running
docker ps
```

---

## Running the Application

### Quick Start (Development)

#### Option 1: Test Mode (Minimal Setup)
```bash
# Start test database and cache
docker-compose -f docker-compose.test.yml up -d

# Run test API server
cd backend
source venv/bin/activate
python test_api_server.py
```

#### Option 2: Full Development Stack
```bash
# Start all services
docker-compose -f docker-compose.test.yml up -d

# Initialize database
docker exec hr_postgres_test psql -U hruser -d hrdb_test < scripts/init-db.sql

# Start API server
cd backend
source venv/bin/activate
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Production Deployment

#### 1. Configure Environment
```bash
# Set production environment variables
export ENVIRONMENT=production
export API_KEYS='["your-api-key-1","your-api-key-2"]'
export LLM_API_KEY="your-openai-key"
export TRANSLATION_API_KEY="your-deepl-key"
```

#### 2. Start Production Stack
```bash
# Build and start all services
docker-compose -f docker-compose.production.yml up -d

# Check status
docker-compose -f docker-compose.production.yml ps

# View logs
docker-compose -f docker-compose.production.yml logs -f hr_assistant
```

#### 3. Verify Deployment
```bash
# Health check
curl http://localhost:8000/hr/v1/health

# Test query
curl -X POST http://localhost:8000/hr/v1/query \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{"query": "How many days of paid leave?", "n_results": 5}'
```

### Docker Commands Reference

```bash
# Start services
docker-compose -f docker-compose.test.yml up -d

# Stop services
docker-compose -f docker-compose.test.yml down

# View logs
docker-compose -f docker-compose.test.yml logs -f [service-name]

# Restart service
docker-compose -f docker-compose.test.yml restart [service-name]

# Clean up (remove containers and volumes)
docker-compose -f docker-compose.test.yml down -v
```

---

## Configuration

### Environment Variables

#### Essential Settings
| Variable | Description | Example |
|----------|-------------|---------|
| `ENVIRONMENT` | Deployment environment | `production` |
| `API_KEYS` | List of valid API keys | `["key1","key2"]` |
| `DATABASE_URL` | PostgreSQL connection | `postgresql://...` |
| `REDIS_URL` | Redis connection | `redis://localhost:6379` |
| `LLM_API_KEY` | LLM provider API key | `sk-...` |

#### Performance Tuning
| Variable | Default | Description |
|----------|---------|-------------|
| `DATABASE_POOL_SIZE` | 20 | Database connection pool |
| `CACHE_TTL_SECONDS` | 3600 | Cache expiration time |
| `LLM_TIMEOUT_SECONDS` | 30 | LLM request timeout |
| `RATE_LIMIT_PER_MINUTE` | 60 | Rate limit per API key |

#### Feature Flags
| Variable | Default | Description |
|----------|---------|-------------|
| `FEATURE_MULTILINGUAL` | true | Enable translation |
| `FEATURE_FEEDBACK` | true | Enable feedback collection |
| `FEATURE_ANALYTICS` | true | Enable analytics logging |

### Database Configuration

#### Initialize Database
```sql
-- Connect to database
docker exec -it hr_postgres_test psql -U hruser -d hrdb_test

-- Create vector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Verify tables
\dt

-- Check document count
SELECT COUNT(*) FROM documents;
```

#### Add Custom Documents
```sql
INSERT INTO documents (doc_id, title, content, page, collection) VALUES
('CUSTOM-001', 'Your Title', 'Your content...', 1, 'hr_policies');
```

---

## API Documentation

### Base URL
- Development: `http://localhost:8000`
- Production: `https://api.yourdomain.com`

### Authentication
Include API key in header:
```
X-API-Key: your-api-key
```

### Endpoints

#### 1. Health Check
```http
GET /hr/v1/health
```

Response:
```json
{
  "status": "healthy",
  "checks": {
    "database": "healthy",
    "redis": "healthy",
    "llm": "healthy"
  }
}
```

#### 2. Query HR Assistant
```http
POST /hr/v1/query
Content-Type: application/json

{
  "query": "How many days of paid leave?",
  "collection_name": null,
  "n_results": 5
}
```

Response:
```json
{
  "answer_lines": [
    "Line 1 of answer",
    "Line 2 of answer",
    "Line 3 of answer",
    "Line 4 of answer"
  ],
  "metadata": {
    "sources": [...],
    "recommendations": [...],
    "confidence": 0.85
  },
  "formatted_response": "4 lines\n{json}"
}
```

#### 3. List Collections
```http
GET /hr/v1/collections
```

#### 4. Submit Feedback
```http
POST /hr/v1/feedback
Content-Type: application/json

{
  "query": "original query",
  "rating": 5,
  "was_helpful": true,
  "feedback_text": "Very helpful!"
}
```

### Response Format Specification

**STRICT REQUIREMENT**: Responses MUST follow this exact format:
```
Line 1: Main answer to the question
Line 2: Supporting details or conditions
Line 3: Additional context or exceptions
Line 4: Final information or next steps
{"sources":[...],"recommendations":[...],"confidence":0.00}
```

---

## Troubleshooting

### Common Issues

#### 1. Port Already in Use
```bash
# Find process using port
lsof -i :8000
lsof -i :5432

# Kill process
kill -9 [PID]

# Or use different ports in docker-compose.yml
```

#### 2. Database Connection Failed
```bash
# Check PostgreSQL status
docker ps | grep postgres

# Check logs
docker logs hr_postgres_test

# Test connection
docker exec hr_postgres_test psql -U hruser -d hrdb_test -c "SELECT 1;"
```

#### 3. Redis Connection Failed
```bash
# Check Redis status
docker exec hr_redis_test redis-cli ping

# Check logs
docker logs hr_redis_test
```

#### 4. API Not Responding
```bash
# Check API logs
docker logs hr_assistant

# Check port binding
netstat -an | grep 8000

# Test directly
curl http://localhost:8000/
```

### Debug Mode

Enable debug logging:
```bash
export LOG_LEVEL=DEBUG
export DEBUG=true

# Restart services
docker-compose -f docker-compose.test.yml restart
```

### Reset Everything
```bash
# Stop all services
docker-compose -f docker-compose.test.yml down -v

# Remove all containers
docker rm -f $(docker ps -aq)

# Clean Docker system
docker system prune -a

# Start fresh
docker-compose -f docker-compose.test.yml up -d
```

---

## Maintenance

### Daily Tasks
- Check logs for errors: `docker logs hr_assistant --since 24h`
- Monitor disk space: `df -h`
- Check service health: `curl http://localhost:8000/hr/v1/health`

### Weekly Tasks
- Review metrics in Grafana (if configured)
- Check database size: `docker exec hr_postgres_test psql -U hruser -c "\l+"`
- Update document embeddings if needed

### Monthly Tasks
- Update dependencies: `pip install --upgrade -r requirements-production.txt`
- Backup database: See backup section
- Review and rotate API keys

### Backup & Recovery

#### Database Backup
```bash
# Backup
docker exec hr_postgres_test pg_dump -U hruser hrdb_test | gzip > backup_$(date +%Y%m%d).sql.gz

# Restore
gunzip < backup_20240130.sql.gz | docker exec -i hr_postgres_test psql -U hruser hrdb_test
```

#### Redis Backup
```bash
# Save snapshot
docker exec hr_redis_test redis-cli BGSAVE

# Copy backup
docker cp hr_redis_test:/data/dump.rdb ./redis_backup_$(date +%Y%m%d).rdb
```

### Monitoring

#### Check Resource Usage
```bash
# Container stats
docker stats

# Database connections
docker exec hr_postgres_test psql -U hruser -c "SELECT count(*) FROM pg_stat_activity;"

# Redis memory
docker exec hr_redis_test redis-cli INFO memory
```

#### Access Monitoring Tools
- Prometheus: http://localhost:9090
- Grafana: http://localhost:3000
- Jaeger: http://localhost:16686

---

## Performance Optimization

### Database Tuning
```sql
-- Analyze query performance
EXPLAIN ANALYZE SELECT * FROM documents WHERE ...;

-- Update statistics
ANALYZE documents;

-- Reindex
REINDEX TABLE documents;
```

### Cache Optimization
```bash
# Monitor cache hit rate
docker exec hr_redis_test redis-cli INFO stats | grep keyspace_hits

# Adjust cache size
docker exec hr_redis_test redis-cli CONFIG SET maxmemory 2gb
```

### API Performance
- Enable connection pooling
- Increase worker threads
- Use async operations
- Implement request batching

---

## Security Checklist

- [ ] Change default passwords
- [ ] Rotate API keys regularly
- [ ] Enable SSL/TLS
- [ ] Configure firewall rules
- [ ] Implement rate limiting
- [ ] Enable audit logging
- [ ] Regular security updates
- [ ] Backup encryption

---

## Support & Resources

### Documentation
- API Specification: `/docs` (development only)
- Test Guide: `TESTING_GUIDE.md`
- Production Guide: `PRODUCTION_DEPLOYMENT_GUIDE.md`

### Logs Location
- Application: `backend/logs/`
- PostgreSQL: `docker logs hr_postgres_test`
- Redis: `docker logs hr_redis_test`
- Nginx: `docker logs hr_nginx`

### Getting Help
1. Check logs for error messages
2. Review troubleshooting section
3. Search existing issues
4. Contact support team

---

## Quick Command Reference

```bash
# Start everything
./test.sh --quick

# Run tests
python backend/test_hr_assistant.py

# Check health
curl http://localhost:8000/hr/v1/health

# Test query
curl -X POST http://localhost:8000/hr/v1/query \
  -H "X-API-Key: test-api-key-1" \
  -H "Content-Type: application/json" \
  -d '{"query": "What are the benefits?"}'

# View logs
docker-compose logs -f --tail=100

# Stop everything
docker-compose down
```

---

*Last Updated: November 2024*
*Version: 1.0.0*
