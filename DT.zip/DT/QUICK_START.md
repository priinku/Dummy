# HR Assistant - Quick Start Guide 🚀

Get the HR Assistant running in **5 minutes** with these simple steps!

---

## Option 1: Fastest Start (Mock Mode) ⚡

**No Docker needed! Just Python.**

```bash
# 1. Navigate to backend
cd backend

# 2. Create virtual environment
python3 -m venv test_venv
source test_venv/bin/activate  # Windows: test_venv\Scripts\activate

# 3. Install minimal dependencies
pip install aiohttp colorama fastapi uvicorn pydantic

# 4. Start mock API server
python test_api_server.py &

# 5. Test it!
curl -X POST http://localhost:8000/hr/v1/query \
  -H "X-API-Key: test-api-key-1" \
  -H "Content-Type: application/json" \
  -d '{"query": "How many days of paid leave?"}'
```

**That's it!** You should see a properly formatted 4-line response with JSON metadata.

---

## Option 2: Docker Quick Start 🐳

**Full test environment with database.**

```bash
# 1. Start services
docker-compose -f docker-compose.test.yml up -d

# 2. Wait 10 seconds for initialization
sleep 10

# 3. Test the system
cd backend
source test_venv/bin/activate
python test_hr_assistant.py

# 4. Make a query
curl -X POST http://localhost:8000/hr/v1/query \
  -H "X-API-Key: test-api-key-1" \
  -H "Content-Type: application/json" \
  -d '{"query": "What are the health benefits?"}'
```

---

## Option 3: One-Command Test 🎯

```bash
# Run everything with one command
./test.sh --quick
```

This script:
- ✅ Starts PostgreSQL + Redis
- ✅ Creates database tables
- ✅ Loads sample data
- ✅ Starts API server
- ✅ Runs test suite
- ✅ Shows results

---

## What You Get 📦

### API Endpoints Available

| Endpoint | Description | Try It |
|----------|-------------|--------|
| `GET /hr/v1/health` | Check system health | `curl http://localhost:8000/hr/v1/health` |
| `POST /hr/v1/query` | Ask HR questions | See examples below |
| `GET /hr/v1/collections` | List document collections | Requires API key |

### Sample Queries to Try

```bash
# 1. Leave policy
curl -X POST http://localhost:8000/hr/v1/query \
  -H "X-API-Key: test-api-key-1" \
  -H "Content-Type: application/json" \
  -d '{"query": "How many days of paid leave do I get?"}'

# 2. Benefits
curl -X POST http://localhost:8000/hr/v1/query \
  -H "X-API-Key: test-api-key-1" \
  -H "Content-Type: application/json" \
  -d '{"query": "What health insurance coverage do we have?"}'

# 3. Remote work
curl -X POST http://localhost:8000/hr/v1/query \
  -H "X-API-Key: test-api-key-1" \
  -H "Content-Type: application/json" \
  -d '{"query": "Can I work from home?"}'

# 4. Japanese query
curl -X POST http://localhost:8000/hr/v1/query \
  -H "X-API-Key: test-api-key-1" \
  -H "Content-Type: application/json" \
  -d '{"query": "有給休暇について教えてください"}'
```

### Expected Response Format

Every response follows this **exact format**:

```
Employees receive 15 days of paid annual leave after probation.
Leave accrual starts from day one at 1.25 days per month.
Unused leave can be carried forward up to 5 days.
Part-time employees receive prorated leave based on hours.
{"sources":[{"doc_id":"HR-POL-001","title":"Leave Policy 2024","page":3,"original_snippet":"Annual leave entitlement is 15 days","translated_snippet":"Annual leave entitlement is 15 days","score":0.92}],"recommendations":[{"title":"Check policy details","reason":"View complete documentation"},{"title":"Contact HR","reason":"Get personalized assistance"}],"confidence":0.85}
```

**Key Points:**
- ✅ Exactly 4 lines of text
- ✅ JSON metadata on line 5
- ✅ No markdown formatting
- ✅ Confidence score 0.0-1.0
- ✅ Maximum 3 recommendations

---

## Test Credentials 🔑

| Type | Value | Usage |
|------|-------|-------|
| API Key 1 | `test-api-key-1` | General testing |
| API Key 2 | `test-api-key-2` | Alternative key |
| Database | `hruser` / `testpass` | PostgreSQL access |
| Port (API) | `8000` | API server |
| Port (DB) | `5433` | PostgreSQL |
| Port (Redis) | `6379` | Redis cache |

---

## Verify Installation ✅

Run these commands to verify everything is working:

```bash
# Check Docker containers
docker ps | grep test

# Check API health
curl http://localhost:8000/hr/v1/health

# Check database
docker exec hr_postgres_test psql -U hruser -d hrdb_test -c "SELECT COUNT(*) FROM documents;"

# Check Redis
docker exec hr_redis_test redis-cli ping

# Run test suite
cd backend && python test_hr_assistant.py
```

Expected output:
```
✓ Health status: healthy
✓ 5 documents in database
✓ PONG from Redis
✓ All tests passed (6/6)
```

---

## Stop Everything 🛑

```bash
# Stop and remove all test containers
docker-compose -f docker-compose.test.yml down

# Stop mock API server
pkill -f test_api_server.py

# Clean up completely (including data)
docker-compose -f docker-compose.test.yml down -v
```

---

## Troubleshooting 🔧

### Port Already in Use
```bash
# Change ports in docker-compose.test.yml
# Or kill existing process
lsof -i :8000 && kill -9 <PID>
```

### Docker Not Running
```bash
# Start Docker Desktop or
sudo systemctl start docker
```

### Python Module Not Found
```bash
# Make sure virtual environment is activated
source backend/test_venv/bin/activate
pip install -r backend/requirements-production.txt
```

### Database Connection Failed
```bash
# Restart PostgreSQL container
docker-compose -f docker-compose.test.yml restart postgres-test
```

---

## Next Steps 📚

1. **Explore the API**: Check `/docs` endpoint (dev mode)
2. **Read the Guides**: 
   - `TEST_PLAN.md` - Comprehensive test scenarios
   - `REQUIREMENTS_SPECIFICATION.md` - Detailed requirements
   - `COMPLETE_DEPLOYMENT_GUIDE.md` - Full deployment instructions
3. **Deploy to Production**: Follow `PRODUCTION_DEPLOYMENT_GUIDE.md`
4. **Add Custom Data**: Load your own HR documents

---

## Support 💬

- **Logs**: `docker-compose logs -f [service-name]`
- **Health**: `http://localhost:8000/hr/v1/health`
- **Metrics**: Available on port 9090 (if enabled)

---

**Ready to go!** The system is now running and ready for testing. 🎉

*Need more details? Check the complete guides in the repository.*
