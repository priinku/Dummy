# HR Chatbot - Features Documentation

> **Version:** 2.0  
> **Last Updated:** December 12, 2025  
> **Purpose:** Complete guide for demo and onboarding

---

## Table of Contents

1. [System Overview](#system-overview)
2. [Getting Started](#getting-started)
3. [User Features](#user-features)
   - [Chat Interface](#chat-interface)
   - [Dual Language Support](#dual-language-support)
   - [Chat History](#chat-history)
   - [Chat Export](#chat-export)
   - [Message Feedback](#message-feedback)
4. [Admin Features](#admin-features)
   - [Document Management](#document-management)
   - [Analytics Dashboard](#analytics-dashboard)
   - [User Management](#user-management)
   - [Activity Logs](#activity-logs)
   - [Notifications](#notifications)
5. [Technical Architecture](#technical-architecture)
6. [Demo Script](#demo-script)
7. [Troubleshooting](#troubleshooting)

---

## System Overview

The HR Chatbot is an AI-powered enterprise application that allows employees to ask questions about HR policies, company documents, and get instant answers in **both English and Japanese**.

### Key Capabilities

| Feature | Description |
|---------|-------------|
| **AI-Powered Q&A** | Ask questions in natural language, get accurate answers |
| **Dual Language** | Responses in both English and Japanese |
| **Document Search** | AI searches through uploaded HR documents |
| **RAG Technology** | Retrieval-Augmented Generation for accurate answers |
| **Admin Dashboard** | Manage documents, view analytics, monitor usage |

### Technology Stack

- **Frontend:** React + TypeScript + Tailwind CSS
- **Backend:** Node.js + Koa + TypeScript
- **Database:** MySQL + Sequelize
- **AI/LLM:** Ollama (llama3.2)
- **Search:** Apache Solr
- **Queue:** BullMQ + Redis

---

## Getting Started

### Prerequisites

1. **Node.js** v18+
2. **MySQL** database running
3. **Redis** server running
4. **Solr** server running on port 8983
5. **Ollama** with llama3.2 model

### Starting the Application

```bash
# Terminal 1: Start Backend API
cd api
npm run dev
# Runs on http://localhost:9090

# Terminal 2: Start Frontend UI
cd ui-2
npm run dev
# Runs on http://localhost:7001 or 7002
```

### Default Login

- **Username:** `admin`
- **Password:** `admin123`

---

## User Features

### Chat Interface

The main chat interface allows users to interact with the AI assistant.

#### How to Use

1. **Open the application** in your browser
2. **Login** with your credentials
3. **Type your question** in the input box at the bottom
4. **Press Enter** or click **Send** to submit

#### Features

| Action | How To |
|--------|--------|
| **Send Message** | Type and press `Enter` or click Send button |
| **New Line** | Press `Shift + Enter` |
| **Stop Generation** | Click Stop button or press `Esc` |
| **New Chat** | Click ➕ button |
| **Clear Chat** | Click 🗑️ button |

#### Screenshot Reference
```
┌─────────────────────────────────────────────────────┐
│  💬 History  ➕ New  🗑️ Clear        ⬇️ Export     │
├─────────────────────────────────────────────────────┤
│                                                     │
│  👤 User: What is the leave policy?                │
│                                                     │
│  🤖 Bot:                                           │
│  ┌─────────────────────────────────────────────┐   │
│  │ English:                                     │   │
│  │ The annual leave policy allows...            │   │
│  │                                              │   │
│  │ Japanese:                                    │   │
│  │ 年次休暇制度では...                           │   │
│  └─────────────────────────────────────────────┘   │
│  [📋 Copy] [👍 Like] [👎 Dislike] [📤 Share]       │
│                                                     │
├─────────────────────────────────────────────────────┤
│  [Type your message...                    ] [Send]  │
└─────────────────────────────────────────────────────┘
```

---

### Dual Language Support

Every AI response is automatically provided in **both English and Japanese**.

#### How It Works

1. User asks a question (in any language)
2. AI detects the language
3. AI generates answer in English
4. Answer is automatically translated to Japanese
5. Both versions are displayed side-by-side

#### Display Format

```
┌─────────────────────┬─────────────────────┐
│      English        │      Japanese       │
├─────────────────────┼─────────────────────┤
│ The leave policy    │ 休暇制度では        │
│ allows employees    │ 従業員は年間20日の  │
│ 20 days annual...   │ 有給休暇を...       │
└─────────────────────┴─────────────────────┘
```

---

### Chat History

View and manage your previous conversations.

#### How to Use

1. Click the **💬 History** button (left side of toolbar)
2. Sidebar opens showing all past chats
3. Click any chat to load it
4. Click **🗑️** to delete a chat

#### Features

- **Persistent Storage:** Chats are saved to database
- **Quick Switch:** Click to switch between conversations
- **Delete:** Remove unwanted chats
- **New Chat:** Start fresh conversation

---

### Chat Export

Export your conversation for documentation or sharing.

#### How to Use

1. Click the **⬇️ Export** button in toolbar
2. Choose export format:
   - **TXT** - Plain text format
   - **Markdown** - Formatted markdown
   - **JSON** - Structured data
3. Click **Download** or **Copy to Clipboard**

#### Export Formats

**TXT Format:**
```
Chat Export - HR Chatbot
Generated: 12/12/2025, 12:00:00 AM

---

[User] 12:00:00 AM
What is the leave policy?

[Assistant] 12:00:05 AM
The annual leave policy allows...
```

**Markdown Format:**
```markdown
# Chat Export - HR Chatbot

## User
What is the leave policy?

## Assistant
The annual leave policy allows...
```

**JSON Format:**
```json
{
  "title": "HR Chatbot",
  "exportedAt": "2025-12-12T00:00:00.000Z",
  "messages": [
    {
      "role": "user",
      "content": "What is the leave policy?",
      "timestamp": "12:00:00 AM"
    }
  ]
}
```

---

### Message Feedback

Provide feedback on AI responses to improve quality.

#### How to Use

1. After receiving a response, click:
   - **👍 Like** - Response was helpful
   - **👎 Dislike** - Response needs improvement
2. Feedback is saved to database for analytics

#### Actions Available

| Button | Action |
|--------|--------|
| **📋 Copy** | Copy response to clipboard |
| **👍 Like** | Mark as helpful |
| **👎 Dislike** | Mark as unhelpful |
| **📤 Share** | Share response (copy link) |
| **↻ Edit** | Edit and resend your message |

---

## Admin Features

Access the Admin Dashboard by clicking **Admin Dashboard** in the navigation.

### Document Management

Upload and manage HR documents for the AI to search.

#### Uploading Documents

1. Go to **Admin Dashboard** → **Documents** tab
2. Click **Upload** button
3. Select files (PDF, DOC, DOCX, TXT, XLSX, CSV)
4. Choose category (optional)
5. Click **Start Upload**

#### Supported File Types

| Type | Extension | Max Size |
|------|-----------|----------|
| PDF | .pdf | 50MB |
| Word | .doc, .docx | 50MB |
| Text | .txt | 10MB |
| Excel | .xlsx, .csv | 20MB |

#### Document Processing Pipeline

```
📄 Upload → 📝 Extract Text → 🔍 Index in Solr → 🤖 Ready for RAG
```

1. **File Upload** - Document saved to server
2. **Content Extraction** - Text extracted from document
3. **Embedding & Indexing** - Content indexed in Solr
4. **RAG Integration** - Available for AI search

#### Managing Documents

| Action | How To |
|--------|--------|
| **Search** | Type in search box to filter |
| **Delete** | Click 🗑️ Delete button |

---

### Analytics Dashboard

View usage statistics and insights.

#### Metrics Available

| Metric | Description |
|--------|-------------|
| **Total Queries** | Number of questions asked |
| **Positive Feedback** | Percentage of liked responses |
| **Avg Response Time** | Average time to generate answer |
| **Documents Indexed** | Number of searchable documents |
| **Active Users** | Users who used the system |

#### Charts

- **Query Volume** - Daily/weekly query trends
- **Top Questions** - Most frequently asked questions
- **Top Documents** - Most referenced documents
- **Feedback Distribution** - Like vs Dislike ratio

---

### User Management

View and manage system users.

#### User Information

| Field | Description |
|-------|-------------|
| **Name** | User's display name |
| **Employee ID** | Unique identifier |
| **Department** | User's department |
| **Last Active** | Last login/activity time |
| **Queries** | Number of questions asked |

---

### Activity Logs

Monitor system activity and user actions.

#### Activity Types

| Type | Description |
|------|-------------|
| **Query submitted** | User asked a question |
| **Document uploaded** | Admin uploaded file |
| **Feedback given** | User liked/disliked response |
| **Chat created** | New conversation started |

---

### Notifications

Send announcements to all users.

#### How to Send

1. Go to **Admin Dashboard** → **Notifications** tab
2. Enter **Title** and **Message**
3. Click **Send to All Users**

---

## Technical Architecture

### System Components

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Browser   │────▶│  Frontend   │────▶│   Backend   │
│   (User)    │     │  (React)    │     │  (Node.js)  │
└─────────────┘     └─────────────┘     └──────┬──────┘
                                               │
                    ┌──────────────────────────┼──────────────────────────┐
                    │                          │                          │
                    ▼                          ▼                          ▼
             ┌─────────────┐           ┌─────────────┐           ┌─────────────┐
             │    MySQL    │           │    Solr     │           │   Ollama    │
             │  (Database) │           │  (Search)   │           │   (LLM)     │
             └─────────────┘           └─────────────┘           └─────────────┘
```

### API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/tasks/add` | POST | Create new chat/query |
| `/api/tasks` | GET | List all tasks |
| `/api/tasks/output` | GET | Get task responses |
| `/api/files/upload` | POST | Upload documents |
| `/api/files` | GET | List all files |
| `/api/files/:id` | DELETE | Delete a file |

### Data Flow for Query

```
1. User types question
2. Frontend sends POST /api/tasks/add
3. Backend creates task in MySQL
4. BullMQ job processes query:
   a. Search relevant docs in Solr (RAG)
   b. Send context + question to Ollama
   c. Ollama generates English answer
   d. Translate to Japanese
   e. Save output to MySQL
5. Frontend polls for response
6. Display dual-language answer
```

---

## Demo Script

Follow this script for a complete product demonstration.

### 1. Introduction (2 min)

"Welcome to the HR Chatbot demo. This AI-powered assistant helps employees get instant answers to HR questions in both English and Japanese."

### 2. User Chat Demo (5 min)

```
Step 1: Show login page, login as admin
Step 2: Point out the clean chat interface
Step 3: Ask: "What is the annual leave policy?"
Step 4: Show dual-language response
Step 5: Click 👍 to show feedback feature
Step 6: Click Copy to show clipboard function
```

### 3. Chat Features Demo (3 min)

```
Step 1: Click History button - show past chats
Step 2: Start new chat with ➕ button
Step 3: Ask: "How do I apply for remote work?"
Step 4: Click Export - show download options
Step 5: Download as Markdown
```

### 4. Admin Dashboard Demo (5 min)

```
Step 1: Navigate to Admin Dashboard
Step 2: Documents tab - show uploaded files
Step 3: Upload a new document (have sample PDF ready)
Step 4: Show processing pipeline
Step 5: Analytics tab - show metrics and charts
Step 6: Users tab - show user list
Step 7: Activity tab - show recent actions
```

### 5. Q&A (5 min)

Common questions:
- "What languages are supported?" → English and Japanese
- "How accurate is the AI?" → Uses RAG for document-grounded answers
- "Can we add more documents?" → Yes, admins can upload anytime
- "Is data secure?" → Yes, enterprise-grade security

---

## Troubleshooting

### Common Issues

#### Chat not responding

```
Cause: Backend server not running
Fix: 
  cd api
  npm run dev
```

#### "Internal Server Error"

```
Cause: Database or Redis connection issue
Fix:
  1. Check MySQL is running
  2. Check Redis is running
  3. Restart backend server
```

#### Documents not searchable

```
Cause: Solr not running or not indexed
Fix:
  1. Ensure Solr is running on port 8983
  2. Check document was processed (no errors in upload)
  3. Reindex if necessary
```

#### Slow responses

```
Cause: Ollama model loading or slow generation
Fix:
  1. Ensure Ollama is running
  2. Check GPU availability
  3. Consider smaller model for faster responses
```

### Logs Location

| Component | Log Location |
|-----------|--------------|
| Backend | Terminal running `npm run dev` |
| Frontend | Browser Console (F12) |
| Database | MySQL logs |
| Queue | Bull Board at http://localhost:9999 |

---

## File Structure

```
avi2/
├── api/                    # Backend API
│   ├── src/
│   │   ├── controllers/    # Request handlers
│   │   ├── services/       # Business logic
│   │   ├── workers/        # BullMQ job processors
│   │   └── main.ts         # Entry point
│   └── package.json
│
├── ui-2/                   # Frontend UI
│   ├── src/
│   │   ├── components/     # React components
│   │   │   ├── ChatInterface.tsx
│   │   │   ├── AdminDashboard.tsx
│   │   │   ├── AnalyticsDashboard.tsx
│   │   │   ├── ChatExport.tsx
│   │   │   └── ...
│   │   ├── api/            # API client functions
│   │   ├── context/        # React contexts
│   │   └── App.tsx         # Main app component
│   └── package.json
│
└── FEATURES_DOCUMENTATION.md  # This file
```

---

## New Features Summary (v2.0)

| Feature | File | Description |
|---------|------|-------------|
| **Toast Notifications** | `ToastContext.tsx` | Global notification system |
| **Chat Export** | `ChatExport.tsx` | Export chats to TXT/MD/JSON |
| **Analytics Dashboard** | `AnalyticsDashboard.tsx` | Usage statistics & charts |
| **Message Feedback** | `FeedbackComponents.tsx` | Like/Dislike with confirmation |
| **PDF Preview** | `PDFPreview.tsx` | Document preview modal |
| **Smooth Animations** | `index.css` | Fade, slide, bounce effects |
| **Dual Language** | `ChatInterface.tsx` | EN/JP side-by-side display |
| **Document Search** | `AdminDashboard.tsx` | Filter documents by name |

---

## Contact & Support

For technical issues or feature requests, contact the development team.

---

*Document generated for HR Chatbot v2.0*
