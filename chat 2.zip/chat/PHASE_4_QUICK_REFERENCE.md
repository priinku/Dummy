# Phase 4 Quick Reference Guide

## File Locations & Modifications

### New Services (Backend)

#### Language Detection & Classification
```
📄 api/src/service/queryClassificationService.ts

Functions:
  - detectLanguage(query: string): 'en' | 'ja'
  - classifyQuery(query: string): ClassificationResult
  - getCompanyKeywords(language: 'en' | 'ja'): string[]

Import:
  import { detectLanguage, classifyQuery } from '@/service/queryClassificationService';
```

#### Translation
```
📄 api/src/service/translationService.ts

Functions:
  - translateText(req: TranslationRequest): Promise<TranslationResult>
  - translateENtoJA(text: string): Promise<string>
  - translateJAtoEN(text: string): Promise<string>
  - batchTranslate(...): Promise<TranslationResult[]>

Import:
  import { translateENtoJA, translateJAtoEN } from '@/service/translationService';
```

### Core Controller Changes

#### Main Task Processing
```
📄 api/src/controller/genTask.ts → getAddMid()

Two-Path Logic:
  if (isCompanyQuery) {
    // Translate EN→JA, trigger RAG, get citations
  } else {
    // Direct LLM call, dual output only
  }

Uses Services:
  - detectLanguage()
  - classifyQuery()
  - translateENtoJA()
  - getUploadedFilesForContext() [existing]
```

### New Frontend Component

```
📄 ui-2/src/components/DualLanguageResponse.tsx

Props:
  - detectedLanguage: 'en' | 'ja'
  - primaryText: string
  - secondaryText: string
  - isRAGBased?: boolean
  - citations?: PageCitation[]
  - metadata?: {...}

Usage:
  <DualLanguageResponse
    detectedLanguage="en"
    primaryText="English answer..."
    secondaryText="日本語の答え..."
    isRAGBased={true}
    citations={[{filename: 'policy.pdf', page: 5}]}
  />
```

### Modified Files

```
📄 api/src/controller/file.ts → deleteFileById()
  Route: DELETE /api/files/:id
  Purpose: Delete single file by ID

📄 api/src/routes/file.ts
  Updated: Route ordering (specific → general)
  Added: DELETE /:id → deleteFileById

📄 ui-2/src/components/AdminDashboard.tsx
  Added: Delete button functionality
  Added: Duplicate detection modal
  Added: handleDeleteFile() function
```

---

## Key Imports

### Backend
```typescript
// Language & Classification
import { detectLanguage, classifyQuery } from '@/service/queryClassificationService';

// Translation
import { translateENtoJA, translateJAtoEN } from '@/service/translationService';

// File Model
import File from '@/mysql/model/file.model';
```

### Frontend
```typescript
// Dual Language Component
import { DualLanguageResponse } from '@/components/DualLanguageResponse';

// Lucide Icons (used in component)
import { Globe, Languages, Copy, FileText, Check } from 'lucide-react';
```

---

## API Endpoints

### Task Creation (Existing, Enhanced)
```
POST /api/tasks
Body: {
  type: 'CHAT',
  formData: {
    prompt: string
  }
}

Response metadata now includes:
  - processingPath: 'GENERAL' | 'COMPANY'
  - detectedLanguage: 'en' | 'ja'
  - ragTriggered: boolean
  - usedFiles: DocumentHistory[]
```

### File Management

#### List Files (Existing)
```
GET /api/files?pageNum=1&pageSize=100

Response:
  {
    data: DocumentHistory[]
  }
```

#### Delete File (New)
```
DELETE /api/files/:id

Parameters:
  id: number (file ID)

Response:
  {
    message: 'ファイルが正常に削除されました',
    id: number
  }

Side Effects:
  - Deleted from MySQL
  - Deleted from RAG (ChromaDB)
  - Deleted from Solr search index
```

---

## Console Log Patterns

### Recognize These Patterns

#### Language Detection
```
🔤 [Language Detection]
  - query: "..." (preview)
  - japaneseChars: N
  - totalChars: N
  - percentage: X%
```

#### Query Classification
```
📊 [Query Classification]
  - isCompanyQuery: boolean
  - language: 'en' | 'ja'
  - confidence: X%
  - detectedKeywords: [...]
  - reason: "..."
```

#### Translation
```
🌐 [Translation Service] Starting translation
  - sourceLang: 'en'
  - targetLang: 'ja'
  - textPreview: "..."

✅ [Translation] Success
  - sourceLang: 'en'
  - targetLang: 'ja'
  - translatedPreview: "..."
```

#### RAG Preparation
```
📚 [GenTask] Fetching uploaded documents...
📊 [Database] Query completed
✅ [GenTask] Documents retrieved successfully
🔗 [GenTask] RAG Context Prepared
```

#### File Operations
```
🗑️  [FileController] Deleting file by ID
📄 [FileController] File found
✅ [FileController] File deleted from MySQL
✅ [FileController] File deleted from RAG
🎉 [FileController] File deleted successfully
```

---

## Data Types

### ClassificationResult
```typescript
interface ClassificationResult {
  isCompanyQuery: boolean;
  language: 'en' | 'ja';
  confidence: number;           // 0-1
  detectedKeywords: string[];
  reason: string;
}
```

### TranslationRequest
```typescript
interface TranslationRequest {
  text: string;
  sourceLang: 'en' | 'ja';
  targetLang: 'en' | 'ja';
}
```

### TranslationResult
```typescript
interface TranslationResult {
  original: string;
  translated: string;
  sourceLang: 'en' | 'ja';
  targetLang: 'en' | 'ja';
  success: boolean;
  error?: string;
}
```

### DocumentHistory
```typescript
interface DocumentHistory {
  id: number;
  filename: string;
  size: number;
  mime_type: string;
  created_at: string;
  create_by: string;
  storage_key: string;
}
```

### PageCitation
```typescript
interface PageCitation {
  filename: string;
  page?: number;
  content?: string;
}
```

---

## Common Tasks

### Add a New Company Keyword

**For English:**
```typescript
// In queryClassificationService.ts
const COMPANY_KEYWORDS_EN = [
  // ... existing keywords ...
  'new_keyword',  // Add here
];
```

**For Japanese:**
```typescript
const COMPANY_KEYWORDS_JA = [
  // ... existing keywords ...
  '新しいキーワード',  // Add here (Japanese)
];
```

### Test Language Detection

```typescript
import { detectLanguage } from '@/service/queryClassificationService';

// Test English
console.log(detectLanguage('What is your name?'));  // 'en'

// Test Japanese
console.log(detectLanguage('あなたの名前は何ですか？'));  // 'ja'

// Test Mixed (mostly English)
console.log(detectLanguage('What about 休暇?'));  // Check percentage
```

### Test Query Classification

```typescript
import { classifyQuery } from '@/service/queryClassificationService';

const result = classifyQuery('What is the leave policy?');
console.log(result);
// {
//   isCompanyQuery: true,
//   language: 'en',
//   confidence: 0.35,
//   detectedKeywords: ['leave', 'policy'],
//   reason: 'Company query detected (keywords: leave, policy)'
// }
```

### Test Translation

```typescript
import { translateENtoJA } from '@/service/translationService';

const ja = await translateENtoJA('What is the leave policy?');
console.log(ja);  // "年間休暇ポリシーは何ですか？"
```

### Trigger Company Query Path

```
User Input: "What is the annual leave policy?"
Expected Flow:
  1. Language: 'en' ✓
  2. Classification: company (leave, policy keywords) ✓
  3. Translate to JA ✓
  4. Query RAG ✓
  5. Dual output ✓
```

### Delete a File

```typescript
// Frontend
const response = await fetch('/dev-api/api/files/5', {
  method: 'DELETE'
});

// Backend processes:
// 1. Delete from MySQL file table
// 2. Delete from RAG/ChromaDB
// 3. Delete from Solr index
// 4. Return confirmation
```

---

## Troubleshooting Checklist

### Language Not Detecting as Japanese
- [ ] Query has >20% Japanese characters?
- [ ] Check hiragana + katakana + kanji count
- [ ] See console: 🔤 [Language Detection] output

### Company Query Not Triggering RAG
- [ ] Is query classified as company? Check console
- [ ] Do keywords match? Check COMPANY_KEYWORDS lists
- [ ] Are documents uploaded? Check /api/files endpoint

### Translation Seems Wrong
- [ ] Is Ollama running? Check `http://localhost:11435`
- [ ] Is model loaded? `ollama list` to verify
- [ ] Check console for translation errors: ❌ [Translation]

### Delete Not Working
- [ ] Check DELETE endpoint exists: `DELETE /api/files/:id`
- [ ] Verify file ID is valid integer
- [ ] Check backend logs for errors
- [ ] Verify database permissions

### 2-Column UI Not Showing
- [ ] Check DualLanguageResponse component renders
- [ ] Check metadata in response includes both languages
- [ ] Verify Tailwind CSS loaded
- [ ] Check console for React errors

---

## Performance Tuning

### Optimize Language Detection
```typescript
// Current: Counts all Japanese characters
// If slow: Add early exit at >20% threshold
if (japanesePercentage > 0.2) return 'ja';
```

### Optimize Classification
```typescript
// Current: Checks all keywords
// If slow: Add word tokenization first
const words = query.split(/\s+/);
const matchingKeywords = KEYWORDS.filter(kw => 
  words.some(w => w.toLowerCase().includes(kw))
);
```

### Optimize Translation
```typescript
// Current: Waits for full response
// If slow: Check Ollama model is quantized
// Consider: Caching translations
const cacheKey = `${text}_${sourceLang}_${targetLang}`;
if (cache.has(cacheKey)) return cache.get(cacheKey);
```

---

## Deployment Checklist

Before going to production:

- [ ] All TypeScript files compile without errors
- [ ] No linting warnings
- [ ] All imports resolve correctly
- [ ] Database connection working
- [ ] Ollama API accessible on port 11435
- [ ] RAG backend responding
- [ ] Solr search index running
- [ ] Frontend and backend proxy configured
- [ ] Document upload working
- [ ] Document deletion working
- [ ] Duplicate detection working
- [ ] Console logs appearing correctly
- [ ] 2-column UI rendering properly
- [ ] Tested with both EN and JA queries
- [ ] Tested with company and general queries

---

## Monitoring in Production

### Key Metrics to Watch

```
✓ Language detection accuracy
✓ Query classification accuracy
✓ Translation quality
✓ RAG retrieval relevance
✓ Response time (target: 4-9 seconds)
✓ Error rate (target: <1%)
✓ Delete operation success rate (target: 100%)
```

### Alert Conditions

```
⚠️  Language detection always returns 'en'
⚠️  Translation timeouts increasing
⚠️  RAG retrieval returning 0 documents
⚠️  LLM response time > 10 seconds
⚠️  Delete operations failing
⚠️  Console errors appearing
```

---

## Quick Links

- Implementation Details: [PHASE_4_IMPLEMENTATION_COMPLETE.md](PHASE_4_IMPLEMENTATION_COMPLETE.md)
- Testing Guide: [PHASE_4_TESTING_GUIDE.md](PHASE_4_TESTING_GUIDE.md)
- Full Summary: [PHASE_4_SUMMARY.md](PHASE_4_SUMMARY.md)

