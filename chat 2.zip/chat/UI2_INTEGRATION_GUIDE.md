/**
 * UI-2 INTEGRATION GUIDE FOR QUESTION CLASSIFICATION & RAG TRIGGERING
 * 
 * This document explains how to integrate question classification with RAG
 * in the ui-2 React application with dual-language support.
 */

// ============================================================================
// SECTION 1: BACKEND FLOW (What happens on the API)
// ============================================================================

/*
Question Flow in Backend:

1. User sends message via /api/gen-task endpoint
   Body: {
     type: "CHAT",
     formData: {
       prompt: "What is the company vacation policy?",
       fieldSort: 1,
       taskId: "xyz123"
     }
   }

2. Backend receives and classifies the question
   - Checks keywords for internal/policy related terms
   - Returns confidence score (0-1)
   - Marks as isInternal: true/false

3. Classification Decision:
   IF isInternal = true AND files uploaded:
     - Trigger RAG service
     - Add file context to prompt
     - Get dual-language response (日本語 + English)
   ELSE:
     - Use standard LLM response
     - Still provide dual-language output

4. Response contains:
   {
     classification: { isInternal, confidence, keywords },
     answer_ja: "ご質問ありがとうございます。...",
     answer_en: "Thank you for your question. ...",
     usedFiles: [{ filename, content }]  // if internal
   }
*/

// ============================================================================
// SECTION 2: BACKEND CHANGES REQUIRED
// ============================================================================

/*
FILE: api/src/controller/genTask.ts (or similar task controller)

ADD THIS BEFORE sending to RAG/LLM:
-------

import { classifyQuestion } from '@/service/classificationService';

async function handleTaskGeneration(ctx: Context) {
  const { prompt, formData } = ctx.request.body;
  
  // 1. CLASSIFY THE QUESTION
  const classification = classifyQuestion(
    prompt,
    userCustomKeywords,  // from settings
    userThreshold        // from settings
  );
  
  console.log('Classification Result:', {
    isInternal: classification.isInternal,
    confidence: classification.confidence,
    keywords: classification.keywords
  });
  
  // 2. PREPARE CONTEXT
  let augmentedPrompt = prompt;
  let ragContext = null;
  
  if (classification.isInternal) {
    // Try to fetch relevant files
    const uploadedFiles = await getUploadedFilesByCategory(
      ['company_policy', 'internal_guide']
    );
    
    if (uploadedFiles.length > 0) {
      // TRIGGER RAG
      ragContext = {
        files: uploadedFiles,
        relevantContent: uploadedFiles
          .map(f => f.contentExtracted)
          .join('\n\n')
      };
      
      // Augment prompt with file context
      augmentedPrompt = `${prompt}
      
[Internal Context - Use the following company documents to answer]
${ragContext.relevantContent}`;
    }
  }
  
  // 3. SEND TO LLM/RAG
  const response = await sendToLLM(augmentedPrompt);
  
  // 4. FORMAT RESPONSE WITH DUAL LANGUAGES
  const dualLanguageResponse = {
    classification: {
      isInternal: classification.isInternal,
      confidence: classification.confidence,
      keywords: classification.keywords
    },
    answer: response.text,
    answer_ja: response.ja || await translateToJapanese(response.text),
    answer_en: response.en || response.text,
    usedInternalDocs: ragContext ? ragContext.files : null,
    metadata: {
      processedAt: new Date(),
      classification_confidence: classification.confidence
    }
  };
  
  ctx.body = dualLanguageResponse;
}

-------
*/

// ============================================================================
// SECTION 3: FRONTEND CHANGES FOR UI-2
// ============================================================================

/*
FILE: ui-2/src/components/ChatInterface.tsx

In your message sending function, add classification logging:

-------
import { classifyQuestion } from '@/api/admin';

async function handleSendMessage(message: string) {
  // 1. CLASSIFY BEFORE SENDING
  let questionClassification = {
    isInternal: false,
    confidence: 0,
    keywords: []
  };
  
  try {
    const result = await classifyQuestion(message);
    questionClassification = result;
    
    console.log('📊 Classification:', {
      type: questionClassification.isInternal ? '📁 INTERNAL' : '🌐 GENERAL',
      confidence: (questionClassification.confidence * 100).toFixed(1) + '%',
      keywords: questionClassification.keywords.join(', ') || 'none'
    });
  } catch (error) {
    console.warn('⚠️ Classification failed:', error);
  }
  
  // 2. SEND MESSAGE WITH CLASSIFICATION INFO
  const response = await addTask({
    type: 'CHAT',
    formData: {
      prompt: message,
      fieldSort: fieldSort,
      taskId: chatId,
      // Add classification info
      isInternal: questionClassification.isInternal,
      classificationConfidence: questionClassification.confidence,
      classificationKeywords: questionClassification.keywords
    }
  });
  
  // 3. HANDLE RESPONSE
  if (response && response.metadata) {
    // Response has dual language and classification info
    const { answer_ja, answer_en, classification, usedInternalDocs } = response.metadata;
    
    // Display based on user's language preference
    displayMessage(
      userLanguagePreference === 'ja' ? answer_ja : answer_en
    );
    
    // Show if internal docs were used
    if (usedInternalDocs && usedInternalDocs.length > 0) {
      showNotification('📚 Referenced internal documents:', 
        usedInternalDocs.map(f => f.originalName).join(', ')
      );
    }
  }
}

-------
*/

// ============================================================================
// SECTION 4: CLASSIFICATION KEYWORDS (DEFAULT)
// ============================================================================

/*
Default internal/policy keywords:
- policy, procedure, internal, company, compliance
- regulation, requirement, process, guideline, rule
- standard, protocol, code of conduct, handbook
- manual, employee, hr, human resource
- vacation, leave, holiday, remote, work from home
- salary, compensation, benefits, bonus
- training, onboarding, promotion, performance
- conduct, discipline, grievance, complaint
*/

// ============================================================================
// SECTION 5: DUAL LANGUAGE OUTPUT FORMAT
// ============================================================================

/*
Backend Response Format:

{
  "code": 200,
  "message": "Success",
  "result": {
    "taskId": "abc123",
    "content": "Multi-language response...",
    "metadata": {
      "classification": {
        "isInternal": true,
        "confidence": 0.75,
        "keywords": ["policy", "vacation"]
      },
      "answer_ja": "ご質問ありがとうございます。当社の休暇ポリシーについてお答えします。...",
      "answer_en": "Thank you for your question. Regarding our vacation policy, ...",
      "usedInternalDocs": [
        {
          "id": 1,
          "originalName": "HR_Policy_2024.pdf",
          "category": "company_policy"
        }
      ],
      "language": "dual",
      "processedAt": "2024-12-11T10:30:00Z"
    }
  }
}
*/

// ============================================================================
// SECTION 6: UI-2 NOTIFICATION WHEN INTERNAL DOCS ARE USED
// ============================================================================

/*
In ChatInterface.tsx or your message display component:

Add this visual indicator:

-------
{classification.isInternal && usedInternalDocs && usedInternalDocs.length > 0 && (
  <div className="bg-blue-500/20 border border-blue-500/50 rounded p-3 mb-3 text-sm">
    <div className="flex items-center gap-2">
      <span>📚</span>
      <span className="text-blue-200">
        Answered using {usedInternalDocs.length} internal document(s)
      </span>
    </div>
    <div className="text-xs text-blue-300 mt-1">
      {usedInternalDocs.map(doc => doc.originalName).join(', ')}
    </div>
  </div>
)}

-------
*/

// ============================================================================
// SECTION 7: CLASSIFICATION THRESHOLDS & SETTINGS
// ============================================================================

/*
Users can adjust via Admin Dashboard:

Threshold: 0.1 - 0.9
- 0.1: Very sensitive (classify almost everything as internal)
- 0.3: Sensitive (catch most internal queries)
- 0.5: Balanced (DEFAULT RECOMMENDED)
- 0.7: Strict (only very clear internal queries)
- 0.9: Very strict (almost nothing classified as internal)

Custom Keywords:
- Users can add domain-specific keywords
- Example: "PTO", "OKR", "sprint", "standup" for tech companies

File-Based Answers Toggle:
- ON: Use uploaded docs for internal questions
- OFF: Only use general knowledge even for internal questions
*/

// ============================================================================
// SECTION 8: ERROR HANDLING & FALLBACKS
// ============================================================================

/*
If classification fails:
- Log the error but continue
- Assume isInternal = false (safe default)
- Send question normally to LLM
- Still provide dual-language output

If RAG fails:
- Try to answer without file context
- Log the failure
- Return response with classification but empty usedInternalDocs

If LLM fails:
- Return error message in both languages
- Include classification info for debugging
*/

// ============================================================================
// SECTION 9: TESTING THE INTEGRATION
// ============================================================================

/*
Test Cases:

1. General Question:
   Input: "What is Python?"
   Expected:
   - isInternal: false
   - No files referenced
   - Standard LLM response

2. Internal Question (Policy):
   Input: "What is the company vacation policy?"
   Expected:
   - isInternal: true
   - confidence: ~0.67
   - Files referenced: HR_Policy.pdf
   - Dual-language response using file content

3. Mixed Question:
   Input: "How do I install Python and what is the company coding standard?"
   Expected:
   - isInternal: true (has "company", "standard")
   - confidence: ~0.5
   - Files referenced: Coding_Guidelines.pdf
   - Response with Python installation + company standards

4. Ambiguous Question:
   Input: "What is a procedure?"
   Expected:
   - May or may not be internal depending on threshold
   - Low confidence
   - No files if question too generic
*/

// ============================================================================
// SECTION 10: LOGGING & DEBUGGING
// ============================================================================

/*
Add to browser console logs:

Classification Log Example:
📊 Question Classification
├─ Type: 📁 INTERNAL
├─ Confidence: 75%
├─ Matched Keywords: policy, company
└─ Threshold: 0.5 ✓ Pass

RAG Trigger Log:
🧠 RAG Triggered
├─ Files Found: 2
├─ Total Content: 15KB
├─ Processing: ⏳ 2.3s
└─ Status: ✅ Success

Response Log:
📝 Dual Language Response
├─ Japanese: ✅ Generated
├─ English: ✅ Generated
├─ Classification: 📁 Internal
└─ Documents Used: HR_Policy.pdf, Benefits_Guide.pdf
*/

export default {};
