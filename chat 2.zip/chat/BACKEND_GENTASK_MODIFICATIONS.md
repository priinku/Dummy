/**
 * BACKEND GENASK CONTROLLER WITH CLASSIFICATION & RAG INTEGRATION
 * File: api/src/controller/genTask.ts (modifications)
 * 
 * This code shows the exact changes needed in your existing genTask controller
 * to integrate question classification and RAG triggering.
 */

// ============================================================================
// IMPORT ADDITIONS
// ============================================================================

/*
Add these imports at the top of your genTask.ts file:

import { 
  classifyQuestion, 
  advancedClassifyQuestion 
} from '@/service/classificationService';
import { queryKeyValue } from '@/utils/auth';  // for user settings
import { getUploadedFiles } from '@/service/fileService';  // NEW
import { translateText } from '@/utils/translation';  // NEW for dual language
*/

// ============================================================================
// NEW FUNCTION: Get Uploaded Files for RAG Context
// ============================================================================

/*
Add this helper function to your controller:

async function getUploadedFilesForContext(userId: number, categories?: string[]) {
  try {
    // Get files uploaded by user or shared with user
    const query = {
      uploadedBy: userId,
      category: categories || ['company_policy', 'internal_guide'],
      isProcessed: true
    };
    
    const files = await uploadedFileModel.findAll({
      where: query,
      attributes: ['id', 'filename', 'originalName', 'category', 'contentExtracted'],
      limit: 5  // Limit to 5 most recent/relevant files
    });
    
    return files;
  } catch (error) {
    console.error('Error fetching uploaded files:', error);
    return [];
  }
}
*/

// ============================================================================
// MODIFIED FUNCTION: getAddMid (Middleware that adds task)
// ============================================================================

/*
FIND THIS CODE (approximately line 50-100 in genTask.ts):

export const getAddMid = async (ctx: Context, next: () => Promise<void>) => {
  const { type, formData } = ctx.request.body;
  // ... validation code ...
  
  // Process the request...
  const result = await addTaskToDatabase(type, formData);
  ctx.state.result = result;
  
  await next();
};

REPLACE WITH:

export const getAddMid = async (ctx: Context, next: () => Promise<void>) => {
  const { type, formData } = ctx.request.body;
  const userId = ctx.state.user?.userId;
  
  // ... existing validation code ...
  
  if (type === 'CHAT' || type === 'FILEUPLOAD') {
    const prompt = formData.prompt || '';
    
    // ========== 1. CLASSIFY THE QUESTION ==========
    const userSession = ctx.state.user?.session;
    let userSettings = null;
    let customKeywords = undefined;
    let threshold = 0.5;  // default
    
    // Try to get user's custom classification settings
    try {
      const sessionData = await queryKeyValue(userSession);
      userSettings = sessionData?.classificationSettings;
      
      if (userSettings) {
        customKeywords = userSettings.internalKeywords?.split(',').map(k => k.trim());
        threshold = userSettings.classificationThreshold || 0.5;
      }
    } catch (error) {
      console.warn('Could not fetch user settings:', error);
    }
    
    // Classify the question
    const uploadedFilesExist = await checkIfUserHasUploadedFiles(userId);
    const classification = advancedClassifyQuestion(
      prompt,
      customKeywords,
      threshold,
      uploadedFilesExist
    );
    
    console.log('🔍 Question Classification:', {
      isInternal: classification.isInternal,
      confidence: (classification.confidence * 100).toFixed(1) + '%',
      keywords: classification.keywords.join(', ')
    });
    
    // Store classification in context for response
    ctx.state.classification = classification;
    
    // ========== 2. PREPARE RAG CONTEXT IF INTERNAL ==========
    let ragContext = null;
    let augmentedFormData = { ...formData };
    
    if (classification.isInternal && uploadedFilesExist) {
      try {
        // Fetch relevant uploaded files
        const uploadedFiles = await getUploadedFilesForContext(userId);
        
        if (uploadedFiles.length > 0) {
          ragContext = {
            files: uploadedFiles.map(f => ({
              id: f.id,
              filename: f.filename,
              originalName: f.originalName,
              category: f.category
            })),
            content: uploadedFiles
              .map(f => `--- File: ${f.originalName} ---\n${f.contentExtracted}`)
              .join('\n\n')
          };
          
          console.log('📚 RAG Context Prepared:', {
            files: ragContext.files.length,
            totalLength: ragContext.content.length
          });
          
          // Augment the prompt with file context
          augmentedFormData = {
            ...formData,
            prompt: `${prompt}\n\n[INTERNAL CONTEXT]\nRefer to the following company documents:\n${ragContext.content}`,
            usedFileIds: ragContext.files.map(f => f.id),
            isInternal: true,
            ragTriggered: true
          };
        }
      } catch (error) {
        console.error('Error preparing RAG context:', error);
        // Continue without RAG context
      }
    }
    
    // ========== 3. STORE IN DATABASE AND SEND METADATA ==========
    const result = await addTaskToDatabase(type, augmentedFormData);
    
    // Store for response middleware
    ctx.state.result = result;
    ctx.state.metadata = {
      classification: {
        isInternal: classification.isInternal,
        confidence: classification.confidence,
        keywords: classification.keywords,
        reason: classification.reason
      },
      ragContext: ragContext,
      usedFiles: ragContext ? ragContext.files : null
    };
  } else {
    // For non-chat types, process normally
    const result = await addTaskToDatabase(type, formData);
    ctx.state.result = result;
  }
  
  await next();
};
*/

// ============================================================================
// NEW FUNCTION: Enhance Response with Dual Language
// ============================================================================

/*
Add this response enhancement function:

export const enhancedResponseFormatter = async (ctx: Context, next: () => Promise<void>) => {
  await next();
  
  // If this is a chat response, add dual language
  if (ctx.state.metadata && ctx.state.metadata.classification) {
    const response = ctx.body;
    
    if (response && response.result && response.result.content) {
      try {
        // Generate Japanese version if response is in English
        const isEnglish = /[a-zA-Z]{10,}/.test(response.result.content);
        
        if (isEnglish) {
          // Call your translation service
          const japanese = await translateText(
            response.result.content,
            'en',
            'ja'
          );
          
          response.result.metadata = response.result.metadata || {};
          response.result.metadata.answer_en = response.result.content;
          response.result.metadata.answer_ja = japanese;
          response.result.metadata.language = 'dual';
        }
        
        // Add classification and RAG info
        response.result.metadata = response.result.metadata || {};
        response.result.metadata.classification = ctx.state.metadata.classification;
        response.result.metadata.usedInternalDocs = ctx.state.metadata.usedFiles;
        
      } catch (error) {
        console.error('Error enhancing response:', error);
        // Continue with response as-is
      }
    }
  }
};

// Register middleware in your router:
// router.post('/gen-task', getAddMid, enhancedResponseFormatter, IndexCon());
*/

// ============================================================================
// HELPER FUNCTION: Check if User Has Uploaded Files
// ============================================================================

/*
Add this helper function:

async function checkIfUserHasUploadedFiles(userId: number): Promise<boolean> {
  try {
    const count = await uploadedFileModel.count({
      where: {
        uploadedBy: userId,
        isProcessed: true
      }
    });
    return count > 0;
  } catch (error) {
    console.error('Error checking uploaded files:', error);
    return false;
  }
}
*/

// ============================================================================
// RESPONSE FORMAT EXAMPLE
// ============================================================================

/*
Complete response format with classification and dual language:

{
  "code": 200,
  "message": "Task created successfully",
  "result": {
    "taskId": "task_abc123def456",
    "taskOutputId": "output_xyz789",
    "content": "The company vacation policy allows 20 days of annual leave...",
    "status": "FINISHED",
    "metadata": {
      "classification": {
        "isInternal": true,
        "confidence": 0.75,
        "keywords": ["policy", "company", "vacation"],
        "reason": "Matched 3 internal/policy keywords: policy, company, vacation"
      },
      "answer_en": "The company vacation policy allows 20 days of annual leave...",
      "answer_ja": "当社の休暇ポリシーでは、年間20日の休暇が認められています...",
      "language": "dual",
      "ragTriggered": true,
      "usedInternalDocs": [
        {
          "id": 1,
          "filename": "1734000000-abc123def456-policy.pdf",
          "originalName": "HR_Policy_2024.pdf",
          "category": "company_policy"
        }
      ],
      "processedAt": "2024-12-11T10:30:00Z"
    }
  }
}
*/

// ============================================================================
// IMPLEMENTATION CHECKLIST FOR BACKEND
// ============================================================================

/*
Required Changes:
1. ☐ Import classificationService functions
2. ☐ Add getUploadedFilesForContext() function
3. ☐ Modify getAddMid() middleware to classify questions
4. ☐ Add RAG context preparation logic
5. ☐ Create enhancedResponseFormatter middleware
6. ☐ Add translation/dual-language support
7. ☐ Update router to use new middleware
8. ☐ Add proper logging for debugging
9. ☐ Test with sample questions
10. ☐ Verify dual-language output

Optional Enhancements:
- [ ] Cache classification results for repeated questions
- [ ] Store classification metrics for analytics
- [ ] Implement feedback loop for accuracy improvement
- [ ] Add language preference to user settings
- [ ] Create admin dashboard for classification metrics
*/

export default {};
