# RAG Pipeline Test Guide

## 📊 Database Location & Structure

### Where Documents Are Stored
- **Database**: MySQL
- **Table**: `file`
- **Columns**:
  - `id` (INT, PRIMARY KEY, AUTO INCREMENT)
  - `filename` (VARCHAR, file name)
  - `storage_key` (VARCHAR, storage path)
  - `mime_type` (VARCHAR, e.g., 'application/pdf')
  - `size` (INT, file size in bytes)
  - `create_by` (CHAR(64), username of uploader)
  - `created_at` (DATE, upload timestamp)
  - `update_by` (CHAR(64), last updater)
  - `updated_at` (DATE, last update timestamp)

### Document Upload Flow
```
User selects file
    ↓
[AdminDashboard UI Pipeline]
  ├─ Step 1: File Upload (uploads to server)
  ├─ Step 2: Content Extraction (parses file)
  ├─ Step 3: Embedding & Indexing (creates searchable index)
  └─ Step 4: RAG Integration (registers for RAG)
    ↓
File stored in: database → table: 'file' → columns: filename, storage_key, mime_type, size, create_by, created_at
    ↓
File now available for RAG queries
```

---

## 🧪 Test Steps

### Step 1: Create Test Document
Create a file with company policy information:

**File**: `test-hr-policy.txt`
```
COMPANY HUMAN RESOURCES POLICY - 2024

1. ANNUAL LEAVE POLICY
- Employees are entitled to 20 days of annual leave per calendar year
- Leave can be carried forward to the next year up to 5 days
- Leave requests must be submitted 2 weeks in advance
- Emergency leave requires manager approval within 24 hours

2. REMOTE WORK POLICY
- Remote work is available 2 days per week
- Must be scheduled in advance
- All meetings must be attended (video camera on)
- Work hours: 9 AM - 5 PM local time

3. MEDICAL BENEFITS
- Health insurance covers 100% of basic medical expenses
- Dental coverage up to $1000 per year
- Mental health counseling available 24/7
- Eye care covered up to $300 per year

4. TRAINING & DEVELOPMENT
- Each employee receives $2000 annual training budget
- Company covers 100% of job-related certifications
- Internal training workshops held monthly
- Online learning platforms available (LinkedIn, Coursera)

5. CODE OF CONDUCT
- Respect and professionalism required at all times
- Zero tolerance for harassment or discrimination
- Confidential information must be protected
- Company assets must be used responsibly
```

### Step 2: Upload Document via Admin Dashboard
1. Go to Admin Dashboard → Documents tab
2. Click "Upload Document"
3. Select `test-hr-policy.txt`
4. Choose category: "📋 Company Policy"
5. Click "Start Upload Pipeline"
6. Watch console logs for:
   - ✅ STEP 1: File Upload - COMPLETED
   - ✅ STEP 2: Content Extraction - COMPLETED
   - ✅ STEP 3: Embedding & Indexing - COMPLETED
   - ✅ STEP 4: RAG Integration - COMPLETED

### Step 3: Check Console Logs (Frontend)
Expected output in browser console:
```
📎 [AdminDashboard] File selected:
  {name: "test-hr-policy.txt", size: "0.05 MB", type: "text/plain"}

🚀 [AdminDashboard] Starting upload pipeline...
📋 [AdminDashboard] Upload details:
  {filename: "test-hr-policy.txt", size: "0.05 MB", category: "company_policy", timestamp: "2024-12-11T..."}

🔄 [AdminDashboard] STEP 1: File Upload - IN PROGRESS
✅ [AdminDashboard] STEP 1: File Upload - COMPLETED

🔄 [AdminDashboard] STEP 2: Content Extraction - IN PROGRESS
✅ [AdminDashboard] STEP 2: Content Extraction - COMPLETED

🔄 [AdminDashboard] STEP 3: Embedding & Indexing - IN PROGRESS
✅ [AdminDashboard] STEP 3: Embedding & Indexing - COMPLETED

🔄 [AdminDashboard] STEP 4: RAG Integration - IN PROGRESS
✅ [AdminDashboard] STEP 4: RAG Integration - COMPLETED

🎉 [AdminDashboard] Upload pipeline completed successfully!
📁 [AdminDashboard] File now stored in database: file table
🧠 [AdminDashboard] File is now ready for RAG queries
```

### Step 4: Verify Document in Database
Check the MySQL database:
```sql
SELECT id, filename, size, create_by, created_at FROM file 
WHERE filename LIKE '%test-hr-policy%' 
ORDER BY created_at DESC 
LIMIT 1;
```

Expected result:
```
id | filename           | size   | create_by | created_at
---|-------------------|--------|-----------|--------------------
45 | test-hr-policy.txt | 1847   | admin     | 2024-12-11 10:30:00
```

### Step 5: Ask Question About Policy (Chat)
In ChatInterface, ask about the company policy:

**Question**: "What is the annual leave policy?"

Expected console output (Backend):
```
================================================================================
🚀 [GenTask] Processing new task...
================================================================================
📋 [GenTask] Task Details:
  {type: "CHAT", userId: 1, userName: "admin", timestamp: "2024-12-11T10:31:00Z"}

💬 [GenTask] Chat request detected
📝 [GenTask] User prompt:
  {query: "What is the annual leave policy?", length: 41}

🔍 [GenTask] Policy Detection:
  {isAboutPolicy: true, detectedKeywords: ["policy"], confidence: "11%"}

🧠 [GenTask] Internal policy question detected - triggering RAG...

📚 [GenTask] Fetching uploaded documents from database...

🔎 [Database] Querying file table for user documents...
  {userId: 1, limit: 5, table: "file"}

📊 [Database] Query completed:
  {resultsReturned: 1, table: "file", database: "MySQL", dbName: "krd_knowledge_base"}

✅ [Database] Files retrieved from database:
   Row 1: id=45, filename="test-hr-policy.txt", size=1847B, created_at=2024-12-11T10:30:00Z

✅ [GenTask] Documents retrieved successfully
📄 [GenTask] Retrieved files:
   1. test-hr-policy.txt (1.80 KB)

🔗 [GenTask] RAG Context Prepared:
  {filesIncluded: 1, totalContentLength: 245}

✨ [GenTask] Prompt augmented with:
  {ragTriggered: true, dualLanguageEnabled: true, fileIds: [45], enhancedPromptLength: 612}

📤 [GenTask] Sending task to processing queue...

✅ [GenTask] Task created successfully:
  {taskId: "task_abc123", type: "CHAT", ragEnabled: "YES", filesUsed: 1}

================================================================================
```

### Step 6: Verify Response Includes Both Languages
Expected response format:
```
[EN]
According to our company policy, employees are entitled to 20 days of annual 
leave per calendar year. Leave can be carried forward to the next year up to 5 
days. Leave requests must be submitted 2 weeks in advance.

[JA]
当社のポリシーに従い、従業員は暦年ごとに20日間の年次休暇を取得する権利があります。
休暇は翌年まで最大5日間繰り越すことができます。休暇申請は事前に2週間提出する必要があります。

📚 Documents Used:
- test-hr-policy.txt (Document ID: 45)
```

---

## 🔧 Testing Different Scenarios

### Test Case 1: Policy Question → RAG Triggered
**Question**: "What is the remote work policy?"
**Expected**: RAG triggered, answer from document with dual language

### Test Case 2: General Question → No RAG
**Question**: "What is Python?"
**Expected**: RAG not triggered, standard response

### Test Case 3: Policy Question → No Documents
**Scenario**: Delete test document from database
**Question**: "What is the leave policy?"
**Expected**: Question detected as policy, but RAG not triggered (no docs)

### Test Case 4: Multiple Documents
**Setup**: Upload 3 documents
**Question**: "What benefits are available?"
**Expected**: All 3 documents included in context

---

## 📋 Verification Checklist

### Frontend Logs (Browser Console)
- ✅ File selection logged with file details
- ✅ Upload pipeline shows all 4 steps with progress
- ✅ Each step transitions from pending → in-progress → completed
- ✅ Success message shows document is ready for RAG

### Backend Logs (Server Console)
- ✅ GenTask middleware receives CHAT request
- ✅ Policy detection identifies question type
- ✅ Database query logged with table name 'file'
- ✅ Number of files found logged (e.g., 1)
- ✅ File details logged (id, filename, size)
- ✅ RAG context preparation logged
- ✅ Prompt augmentation logged with dual-language instruction

### Database Verification
- ✅ File record exists in `file` table
- ✅ Filename, size, create_by are populated
- ✅ created_at timestamp is correct

### Response Verification
- ✅ Response includes English answer
- ✅ Response includes Japanese (日本語) answer
- ✅ Response lists used documents with IDs

---

## 🐛 Troubleshooting

### Issue: File not appearing in Admin Dashboard
**Solution**:
1. Check browser console for fetch errors
2. Verify `/dev-api/api/files` endpoint is working
3. Check Network tab in DevTools for the fetch request

### Issue: RAG not triggering
**Solution**:
1. Check server console for policy detection logs
2. Verify question contains policy keywords
3. Ensure document exists in database: `SELECT COUNT(*) FROM file;`

### Issue: Console logs not showing
**Solution**:
1. Browser console: Press F12 → Console tab
2. Server console: Check terminal where backend is running
3. Make sure log levels are set to INFO or DEBUG

---

## 📊 Expected Metrics

After successful test:
- **Total Console Logs**: ~15-20 entries
- **Database Queries**: 1 (fetch files)
- **Response Time**: ~2-3 seconds
- **Files Processed**: 1
- **Languages Generated**: 2 (EN + JA)

---

**Test Status**: Ready to Run  
**Created**: December 11, 2025
