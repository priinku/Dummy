# Question Classification & RAG Integration - Quick Reference

## 🎯 System Flow

```
User Question in Chat
        ↓
[Classification Service]
  ├─ Check keywords
  ├─ Calculate confidence
  └─ Return: isInternal (true/false)
        ↓
   IF isInternal = true
        ↓
[Check Uploaded Files]
  ├─ Fetch user's documents
  └─ Prepare RAG context
        ↓
[Augment Prompt]
  └─ Add file content to prompt
        ↓
[Send to LLM/RAG Engine]
        ↓
[Generate Dual Language Response]
  ├─ Generate English
  ├─ Translate to Japanese
  └─ Format with metadata
        ↓
Response to User
  ├─ Dual language answer
  ├─ Classification info
  └─ Document references
```

---

## 📊 Classification Details

### Default Keywords (Internal/Policy)
```
policy, procedure, internal, company, compliance,
regulation, requirement, process, guideline, rule,
standard, protocol, code of conduct, handbook,
manual, employee, hr, human resource
```

### Confidence Scoring
- **0.0 - 0.3**: Likely General Question
- **0.3 - 0.5**: Ambiguous
- **0.5 - 0.7**: Likely Internal
- **0.7 - 1.0**: Definitely Internal

### Example Classifications

| Question | Keywords Matched | Confidence | Result |
|----------|------------------|-----------|--------|
| "What is Python?" | none | 0.0 | GENERAL |
| "Company policy?" | policy, company | 0.4 | AMBIGUOUS |
| "Vacation policy?" | policy | 0.33 | GENERAL |
| "Company vacation policy?" | policy, company | 0.67 | **INTERNAL** ✓ |
| "Remote work policy?" | policy, company, work | 0.75 | **INTERNAL** ✓ |

---

## 🔌 API Integration Points

### UI-2 (Frontend React)
```
ui-2/src/api/admin.ts
└─ classifyQuestion(question: string)
   └─ POST /api/chat/classify
      └─ Returns: ClassificationResult

ChatInterface.tsx
└─ Import classifyQuestion
└─ Call before sending message
└─ Display classification indicator
```

### Backend (Node/Koa)
```
api/src/service/classificationService.ts
└─ classifyQuestion()
└─ advancedClassifyQuestion()

api/src/controller/genTask.ts
└─ Modify getAddMid middleware
└─ Add classification logic
└─ Prepare RAG context

api/src/routes/admin.ts
└─ POST /api/chat/classify (new)
└─ POST /api/chat/with-context (new)
```

---

## 🧠 RAG Triggering Logic

### When RAG is Triggered
```
IF (isInternal == true) AND (user has uploaded files) THEN
  ├─ Fetch uploaded files by user
  ├─ Extract content from files
  ├─ Append to user prompt
  └─ Send to LLM with context
```

### When RAG is NOT Triggered
```
IF (isInternal == false) OR (no uploaded files) THEN
  ├─ Send prompt to LLM as-is
  ├─ Use general knowledge only
  └─ Still provide dual-language output
```

---

## 📝 Implementation Checklist

### Backend (Priority: HIGH)
- [ ] Import classification service
- [ ] Modify genTask middleware
- [ ] Add RAG context preparation
- [ ] Implement dual-language response
- [ ] Add proper logging
- [ ] Test with sample questions

### Frontend UI-2 (Priority: MEDIUM)
- [ ] Create admin.ts API file ✓ DONE
- [ ] Import classifyQuestion in ChatInterface
- [ ] Add classification display indicator
- [ ] Show which documents were used
- [ ] Test classification results

### Database (Priority: LOW)
- [ ] Tables already created
- [ ] Verify migrations applied
- [ ] Check upload directory permissions

---

## 🔑 Key Variables & Settings

### Classification Settings (Per User)
```javascript
{
  classificationThreshold: 0.5,  // 0.1 - 0.9
  enableFileBasedAnswers: true,  // toggle
  internalKeywords: "policy,procedure,..." // custom list
}
```

### Response Metadata
```javascript
{
  classification: {
    isInternal: boolean,
    confidence: number,     // 0-1
    keywords: string[],
    reason: string
  },
  answer_en: string,
  answer_ja: string,
  usedInternalDocs: File[],
  language: "dual"
}
```

---

## 🐛 Debugging & Logging

### Console Logs to Check
```
✅ Classification successful:
   "🔍 Question Classification: isInternal=true confidence=75%"

✅ RAG triggered:
   "📚 RAG Context Prepared: 2 files, 15KB"

✅ Dual language generated:
   "📝 Dual Language Response: EN ✓ JA ✓"

❌ Classification failed:
   "⚠️ Classification failed: [error message]"

❌ RAG failed:
   "❌ Error preparing RAG context: [error message]"
```

---

## 🧪 Test Cases

### Test 1: General Question
```
Question: "What is machine learning?"
Expected:
- isInternal: false
- confidence: 0
- No files referenced
- Standard answer
```

### Test 2: Internal Question with Files
```
Question: "What is the company vacation policy?"
Uploaded: HR_Policy.pdf
Expected:
- isInternal: true
- confidence: ~0.67
- Files referenced: HR_Policy.pdf
- Answer uses file content
- Dual language response
```

### Test 3: Classification Settings
```
Threshold: 0.7 (strict)
Question: "Company policy?"
Expected:
- isInternal: false (below strict threshold)
- No RAG triggered
```

---

## 📦 File Structure (UI-2 Focus)

```
ui-2/
├── src/
│   ├── api/
│   │   ├── request.ts          (existing)
│   │   ├── task.ts             (existing)
│   │   └── admin.ts            [NEW] ✓ Created
│   └── components/
│       ├── ChatInterface.tsx    [MODIFY]
│       └── AdminDashboard.tsx   (existing)
├── README.md
└── UI2_INTEGRATION_GUIDE.md    [NEW] ✓ Created

api/
├── src/
│   ├── service/
│   │   └── classificationService.ts    [EXISTING] ✓ Created
│   ├── controller/
│   │   └── genTask.ts                  [MODIFY]
│   └── routes/
│       └── admin.ts                    [NEW] ✓ Created
└── README.md

chatbot/
├── BACKEND_GENTASK_MODIFICATIONS.md    [NEW] ✓ Created
├── UI2_INTEGRATION_GUIDE.md            [NEW] ✓ Created
└── FILES_CREATED.txt                   (existing)
```

---

## 🎓 Example Code Snippets

### UI-2: Classify Before Sending
```typescript
import { classifyQuestion } from '@/api/admin';

async function sendMessage(message: string) {
  // Classify
  const result = await classifyQuestion(message);
  console.log('Classification:', result);
  
  // Show indicator
  if (result.isInternal) {
    showBadge('📁 INTERNAL - Using company documents');
  }
  
  // Send with classification info
  await addTask({
    type: 'CHAT',
    formData: {
      prompt: message,
      isInternal: result.isInternal,
      classificationKeywords: result.keywords
    }
  });
}
```

### Backend: Prepare RAG Context
```typescript
if (classification.isInternal) {
  const files = await getUploadedFilesForContext(userId);
  const context = files
    .map(f => f.contentExtracted)
    .join('\n\n');
  
  augmentedPrompt = `${prompt}\n\n[Files]\n${context}`;
}
```

---

## 🚀 Deployment Steps

1. **Backend**
   - [ ] Update classificationService (already created)
   - [ ] Modify genTask controller
   - [ ] Add dual-language support
   - [ ] Test thoroughly
   - [ ] Deploy to staging
   - [ ] Verify RAG triggering
   - [ ] Deploy to production

2. **Frontend (UI-2)**
   - [ ] Use admin.ts API file (created)
   - [ ] Update ChatInterface
   - [ ] Add visual indicators
   - [ ] Test classification display
   - [ ] Deploy to staging
   - [ ] User acceptance testing
   - [ ] Deploy to production

3. **Validation**
   - [ ] Classification accuracy: >90%
   - [ ] RAG triggering: Correct cases only
   - [ ] Dual language: Both EN and JA present
   - [ ] Performance: <500ms per question
   - [ ] Error handling: Graceful fallbacks

---

## 📊 Metrics to Monitor

```
Classification Accuracy
├─ Precision: How many classified as internal were correct?
├─ Recall: How many actual internal questions were caught?
└─ F1-Score: Balance between precision and recall

RAG Performance
├─ Files matched per question
├─ Content relevance (user feedback)
└─ Response time with/without RAG

Dual Language
├─ EN response quality
├─ JA translation quality
└─ User language preference

System Health
├─ Classification errors
├─ RAG failures
└─ Response generation failures
```

---

## 💾 State Management

### Store Classification Result
```
sessionStorage.setItem('lastClassification', JSON.stringify({
  isInternal: true,
  confidence: 0.75,
  keywords: ['policy', 'vacation'],
  timestamp: Date.now()
}));
```

### Retrieve for Display
```
const lastClassification = JSON.parse(
  sessionStorage.getItem('lastClassification') || '{}'
);

if (lastClassification.isInternal) {
  showIndicator(`Confidence: ${(lastClassification.confidence * 100).toFixed(0)}%`);
}
```

---

## 🔗 Documentation Links

- **UI-2 Integration**: See `UI2_INTEGRATION_GUIDE.md`
- **Backend Modifications**: See `BACKEND_GENTASK_MODIFICATIONS.md`
- **Classification Service**: See `api/src/service/classificationService.ts`
- **Admin API**: See `ui-2/src/api/admin.ts`

---

**Version**: 1.0  
**Last Updated**: December 11, 2024  
**Status**: ✅ Ready for Implementation
