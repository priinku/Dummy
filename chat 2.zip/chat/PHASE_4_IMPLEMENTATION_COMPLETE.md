# Phase 4: Complete Multi-Step Query Classification & Processing Implementation

## Overview

This document details the complete Phase 4 implementation, which introduces:
1. **Language Detection** - Automatic detection of English and Japanese queries
2. **Query Classification** - Distinction between company-related and general queries
3. **Two Processing Paths** - Separate handling for company vs general queries
4. **Dual-Language Output** - Responses in user's detected language + translation
5. **Document Management** - Delete and duplicate detection for uploaded documents
6. **2-Column UI Display** - Side-by-side display of original and translated responses

---

## Architecture Overview

```
User Query
    ↓
┌─────────────────────────────────────────────────────────────┐
│ Step 1: Language Detection (detectLanguage)                 │
│ - Analyzes query for Japanese characters (hiragana/katakana)│
│ - Returns: 'en' (English) or 'ja' (Japanese)               │
└─────────────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────────────┐
│ Step 2: Query Classification (classifyQuery)                │
│ - Checks for company-related keywords (both EN + JA)        │
│ - Work-related general questions → company queries          │
│ - Returns: { isCompanyQuery, language, confidence, ... }    │
└─────────────────────────────────────────────────────────────┘
    ↓
    ├── GENERAL Query Path
    │   │
    │   ├─ Call LLM directly with query
    │   ├─ Generate response in EN + JA
    │   └─ Display in 2-column UI
    │
    └── COMPANY Query Path
        │
        ├─ If EN: Translate to JA
        ├─ Query RAG system
        ├─ Retrieve documents + citations
        ├─ Call LLM with augmented context
        ├─ Generate response in EN + JA
        └─ Display in 2-column UI with citations
```

---

## Implementation Details

### 1. Language Detection Service

**File:** `api/src/service/queryClassificationService.ts`

**Function:** `detectLanguage(query: string): 'en' | 'ja'`

**Algorithm:**
- Counts Japanese characters (hiragana, katakana, kanji)
- If >20% of characters are Japanese → 'ja'
- Otherwise → 'en'

**Console Output:**
```
🔤 [Language Detection]
  - query: "ご質問内容..." (first 50 chars)
  - japaneseChars: 8
  - totalChars: 24
  - percentage: 33.3%
  - result: 'ja'
```

### 2. Query Classification Service

**File:** `api/src/service/queryClassificationService.ts`

**Function:** `classifyQuery(query: string): ClassificationResult`

**Company Keywords (English):**
```
leave, vacation, holiday, absence, salary, wage, benefits, insurance,
training, development, promotion, raise, employee, team, work, office,
policy, regulation, rule, procedure, guideline, hr, payroll, manager,
contract, employment, resignation, sick leave, ...
```

**Company Keywords (Japanese):**
```
休暇, 有給, 休日, 給与, 給料, ボーナス, 福利, 厚生, 保険,
研修, 昇進, 昇給, 従業員, チーム, 仕事, オフィス, ポリシー,
規程, 規則, 手続き, 人事, マネージャー, 契約, 雇用, 病気休暇, ...
```

**Classification Logic:**
- Detected keywords matched against relevant language list
- Confidence = (keywords found / total keywords) * 100%
- Company query if: keywords detected > 0 OR work-related terms found
- Example: "What is the annual leave policy?" → Company query (70% confidence)

**Console Output:**
```
📊 [Query Classification]
  - isCompanyQuery: true
  - language: 'en'
  - detectedKeywords: ['leave', 'policy', 'annual']
  - confidence: 21.4%
  - reason: "Company query detected (keywords: leave, policy, annual)"
```

### 3. Translation Service

**File:** `api/src/service/translationService.ts`

**Function:** `translateText(req: TranslationRequest): Promise<TranslationResult>`

**Supports:**
- EN ↔ JA translation
- Uses Ollama gpt-oss:120b model
- Timeout: 30 seconds
- Temperature: 0.7

**Usage in Company Path:**
- If query language is English
- Translate to Japanese for better RAG matching
- Original query preserved for response

**Example:**
```
Original:   "What is the overtime policy?"
Translated: "残業ポリシーは何ですか？"
```

**Console Output:**
```
🌐 [Translation Service] Starting translation
  - sourceLang: 'en'
  - targetLang: 'ja'
  - textPreview: "What is the overtime policy?"

✅ [Translation] Success
  - sourceLang: 'en'
  - targetLang: 'ja'
  - originalLength: 31
  - translatedLength: 28
  - translatedPreview: "残業ポリシーは何ですか？"
```

### 4. Enhanced genTask Controller

**File:** `api/src/controller/genTask.ts`

**Processing Flow:**

#### Step 1: Language Detection
```typescript
detectedLanguage = detectLanguage(userQuery);
// Result: 'en' or 'ja'
```

#### Step 2: Query Classification
```typescript
const classification = classifyQuery(userQuery);
isCompanyQuery = classification.isCompanyQuery;
processingPath = isCompanyQuery ? 'COMPANY' : 'GENERAL';
```

#### Path 1.1: General Query Handler
```
Input:  "What is the capital of France?"
Language: 'en'

→ Create prompt with dual-language instruction
→ Call LLM (gpt-oss:120b)

Output: 
[EN]
The capital of France is Paris...

[JA]
フランスの首都はパリです...
```

**Enhanced Prompt:**
```
{userQuery}

---

📋 INSTRUCTIONS FOR RESPONSE:
1. Provide answer in detected user language FIRST
2. Then provide translation to the other language
3. Use format:
[EN]
Your answer in English

[JA]
Your answer in Japanese (日本語)
```

#### Path 1.2: Company Query Handler
```
Input:  "What is the annual leave policy?"
Language: 'en'
Classification: Company Query

Step 1: Translate if needed
  → EN "What is the annual leave policy?"
  → JA "年間休暇ポリシーは何ですか？"

Step 2: Query RAG
  → Retrieve relevant documents
  → Extract page citations
  
Step 3: Augment prompt
  → Include document context
  → Request dual-language output with citations

Output:
[EN]
Based on the Employee Handbook (page 23)...

[JA]
従業員ハンドブック（23ページ）に基づくと...

📚 Sources:
- Employee_Handbook.pdf (page 23)
- HR_Policy_Manual.pdf (page 45)
```

**Enhanced Prompt (Company Path):**
```
ORIGINAL QUERY: {userQuery}
(Translated to Japanese for RAG: {queryForRAG})

[COMPANY DOCUMENTS - INTERNAL CONTEXT]
{ragContext}
[END OF CONTEXT]

---

📋 RESPONSE INSTRUCTIONS:
1. Answer using the documents provided above
2. ALWAYS include page citations
3. Provide answer in detected user language FIRST
4. Then provide translation to the other language
5. Use format with citations
```

### 5. DualLanguageResponse Component

**File:** `ui-2/src/components/DualLanguageResponse.tsx`

**Features:**
- 2-column side-by-side layout
- Tab controls: Both | Language 1 | Language 2
- Copy buttons for each column
- Metadata display (processing path, RAG status)
- Page citations section for RAG responses
- Responsive design (single column on mobile)

**Props:**
```typescript
interface DualLanguageResponseProps {
  detectedLanguage: 'en' | 'ja';     // User's detected language
  primaryText: string;                 // Response in user's language
  secondaryText: string;               // Translation
  isRAGBased?: boolean;                // Show citations if true
  citations?: PageCitation[];          // Array of {filename, page}
  metadata?: {
    processingPath?: string;           // 'GENERAL' or 'COMPANY'
    ragTriggered?: boolean;
    filesUsed?: number;
  };
}
```

**Column Headers:**
- Column 1: 日本語 (Detected) | English (Detected)
- Column 2: English (Translation) | 日本語 (Translation)

**Color Scheme:**
- Primary: Blue (user's language)
- Secondary: Purple (translation)
- Metadata: Amber/Gray

### 6. AdminDashboard Enhancements

**File:** `ui-2/src/components/AdminDashboard.tsx`

**New Features:**

#### Delete Functionality
- Delete button in each document table row
- Confirmation dialog before deletion
- Calls: `DELETE /dev-api/api/files/:fileId`
- Success: removes from table, shows confirmation

**Button State:**
```
Loading:   "Deleting..."
Complete:  "Delete"
Disabled:  During deletion
```

#### Duplicate Detection
- Checks filename against database when file selected
- Shows modal popup with existing file details
- Options:
  - Cancel (dismiss)
  - Delete & Replace (delete existing + allow new upload)

**Modal Content:**
```
⚠️  Duplicate Document
This file already exists

📋 File Name: employee_handbook.pdf
📅 Uploaded on: 2024-01-15 10:30 AM
👤 Uploaded by: Admin User

[Cancel] [Delete & Replace]
```

**Console Logging:**
```
📎 [AdminDashboard] File selected
⚠️  [AdminDashboard] Duplicate file detected
🗑️  [AdminDashboard] Deleting file
✅ [AdminDashboard] File deleted successfully
```

### 7. Delete Endpoint (Backend)

**File:** `api/src/controller/file.ts` → `deleteFileById()`

**Endpoint:** `DELETE /api/files/:id`

**Process:**
1. Validate file ID
2. Find file in database
3. Delete from MySQL
4. Delete from RAG system (ChromaDB)
5. Delete from Solr search index
6. Return confirmation

**Console Logging:**
```
🗑️  [FileController] Deleting file by ID
  - fileId: 5
  - timestamp: 2024-01-15T10:45:00Z

📄 [FileController] File found
  - id: 5
  - filename: policy.pdf
  - storage_key: abc123

✅ [FileController] File deleted from MySQL
✅ [FileController] File deleted from RAG
✅ [FileController] File deleted from Solr

🎉 [FileController] File deleted successfully
  - fileId: 5
  - filename: policy.pdf
```

---

## Data Flow Example

### Scenario 1: General Query in English

```
User Types: "What is the weather today?"

Backend genTask.ts:
  1. detectLanguage("What is the weather today?")
     → Result: 'en' (0% Japanese characters)
  
  2. classifyQuery("What is the weather today?")
     → Matching keywords: [] (empty)
     → isCompanyQuery: false
     → processingPath: 'GENERAL'
  
  3. Create enhanced prompt:
     ```
     What is the weather today?
     
     📋 INSTRUCTIONS FOR RESPONSE:
     1. Provide answer in detected user language FIRST
     2. Then provide translation
     3. Use format:
     [EN]
     Your answer in English
     
     [JA]
     Your answer in Japanese
     ```
  
  4. Call LLM → get response with [EN] and [JA] sections
  
  5. Parse response, send to ChatInterface

Frontend:
  1. Receive message with metadata:
     - processingPath: 'GENERAL'
     - detectedLanguage: 'en'
     - ragTriggered: false
  
  2. Render DualLanguageResponse component:
     - Column 1: English text (detected language)
     - Column 2: Japanese translation
     - Metadata badge: "❓ General Query"
```

**Output Display:**
```
┌─────────────────────────────────────────────┐
│ ❓ General Query | Both | English | 日本語     │
├─────────────────────────────────────────────┤
│ Column 1: English          │ Column 2: 日本語  │
│ The weather today is...    │ 今日の天気は... │
│                            │                  │
│ [Copy]                     │ [Copy]          │
└─────────────────────────────────────────────┘
```

### Scenario 2: Company Query in Japanese

```
User Types: "年間休暇ポリシーについて教えてください"

Backend genTask.ts:
  1. detectLanguage("年間休暇ポリシーについて教えてください")
     → Japanese characters: 12
     → Total: 12
     → Percentage: 100%
     → Result: 'ja' (>20% threshold)
  
  2. classifyQuery("年間休暇ポリシーについて教えてください")
     → Matching keywords: ['休暇', 'ポリシー'] (Japanese keywords)
     → Confidence: 18% (2 / 11 keywords)
     → isCompanyQuery: true
     → processingPath: 'COMPANY'
  
  3. RAG retrieval:
     → Query: "年間休暇ポリシーについて教えてください" (already JA)
     → No translation needed
     → Retrieved documents: [HR_Manual.pdf, Policy_2024.pdf]
     → Citations: {filename, page}
  
  4. Create enhanced prompt with context:
     ```
     ORIGINAL QUERY: 年間休暇ポリシーについて教えてください
     (No translation needed - already Japanese)
     
     [COMPANY DOCUMENTS - INTERNAL CONTEXT]
     --- File: HR_Manual.pdf ---
     [Document content would be extracted...]
     [Page citations would be included...]
     
     --- File: Policy_2024.pdf ---
     [Document content would be extracted...]
     [Page citations would be included...]
     [END OF CONTEXT]
     
     📋 RESPONSE INSTRUCTIONS:
     1. Answer using documents above
     2. ALWAYS include page citations
     3. Provide answer in detected user language FIRST
     4. Then provide translation
     ```
  
  5. Call LLM → get response with [JA] and [EN] sections

Frontend:
  1. Receive message with metadata:
     - processingPath: 'COMPANY'
     - detectedLanguage: 'ja'
     - ragTriggered: true
     - filesUsed: 2
     - citations: [{filename: 'HR_Manual.pdf', page: 5}, ...]
  
  2. Render DualLanguageResponse component:
     - Column 1: Japanese text (detected language)
     - Column 2: English translation
     - Metadata badges: "🏢 Company Query" + "RAG Enabled (2 files)"
     - Citations section at bottom
```

**Output Display:**
```
┌──────────────────────────────────────────────────────┐
│ 🏢 Company Query | RAG Enabled (2 files) | Both 日本語 EN │
├──────────────────────────────────────────────────────┤
│ Column 1: 日本語 (Detected) │ Column 2: English (Translation)│
│ 年間休暇ポリシーに基づ... │ Based on the Annual Leave...  │
│                            │                              │
│ [Copy]                     │ [Copy]                      │
├──────────────────────────────────────────────────────┤
│ 📚 Sources:                                           │
│ • HR_Manual.pdf (page 5)                             │
│ • Policy_2024.pdf (page 12)                          │
└──────────────────────────────────────────────────────┘
```

---

## Console Logging Output

### Complete Request Flow Logs

```
================================================================================
🚀 [GenTask] Processing new task...
================================================================================
📋 [GenTask] Task Details:
  - type: CHAT
  - userId: 1
  - userName: admin
  - timestamp: 2024-01-15T10:45:30.000Z

💬 [GenTask] Chat request detected
📝 [GenTask] User query:
  - query: "What is the annual leave policy?"
  - length: 32

--- STEP 1: LANGUAGE DETECTION ---
🔤 [Language Detection]
  - query: "What is the annual leave policy?"
  - japaneseChars: 0
  - totalChars: 32
  - percentage: 0.0%

✅ [GenTask] Language detected:
  - language: English (EN)
  - confidence: High

--- STEP 2: QUERY CLASSIFICATION ---
📊 [GenTask] Classification Result:
  - isCompanyQuery: true
  - path: COMPANY
  - language: en
  - confidence: 30.8%
  - reason: Company query detected (keywords: leave, policy, annual)

--- STEP 1.2: COMPANY QUERY HANDLER ---
ℹ️  [GenTask] Processing as COMPANY query
🏢 [GenTask] Proceeding to Step 2: RAG + Processing

🌐 [GenTask] Query is in English - translating to Japanese for RAG...
✅ [GenTask] Translation successful:
  - original: "What is the annual leave policy?"
  - translated: "年間休暇ポリシーは何ですか？"

--- STEP 2: RAG RETRIEVAL & PROCESSING ---
📚 [GenTask] Fetching uploaded documents from database...
🔎 [Database] Querying file table for user documents...
  - userId: 1
  - limit: 5
  - table: file

📊 [Database] Query completed:
  - resultsReturned: 2
  - table: file
  - database: MySQL

✅ [Database] Files retrieved from database:
   Row 1: id=1, filename="HR_Policy_Manual.pdf", size=2048576B, created_at=2024-01-10T10:00:00Z
   Row 2: id=2, filename="Employee_Handbook.pdf", size=3145728B, created_at=2024-01-12T14:30:00Z

✅ [GenTask] Documents retrieved successfully
📄 [GenTask] Retrieved files:
   1. HR_Policy_Manual.pdf (2.00 MB)
   2. Employee_Handbook.pdf (3.00 MB)

🔗 [GenTask] RAG Context Prepared:
  - filesIncluded: 2
  - totalContentLength: 5194304

✨ [GenTask] Company path with RAG prepared:
  - processingPath: COMPANY
  - userLanguage: en
  - ragRequired: true
  - filesUsed: 2
  - dualLanguageFormat: Enabled with citations

--- TASK CREATION ---
📤 [GenTask] Sending task to processing queue...
✅ [GenTask] Task created successfully:
  - taskId: task_abc123
  - type: CHAT
  - processingPath: COMPANY
  - detectedLanguage: en
  - ragEnabled: YES
  - filesUsed: 2

================================================================================

[LLM Processing occurs here...]
[Response parsing happens...]

✅ [AdminDashboard] Document history loaded:
  - total: 2
  - files: [{id: 1, filename: 'HR_Policy_Manual.pdf'...}, ...]
```

---

## Testing the Implementation

### Test Case 1: General English Query
```
Input:  "What is the capital of Japan?"
Expected Output:
  - processingPath: 'GENERAL'
  - detectedLanguage: 'en'
  - ragTriggered: false
  - Column 1: English answer
  - Column 2: Japanese translation
```

### Test Case 2: General Japanese Query
```
Input:  "フランスの首都は何ですか？"
Expected Output:
  - processingPath: 'GENERAL'
  - detectedLanguage: 'ja'
  - ragTriggered: false
  - Column 1: Japanese answer
  - Column 2: English translation
```

### Test Case 3: Company Query (English)
```
Input:  "What is the remote work policy?"
Expected Output:
  - processingPath: 'COMPANY'
  - detectedLanguage: 'en'
  - ragTriggered: true (if documents exist)
  - Column 1: English answer with citations
  - Column 2: Japanese translation with citations
```

### Test Case 4: Company Query (Japanese)
```
Input:  "リモートワークのポリシーについて教えてください"
Expected Output:
  - processingPath: 'COMPANY'
  - detectedLanguage: 'ja'
  - ragTriggered: true (if documents exist)
  - Column 1: Japanese answer with citations
  - Column 2: English translation with citations
```

### Test Case 5: Duplicate Document Upload
```
Steps:
  1. Upload "policy.pdf" successfully
  2. Try to upload "policy.pdf" again
  
Expected Output:
  - Duplicate warning modal appears
  - Shows existing file details
  - User can click "Delete & Replace"
  - Old file deleted from database
  - New file can be uploaded
```

### Test Case 6: Delete Document
```
Steps:
  1. Document appears in table with Delete button
  2. Click Delete button
  3. Confirm in dialog
  
Expected Output:
  - DELETE /api/files/:id called
  - Deleted from MySQL, RAG, Solr
  - Row removed from table
  - Success notification shown
```

---

## Key Files Modified/Created

### Created Files
- `api/src/service/queryClassificationService.ts` (330 lines)
- `api/src/service/translationService.ts` (150 lines)
- `ui-2/src/components/DualLanguageResponse.tsx` (200 lines)

### Modified Files
- `api/src/controller/genTask.ts` (220 new lines, complete rewrite of processing logic)
- `api/src/controller/file.ts` (+90 lines for deleteFileById function)
- `api/src/routes/file.ts` (added deleteFileById route)
- `ui-2/src/components/AdminDashboard.tsx` (+150 lines for delete, duplicate detection)

### Unchanged Files (Foundation from Phase 3)
- `api/src/mysql/model/file.model.ts` (database schema)
- `config/default.yml` (Ollama, RAG configuration)
- `ui-2/src/components/ChatInterface.tsx` (base chat component)

---

## Performance Considerations

1. **Language Detection:** O(n) where n = query length (character count)
2. **Query Classification:** O(k) where k = keyword list size (~100 keywords)
3. **Translation:** 1-2 seconds per translation call (Ollama model inference)
4. **Database Deletion:** 3 operations (MySQL, RAG, Solr) with timeout handling
5. **UI Rendering:** 2-column layout optimized for desktop and mobile

---

## Error Handling

### Language Detection
- Falls back to 'en' if any error
- Handles edge cases (empty strings, special chars)

### Query Classification
- Returns 'general' if classification fails
- Logs confidence even on boundary cases

### Translation
- Returns original text if translation fails
- Continues processing without blocking

### RAG Retrieval
- Gracefully handles no documents found
- Continues with standard LLM response

### File Deletion
- Successful MySQL deletion is required
- RAG/Solr deletion failures are warnings (not errors)
- User-facing error only if MySQL fails

---

## Migration Notes

This Phase 4 implementation:
- ✅ Builds upon Phase 3 foundation (logging, real-time data)
- ✅ Does NOT modify existing database schema
- ✅ Maintains backward compatibility
- ✅ All endpoints remain functional
- ✅ Requires zero database migrations
- ✅ Can be deployed as incremental update

---

## Next Steps

After Phase 4 deployment:
1. Monitor console logs for any errors
2. Test with diverse queries in both languages
3. Verify RAG citations are extracted correctly
4. Validate 2-column UI rendering on different devices
5. Gather user feedback on dual-language responses
6. Consider adding more language keywords based on usage patterns
7. Potential future: User language preference setting

