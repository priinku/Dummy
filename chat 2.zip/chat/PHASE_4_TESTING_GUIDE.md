# Phase 4 Testing & Validation Guide

## Quick Start Testing

### Prerequisites
- Backend running on port 9090
- Frontend running on port 7001
- Database populated with at least one document
- Ollama running with gpt-oss:120b model

---

## Test Scenarios

### 1. General English Query

**Test in ChatInterface:**
```
Input: "What is the capital of France?"

Expected Console Output (Backend):
✅ [Language Detection] → 'en' (0% Japanese)
📊 [Query Classification] → 'general' (no company keywords)
ℹ️ [GenTask] Processing as GENERAL query

Expected Frontend Output:
┌─ Both | English | 日本語
├─ Column 1 (English): "The capital of France is Paris..."
├─ Column 2 (日本語): "フランスの首都はパリです..."
└─ Metadata: "❓ General Query"
```

**Verification:**
- [ ] Backend logs show 'en' language detection
- [ ] No RAG triggered message
- [ ] Both columns display content
- [ ] Tab switching works

---

### 2. General Japanese Query

**Test in ChatInterface:**
```
Input: "フランスの首都は何ですか？"

Expected Console Output (Backend):
✅ [Language Detection] → 'ja' (100% Japanese)
📊 [Query Classification] → 'general'
ℹ️ [GenTask] Processing as GENERAL query

Expected Frontend Output:
┌─ Both | 日本語 | English
├─ Column 1 (日本語): "フランスの首都はパリです..."
├─ Column 2 (English): "The capital of France is Paris..."
└─ Metadata: "❓ General Query"
```

**Verification:**
- [ ] Backend logs show 'ja' language detection
- [ ] Column 1 shows Japanese text first
- [ ] Tab order changes to Japanese first

---

### 3. Company Query (English)

**Test in ChatInterface:**
```
Input: "What is the annual leave policy?"

Expected Console Output (Backend):
✅ [Language Detection] → 'en'
📊 [Query Classification] → 'company' (keywords: leave, policy)
🏢 [GenTask] Processing as COMPANY query
🌐 [GenTask] Translating EN to JA...
✅ [Translation] Success → "年間休暇ポリシーは何ですか？"
📚 [GenTask] Fetching uploaded documents...
📊 [Database] Query completed: resultsReturned: 2
✅ [GenTask] Documents retrieved successfully
🔗 [GenTask] RAG Context Prepared

Expected Frontend Output:
┌─ 🏢 Company Query | RAG Enabled (2 files) | Both | English | 日本語
├─ Column 1 (English): "Based on the Employee Handbook..."
├─ Column 2 (日本語): "従業員ハンドブックに基づくと..."
├─ Sources section with page citations
└─ [Copy] buttons for each column
```

**Verification:**
- [ ] Backend translates EN to JA
- [ ] "RAG Enabled" badge shows file count
- [ ] Documents fetched from database
- [ ] Citations appear in Sources section
- [ ] Both columns have page references

---

### 4. Company Query (Japanese)

**Test in ChatInterface:**
```
Input: "年間休暇ポリシーについて教えてください"

Expected Console Output (Backend):
✅ [Language Detection] → 'ja'
📊 [Query Classification] → 'company'
🏢 [GenTask] Processing as COMPANY query
(No translation needed - query already JA)
📚 [GenTask] Fetching documents...

Expected Frontend Output:
┌─ 🏢 Company Query | RAG Enabled (N files) | Both | 日本語 | English
├─ Column 1 (日本語): "従業員ハンドブックに基づ..."
├─ Column 2 (English): "Based on the Employee Handbook..."
├─ Sources with citations
```

**Verification:**
- [ ] No translation message in logs (query already JA)
- [ ] Column 1 shows Japanese first
- [ ] RAG documents retrieved

---

### 5. Document Upload - Normal Flow

**Test in AdminDashboard → Documents Tab:**

```
Steps:
1. Click "Upload Document" button
2. Select a new file (e.g., "new_policy.pdf")
3. Select category
4. Click "Start Upload Pipeline"

Expected Console Output:
📎 [AdminDashboard] File selected
📚 [AdminDashboard] Starting upload pipeline...
🔄 [AdminDashboard] STEP 1: File Upload - IN PROGRESS
✅ [AdminDashboard] STEP 1: File Upload - COMPLETED
🔄 [AdminDashboard] STEP 2: Content Extraction - IN PROGRESS
✅ [AdminDashboard] STEP 2: Content Extraction - COMPLETED
[... steps 3 & 4 ...]
🎉 [AdminDashboard] Upload pipeline completed successfully!
📁 [AdminDashboard] File now stored in database: file table
🧠 [AdminDashboard] File is now ready for RAG queries

Expected Frontend:
- Progress bars fill for each step
- Success alert appears
- File appears in document table below
```

**Verification:**
- [ ] All 4 steps show completion
- [ ] File appears in table immediately
- [ ] No duplicate warning appears
- [ ] Success message displayed

---

### 6. Document Upload - Duplicate Detection

**Test in AdminDashboard → Documents Tab:**

```
Precondition: "policy.pdf" already exists in table

Steps:
1. Click "Upload Document"
2. Select same file "policy.pdf"
3. See duplicate warning modal

Expected Console Output:
📎 [AdminDashboard] File selected
⚠️ [AdminDashboard] Duplicate file detected
  - filename: "policy.pdf"
  - existingId: 5
  - existingUploadDate: 2024-01-15T10:00:00Z

Expected Modal:
┌─────────────────────────────────────┐
│ ⚠️  Duplicate Document              │
│ This file already exists            │
│                                     │
│ File Name: policy.pdf               │
│ Uploaded on: 1/15/2024 10:00 AM    │
│ Uploaded by: admin                  │
│                                     │
│ [Cancel] [Delete & Replace]         │
└─────────────────────────────────────┘
```

**Test Option A: Cancel**
- [ ] Modal closes
- [ ] No file uploaded
- [ ] Table unchanged

**Test Option B: Delete & Replace**
- [ ] Old file deleted from database
- [ ] DELETE /api/files/5 called
- [ ] New file upload begins
- [ ] Duplicate modal closes
- [ ] New file appears in table

---

### 7. Document Deletion

**Test in AdminDashboard → Documents Tab:**

```
Steps:
1. Find a document row in the table
2. Click "Delete" button in Action column
3. Confirm in dialog

Expected Console Output (Frontend):
🗑️ [AdminDashboard] Deleting file
  - fileId: 3
  - filename: "old_policy.pdf"
  - timestamp: 2024-01-15T10:45:00Z

Expected Console Output (Backend):
🗑️ [FileController] Deleting file by ID
  - fileId: 3

📄 [FileController] File found
  - id: 3
  - filename: "old_policy.pdf"

✅ [FileController] File deleted from MySQL
✅ [FileController] File deleted from RAG
✅ [FileController] File deleted from Solr

🎉 [FileController] File deleted successfully
  - fileId: 3
  - filename: "old_policy.pdf"

Expected Frontend:
- Delete button becomes "Deleting..."
- After success, row disappears from table
- Success confirmation message
```

**Verification:**
- [ ] Confirmation dialog appears
- [ ] DELETE endpoint called with correct ID
- [ ] File removed from table
- [ ] No errors in console
- [ ] Document history reloaded (if applicable)

---

## Edge Cases to Test

### 1. Mixed Language Query
```
Input: "What about 年間休暇 policy?" (25% Japanese)

Expected:
- Language detection: 'ja' (>20% threshold)
- Classify based on detected keywords
```

### 2. No Documents Uploaded
```
Precondition: Database has no files

Input: "What is the leave policy?"

Expected:
- Classification: company query
- RAG retrieval: 0 files found
- ⚠️ [GenTask] No documents found
- Response: standard LLM without context
```

### 3. Translation Timeout
```
(Simulate by blocking Ollama endpoint)

Input: Company query in English

Expected:
- ⚠️ [GenTask] Translation failed
- Continue with original English query
- Process normally (less optimal but functional)
```

### 4. Large Document Set
```
Precondition: 10+ documents in database

Input: Company query

Expected:
- All documents fetched (limit: 5)
- RAG context prepared
- LLM processes within reasonable time
- Citations list shows relevant files
```

---

## Performance Benchmarks

### Expected Response Times

| Operation | Target Time | Notes |
|-----------|------------|-------|
| Language Detection | < 50ms | Character counting |
| Query Classification | < 100ms | Keyword matching |
| Translation (EN→JA) | 1-2s | Ollama model inference |
| RAG Retrieval | 500ms-1s | Database + ChromaDB query |
| LLM Response | 2-5s | Ollama gpt-oss:120b |
| **Total (Company)** | **4-9s** | End-to-end |
| **Total (General)** | **3-6s** | Without translation/RAG |

---

## Browser Console Checks

### Frontend Console Should Show:
```
✅ [Language Detection] output
✅ [Query Classification] output  
✅ Message metadata displayed
✅ No TypeScript errors
✅ No React warnings
✅ DualLanguageResponse renders
```

### Server Console Should Show:
```
✅ [GenTask] request logs
✅ [Language Detection] results
✅ [Query Classification] results
✅ [Database] file queries
✅ [Translation] status
✅ [FileController] delete operations
```

---

## Known Limitations & Workarounds

### 1. RAG Content Extraction
**Limitation:** Document content extraction shown as placeholder
```
[Content from uploaded document would be extracted here]
```
**Status:** Placeholder - actual content extraction depends on RAG backend

**Workaround:** Verify RAG system is working independently

### 2. Page Citation Extraction
**Limitation:** Page numbers may not always be extracted correctly
**Status:** Dependent on document source format

**Workaround:** Check RAG backend returns page metadata

### 3. Translation Accuracy
**Limitation:** Ollama model accuracy varies
**Status:** Uses temperature 0.7 for balance

**Workaround:** Provide feedback for poor translations

---

## Troubleshooting

### Issue: "Company query detected but no RAG needed"
```
Reason: Query classified as company but no documents found
Solution: Upload documents to database first
```

### Issue: "Language always detected as English"
```
Reason: Query not meeting >20% Japanese character threshold
Solution: Ensure query has significant Japanese content
```

### Issue: Translation takes too long
```
Reason: Ollama model is slow or unresponsive
Solution: Restart Ollama, check model is loaded
```

### Issue: Duplicate detection not working
```
Reason: Filenames must match exactly (case-sensitive)
Solution: Check filename comparison logic
```

### Issue: Delete button doesn't work
```
Reason: DELETE endpoint not accessible
Solution: Check /dev-api proxy configuration (port 9090)
```

---

## Validation Checklist

Before considering Phase 4 complete:

- [ ] All 4 console log sections appear for company queries
- [ ] Language detection works for EN and JA
- [ ] General queries don't trigger RAG
- [ ] Company queries trigger RAG when documents exist
- [ ] 2-column UI displays both languages
- [ ] Copy buttons work for each column
- [ ] Tab switching between Both/EN/JA works
- [ ] Delete button appears for each document
- [ ] Duplicate warning modal appears
- [ ] Delete & Replace works
- [ ] Citations appear for RAG responses
- [ ] Metadata badges show correctly
- [ ] No TypeScript compilation errors
- [ ] No linting errors in modified files
- [ ] Database operations succeed
- [ ] Translation service works (E2E test)
- [ ] All three endpoints function:
  - POST /api/files/upload (upload)
  - GET /api/files (list)
  - DELETE /api/files/:id (new delete)

---

## Sign-Off

Once all tests pass:

✅ **Phase 4 Complete**
- Multi-step query processing implemented
- Language detection working
- Query classification accurate
- Two processing paths functional
- Dual-language output displaying correctly
- Document management enhanced
- Ready for production deployment

