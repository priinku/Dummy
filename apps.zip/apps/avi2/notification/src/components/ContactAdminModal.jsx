import { useState } from 'react';

export default function ContactAdminModal({ isOpen, onClose, onSend }) {
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');

  const handleSend = () => {
    if (!message.trim()) {
      alert('Please enter a message');
      return;
    }
    onSend({ subject, message });
    setSubject('');
    setMessage('');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <h2>Contact Admin</h2>
        
        <input
          className="modal-input"
          type="text"
          placeholder="Subject (optional)"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
        />
        
        <textarea
          className="modal-textarea"
          placeholder="Your message here..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
        
        <div className="modal-buttons">
          <button className="cancel-btn" onClick={onClose}>
            Cancel
          </button>
          <button className="send-btn" onClick={handleSend}>
            Send
          </button>
        </div>
      </div>
    </div>
  );
}
