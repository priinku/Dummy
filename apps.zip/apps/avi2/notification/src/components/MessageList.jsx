export default function MessageList({ messages }) {
  return (
    <div className="message-list">
      {messages.length === 0 ? (
        <p style={{ color: '#999', textAlign: 'center' }}>No messages yet</p>
      ) : (
        messages.map((m, i) => (
          <div key={i} className={m.role === 'admin' ? 'admin-msg' : 'user-msg'}>
            <strong>{m.sender}</strong>
            <h4 style={{ margin: '5px 0', color: '#0078ff' }}>{m.subject}</h4>
            <p>{m.text}</p>
            <span>{m.time}</span>
          </div>
        ))
      )}
    </div>
  );
}

