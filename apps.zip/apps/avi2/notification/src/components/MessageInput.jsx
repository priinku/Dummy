import { useState } from 'react';
import { useAuth } from '../context/AuthContext';

export default function MessageInput({ send }) {
  const { user } = useAuth();
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');

  const submit = () => {
    if (!subject.trim() || !message.trim()) return;
    send({ subject, message });
    setSubject('');
    setMessage('');
  };

  const buttonText = user.role === 'admin' ? 'Send to all users' : 'Send to admin';

  return (
    <div className="message-input">
      <input
        className="subject-input"
        placeholder="Subject or Title"
        value={subject}
        onChange={(e) => setSubject(e.target.value)}
      />
      <textarea
        className="message-textarea"
        placeholder="Type your message here..."
        value={message}
        onChange={(e) => setMessage(e.target.value)}
      />
      <div className="send-button-container">
        <button onClick={submit}>{buttonText}</button>
      </div>
    </div>
  );
}

