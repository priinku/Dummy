import { useAuth } from './context/AuthContext';
import Login from './pages/Login';
import Messenger from './pages/Messenger';

export default function App() {
  const { user } = useAuth();
  return user ? <Messenger /> : <Login />;
}

