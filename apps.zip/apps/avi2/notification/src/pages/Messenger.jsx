import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import MessageList from '../components/MessageList';
import MessageInput from '../components/MessageInput';
import ContactAdminModal from '../components/ContactAdminModal';

export default function Messenger() {
  const { user, logout } = useAuth();
  const [messages, setMessages] = useState([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);

  // Load messages from localStorage on mount
  useEffect(() => {
    const storedMessages = localStorage.getItem('notifications_messages');
    if (storedMessages) {
      try {
        setMessages(JSON.parse(storedMessages));
      } catch (e) {
        console.error('Error loading messages:', e);
      }
    }
  }, []);

  const sendMessage = ({ subject, message }) => {
    const msg = {
      sender: user.id,
      role: user.role,
      subject,
      text: message,
      time: new Date().toLocaleTimeString(),
      date: new Date().toLocaleDateString(),
    };
    
    const updatedMessages = [...messages, msg];
    setMessages(updatedMessages);
    
    // Store in localStorage
    localStorage.setItem('notifications_messages', JSON.stringify(updatedMessages));
  };

  const visibleMessages = messages.filter((m) => {
    if (user.role === 'admin') return true;
    return m.role === 'admin';
  });

  const notifications = messages.filter((m) => {
    if (user.role === 'admin') return m.role === 'user';
    return m.role === 'admin';
  });

  return (
    <div className="messenger-container">
      <div className="header">
        <h2>{user.role === 'admin' ? 'Admin Panel' : 'Contact Admin'}</h2>
        <div>
          {user.role === 'user' && (
            <button 
              className="notification-button" 
              onClick={() => setShowContactModal(true)}
              style={{ marginRight: '10px' }}
            >
              ✉️ Contact Admin
            </button>
          )}
          <button className="notification-button" onClick={() => setShowNotifications(!showNotifications)}>
            🔔 Notifications ({notifications.length})
          </button>
          <button onClick={logout}>Logout</button>
        </div>
      </div>

      {showNotifications && (
        <div className="notification-panel">
          <h4>Chat History</h4>
          {notifications.length === 0 ? (
            <p style={{ color: '#999' }}>No notifications</p>
          ) : (
            notifications.map((n, i) => (
              <div key={i} className="notification-item">
                <strong>{n.sender}:</strong> {n.subject}
                <br />
                <p style={{ margin: '5px 0', color: '#ccc', fontSize: '12px' }}>{n.text}</p>
                <span style={{ fontSize: '12px', color: '#999' }}>{n.date} {n.time}</span>
              </div>
            ))
          )}
        </div>
      )}

      {user.role === 'admin' && <MessageList messages={visibleMessages} />}
      {user.role === 'admin' && <MessageInput send={sendMessage} />}

      <ContactAdminModal 
        isOpen={showContactModal}
        onClose={() => setShowContactModal(false)}
        onSend={sendMessage}
      />
    </div>
  );
}

