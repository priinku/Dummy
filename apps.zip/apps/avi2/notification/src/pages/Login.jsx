import { useState } from 'react';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const { login } = useAuth();
  const [id, setId] = useState('');
  const [pass, setPass] = useState('');
  const [err, setErr] = useState('');

  const submit = () => {
    const ok = login(id, pass);
    if (!ok) setErr('Invalid credentials');
  };

  return (
    <div className="login-container">
      <h2>Login</h2>

      <input
        placeholder="User ID"
        value={id}
        onChange={(e) => setId(e.target.value)}
      />

      <input
        placeholder="Password"
        type="password"
        value={pass}
        onChange={(e) => setPass(e.target.value)}
      />

      <button onClick={submit}>Login</button>
      {err && <p className="error">{err}</p>}
    </div>
  );
}

