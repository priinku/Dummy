import { createContext, useContext, useState } from 'react';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);

  const login = (id, pass) => {
    const admins = { admin: 'admin123' };
    const users = { user1: 'user123', user2: 'user123' };

    if (admins[id] && admins[id] === pass) {
      setUser({ id, role: 'admin' });
      return true;
    }
    if (users[id] && users[id] === pass) {
      setUser({ id, role: 'user' });
      return true;
    }
    return false;
  };

  const logout = () => setUser(null);

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);

