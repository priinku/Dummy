# Aviary Lite for IJTT
このbranchには、IJTT用にカスタマイズされたaviaryが含まれています

## 中間ウェアのインストール
必要な場合はconda環境を用意してください
```
conda create -n IJTT python=3.11 -y
conda activate IJTT
```

以下のコマンドを実行
```
bash dev-init.sh
```

### スクリプトによる `MySQL` の更新 (スキップ可)

`MySQL` でテーブルの構造を更新するには、以下のコマンドを使用します。
`<script_name>` を実行したいSQLスクリプトの名前に置き換えてください。
更新しない場合は、このステップをスキップできます。

```bash
Get-Content ./api/src/mysql/scripts/<script_name>.sql | docker exec -i aviary-lite-mysql-1 mysql -u aviaryAdmin -pav1aRy@adm1n aviary-db
```

## `.env` `config` ファイルについて

> ![NOTE]
> `.env` ファイルを作成した後は、必要に応じて各自の環境に合わせて内容を編集してください。
> `OLLAMA_MODEL=` の行には、自分のローカルの Ollama に実在のモデルを名前をに切り替えて下さい、
> 又は、`ollama pull qwen2.5:3b` のコメントを使用して、モデルをインストールして下さい。
>
> nvidiaのGPUの無い環境の場合、`config`の `throwErrorWhenCUDAUnavailable` をfalseに設定してください


## 起動方法

```bash
# 1. 先ずは MySQL と Redis が起動しているかどうかを確認
docker-compose ps
# 起動していない場合は、以下のコマンドで起動
docker compose up -d

# 2. API を起動
cd api
pnpm dev
# API をデバッグモードで起動したい場合は
# ./api/package.json の scripts セクションの DEBUG ボタンをクリックしてください
# その後、dev を選択し、実行してください

# 3. RAG を起動
cd rag
# conda で環境を作成している場合は、以下のコマンドで環境をアクティベートしてください
conda activate IJTT
# その後、以下のコマンドで RAG を起動してください
python main.py

# 4. UI を起動
cd ui
pnpm dev
```

## SSO 登录

http://localhost:7000/login?sso=true

## RAGの切り替えについて
`config/default.yml`内の`RAG.mode`を書き換えてください
10/2現在、モードごとにファイルの再アップロードが必要です

## RAGの追加について
mode_nameを付けてください
下記の2ファイルのみの追加で動作します。
### `api`への追加
`api/src/types/ragProcessor.ts`のルールに従って、<mode_name>.tsファイルを`api/src/ragclass`に追加してください
### `rag`への追加
<mode_name>_api.pyファイルを`rag/api/modeAPI`に追加してください
(pythonからsolrのデータ取得は`rag/utils/solr.py`の`get_solr_doc_by_id`で可能です。)
#### `api/src/types/ragProcessor.ts`の内容
```
export type UploadedFile = {
    newFilename: string;
    originalFilename: string;
    mimetype: string;
    size: number;
    filepath: string;
};

export type UploadResult = {
  result: {
    id: number;
    filename: string;
    storage_key: string;
    mime_type: string;
    size: number;
    created_at: Date;
  };
  status: 'fulfilled' | 'rejected';
};

export interface RAGProcessor {
  upload(file: UploadedFile, tagsIdList: number[], userName: string): Promise<UploadResult> | { result, status };
  search(prompt: string): Promise<string> | string;
}
```
