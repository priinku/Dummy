export default {
  title: import.meta.env.VITE_APP_TITLE,

  sideTheme: "theme-dark",

  showSettings: true,

  topNav: false,

  tagsView: true,

  fixedHeader: false,

  sidebarLogo: true,

  dynamicTitle: false,

  errorLog: "production",
};
