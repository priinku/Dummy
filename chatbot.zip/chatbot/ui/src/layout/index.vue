<template>
  <div :class="classObj" class="app-wrapper" :style="{ '--current-color': theme }">
    <div v-if="device === 'mobile' && sidebar.opened" class="drawer-bg" @click="handleClickOutside" />
    <!-- 側邊欄已被註釋掉 -->
    <!-- <sidebar v-if="!sidebar.hide" class="sidebar-container" /> -->
    <div :class="{ 
      hasTagsView: needTagsView, 
      sidebarHide: sidebar.hide,
      'main-collapsed': !sidebar.opened 
    }" class="main-container">
      <div :class="{ 'fixed-header': fixedHeader }">
        <!-- 頂部導航欄已被註釋掉 -->
        <!-- <navbar @setLayout="setLayout" /> -->
      </div>
      <app-main />
      <settings ref="settingRef" />
    </div>
  </div>
</template>

<script setup>
import { AppMain, Navbar } from "./components";
import Sidebar from "./components/Sidebar/index.vue";
import useAppStore from "@/store/modules/app";
import useSettingsStore from "@/store/modules/settings";

const settingsStore = useSettingsStore();
const theme = computed(() => settingsStore.theme);
const sidebar = computed(() => useAppStore().sidebar);
const device = computed(() => useAppStore().device);
const needTagsView = computed(() => settingsStore.tagsView);
const fixedHeader = computed(() => settingsStore.fixedHeader);

const classObj = computed(() => ({
  openSidebar: sidebar.value.opened,
  withoutAnimation: sidebar.value.withoutAnimation,
  mobile: device.value === "mobile",
}));

function handleClickOutside() {
  useAppStore().closeSideBar({ withoutAnimation: false });
}

const settingRef = ref(null);
function setLayout() {
  settingRef.value.openSetting();
}
</script>

<style lang="scss" scoped>
@import "@/assets/styles/mixin.scss";
@import "@/assets/styles/variables.module.scss";

.app-wrapper {
  @include clearfix;
  position: relative;
  height: 100%;
  width: 100%;
  overflow-y: scroll; 
  scrollbar-gutter: stable; 

  &.mobile.openSidebar {
    position: fixed;
    top: 0;
  }
}

.drawer-bg {
  background: #000;
  opacity: 0.3;
  width: 100%;
  top: 0;
  height: 100%;
  position: absolute;
  z-index: 999;
}

.main-container {
  min-height: 100vh;
  margin-left: 0; /* 調整為0，避免留出側邊欄空間 */
  transition: margin-left 0.3s;
  position: relative;

  &.main-collapsed {
    margin-left: 0; /* 調整為0，避免留出側邊欄空間 */
  }
}

.fixed-header {
  position: fixed;
  top: 0;
  right: 0;
  z-index: 9;
  width: 100%; /* 調整為100%，避免留出側邊欄空間 */
  transition: width 0.28s;

  .main-collapsed & {
    width: 100%; /* 調整為100%，避免留出側邊欄空間 */
  }
}

.hideSidebar .fixed-header {
  width: 100%;
}

.sidebarHide .fixed-header {
  width: 100%;
}

.mobile .fixed-header {
  width: 100%;
}

// 處理 mobile 狀態
.mobile {
  .main-container {
    margin-left: 0;
  }

  .sidebar-container {
    width:  $base-sidebar-width;;
    transition: transform .3s;

    &.collapsed {
      width: $base-sidebar-width-collapsed;
    }
  }

  &.openSidebar {
    .sidebar-container {
      transform: translate3d(0, 0, 0);
    }
  }
}
</style>