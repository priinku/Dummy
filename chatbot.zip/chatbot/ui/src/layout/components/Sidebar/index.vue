<template>
  <div class="sidebar-container" :class="{ collapsed: isCollapse }">
    <div
      class="sidebar-content"
      :class="{ 'has-logo': showLogo }"
      :style="{
        backgroundColor:
          sideTheme === 'theme-dark'
            ? variables.menuBackground
            : variables.menuLightBackground,
      }"
    >
      <el-scrollbar :class="sideTheme" wrap-class="scrollbar-wrapper">
        <el-menu
          :default-active="activeMenu"
          :collapse="isCollapse"
          :background-color="
            sideTheme === 'theme-dark'
              ? variables.menuBackground
              : variables.menuLightBackground
          "
          :text-color="
            sideTheme === 'theme-dark'
              ? variables.menuColor
              : variables.menuLightColor
          "
          :unique-opened="true"
          active-text-color="#409EFF"
          :collapse-transition="false"
          @select="handleSelect"
          mode="vertical"
          class="custom-menu"
        >
          <sidebar-item
            v-for="(route, index) in constantRoutes"
            :key="route.path + index"
            :item="route"
            :base-path="route.path"
          />
        </el-menu>
      </el-scrollbar>

      <div class="user-info">
        <el-dropdown
          @command="handleCommand"
          class="right-menu-item hover-effect"
          trigger="click"
        >
          <div class="user-profile">
            <img
              :src="userStore.avatar"
              class="user-avatar"
            />
            <div
              v-show="!isCollapse"
              class="user-details"
            >
              <div class="user-name">
                {{ userStore.nickName }}
              </div>
              <div class="user-handle">
                @{{ userStore.name }}
              </div>
            </div>
          </div>
          <template #dropdown>
            <el-dropdown-menu class="custom-dropdown">
              <el-dropdown-item divided command="logout">
                <span>ログアウト</span>
              </el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </div>

    <div class="collapse-button" @click="toggleSidebar">
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 1024 1024"
        :class="{ 'is-collapsed': isCollapse }"
      >
        <path
          fill="currentColor"
          d="M340.864 149.312a30.592 30.592 0 0 0 0 42.752L652.736 512 340.864 831.872a30.592 30.592 0 0 0 0 42.752 29.12 29.12 0 0 0 41.728 0L714.24 534.336a32 32 0 0 0 0-44.672L382.592 149.376a29.12 29.12 0 0 0-41.728 0z"
        ></path>
      </svg>
    </div>
  </div>
</template>

<script setup>
import variables from "@/assets/styles/variables.module.scss";
import useAppStore from "@/store/modules/app";
import useSettingsStore from "@/store/modules/settings";
import useUserStore from "@/store/modules/user";
import { ElMessageBox } from "element-plus";
import SidebarItem from "./SidebarItem";
import { onMounted } from "vue";
import { constantRoutes } from "@/router";

const route = useRoute();
const appStore = useAppStore();
const settingsStore = useSettingsStore();
const userStore = useUserStore();

onMounted(() => {
  appStore.sidebar.opened = false;
  window.visualViewport?.addEventListener("resize", handleViewportResize);
});

onBeforeUnmount(() => {
  window.visualViewport?.removeEventListener("resize", handleViewportResize);
});

function handleViewportResize() {
  document.documentElement.style.setProperty('--vh', `${window.innerHeight * 0.01}px`);
}

const showLogo = computed(() => settingsStore.sidebarLogo);
const sideTheme = computed(() => settingsStore.sideTheme);
const theme = computed(() => settingsStore.theme);
const isCollapse = computed(() => !appStore.sidebar.opened);

const activeMenu = computed(() => {
  const { meta, path } = route;
  if (meta.activeMenu) {
    return meta.activeMenu;
  }
  return path;
});

function toggleSidebar() {
  appStore.sidebar.opened = !appStore.sidebar.opened;
}

function handleSelect() {
  setTimeout(() => {
    appStore.sidebar.opened = false;
  }, 150);
}

function handleCommand(command) {
  switch (command) {
    case "logout":
      logout();
      break;
    default:
      break;
  }
}

function logout() {
  ElMessageBox.confirm(
    "システムからログアウトし、退出しますか？",
    "ログアウト",
    {
      confirmButtonText: "ログアウト",
      cancelButtonText: "キャンセル",
      type: "warning",
    }
  )
    .then(() => {
      userStore.logOut().then(() => {
        location.href = "/chat";
      });
    })
    .catch(() => {});
}
</script>

<style lang="scss" scoped>
.sidebar-container {
  position: relative;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  overscroll-behavior: none;
  -webkit-overflow-scrolling: auto;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  height: 0;
  &.collapsed {
    .sidebar-content {
      width: 64px;
    }

    .collapse-button {
      left: 64px;
    }
  }
}

.el-scrollbar {
  overscroll-behavior: contain;
  background: linear-gradient(180deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0) 100%);
}

.sidebar-content {
  width: 240px;
  height: 100vh;
  position: fixed;
  bottom: 0;
  left: 0;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  z-index: 1000;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  backdrop-filter: blur(10px);
  border-radius: 0 12px 12px 0;
}

.custom-menu {
  border-right: none !important;
  
  :deep(.el-menu-item) {
    height: 50px;
    line-height: 50px;
    margin: 4px 0;
    border-radius: 8px;
    
    &:hover {
      background-color: rgba(255, 255, 255, 0.1) !important;
    }
    
    &.is-active {
      background: linear-gradient(90deg, #409EFF 0%, rgba(64, 158, 255, 0.5) 100%);
      box-shadow: 0 2px 8px rgba(64, 158, 255, 0.3);
    }
  }
}

.collapse-button {
  position: fixed;
  left: 240px;
  top: 50%;
  transform: translateY(-50%);
  width: 24px;
  height: 60px;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(5px);
  border-radius: 0 8px 8px 0;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  z-index: 999;
  box-shadow: 4px 0 16px rgba(0, 0, 0, 0.1);

  svg {
    width: 16px;
    height: 16px;
    transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    color: #409EFF;
    transform: rotate(180deg);

    &.is-collapsed {
      transform: rotate(0deg);
    }
  }

  &:hover {
    background: rgba(255, 255, 255, 1);
    width: 28px;
  }
}

.user-info {
  padding: 16px 0px;
  background: #001e60;
  backdrop-filter: blur(10px);
  margin-top: auto;
}

.user-profile {
  cursor: pointer;
  display: flex;
  gap: 12px;
  align-items: center;
  padding: 8px;
  border-radius: 12px;
  transition: all 0.3s;
  
  &:hover {
    background: rgba(255, 255, 255, 0.1);
  }
}

.user-avatar {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  border: 2px solid rgba(255, 255, 255, 0.2);
  transition: all 0.3s;
  
  &:hover {
    border-color: #409EFF;
  }
}

.user-details {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.user-name {
  color: #ffffff;
  font-size: 16px;
  font-weight: 500;
}

.user-handle {
  color: rgba(255, 255, 255, 0.7);
  font-size: 14px;
}

.custom-dropdown {
  :deep(.el-dropdown-menu__item) {
    padding: 12px 20px;
    
    &:hover {
      background-color: rgba(64, 158, 255, 0.1);
      color: #409EFF;
    }
  }
}
</style>
