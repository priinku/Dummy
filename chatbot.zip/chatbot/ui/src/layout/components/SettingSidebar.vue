<template>
  <div class="settings-sidebar">
    <!-- サイドバー部分 -->
    <div class="sidebar">
      <div class="home-button">
            <el-button type="primary" icon="Back" @click="navigateToHome"></el-button>
      </div>
      <div class="sidebar-header">
        <h2 class="sidebar-title">設定</h2>
      </div>
      <div class="sidebar-link-area">  
        <el-menu
          :router="true"
          :default-active="$route.path"
          class="el-menu"
        >
          <el-menu-item index="/settings/user">ユーザー管理</el-menu-item>
          <el-menu-item index="/settings/model">モデル管理</el-menu-item>
          <el-menu-item index="/settings/other">その他</el-menu-item>
        </el-menu>
      </div>
    </div>
    
    <!-- メインコンテンツ部分 -->
    <main class="main-content">
      <router-view />
    </main>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router';

const router = useRouter();

function navigateToHome() {
  router.push('/home');
}
</script>

<style scoped>
.settings-sidebar {
  display: flex;
  height: 100vh;
}

h2.sidebar-title {
  color: #ffffff;
  font-size: 48px;
  margin-top: 0;
}

.sidebar-header {
  display: flex;
  align-items: center;
  padding-top: 10px;
}

.sidebar {
  background-color: #002357;
  height: 100%;
  max-width: 20%;
  min-width: 250px;
  opacity: 0.95;
  overflow-x: hidden;
  box-sizing: border-box;
  padding: 20px;
}

.sidebar-link-area {
  font-size: 24px;
  padding-top: 0px;
  padding: 20px;
}

.el-menu {
  border-right: none !important;
  box-shadow: none !important;
  background-color: #002357;
}

/* メニューアイテムの基本スタイル */
.el-menu-item {
  color: #15bcda !important;
  font-size: 24px !important;
  background-color: transparent !important;
}

/* メニューアイテムのホバー状態 */
.el-menu-item:hover {
  background-color: rgba(21, 188, 218, 0.2) !important;
  color: #ffffff !important;
}

/* アクティブなメニューアイテム */
.el-menu-item.is-active {
  background-color: #00d9ffaa !important;
  color: #002357 !important;
  font-weight: bold !important;
}

.main-content {
  flex: 1;
  padding: 2rem;
  background: #fefefc;
  padding-top: 40px;
}

.home-button-fixed {
  position: fixed;
  top: 10px;
  left: 20px;
  z-index: 1000;
}
</style> 