<template>
  <div class="input-node">
    <Handle type="source" position="right" />

    <strong>🟢 输入</strong>
  </div>
</template>

<script setup lang="ts">
import { reactive } from "vue";
import { Handle } from "@vue-flow/core";

const emit = defineEmits(["update"]);
const props = defineProps<{ id: string; data: { text?: string } }>();

const localData = reactive({
  text: props.data.text || "",
});

function emitUpdate() {
  emit("update", { ...localData });
}
</script>

<style scoped>
.input-node {
  background-color: #d1fae5;
  border: 1px solid #10b981;
  padding: 10px;
  border-radius: 8px;
  width: 200px;
  font-size: 14px;
  position: relative;
}
.field {
  display: flex;
  flex-direction: column;
}
input {
  padding: 4px 6px;
  font-size: 13px;
  border: 1px solid #d1d5db;
  border-radius: 4px;
}
</style>
