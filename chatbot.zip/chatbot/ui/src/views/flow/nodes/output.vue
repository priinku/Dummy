<template>
  <div class="output-node">
    <Handle type="target" position="left" />
    <strong>🔴 输出</strong>
  </div>
</template>

<script setup lang="ts">
import { Handle } from "@vue-flow/core";
defineProps<{ id: string; data: { text?: string } }>();
</script>

<style scoped>
.output-node {
  background-color: #fee2e2;
  border: 1px solid #ef4444;
  padding: 10px;
  border-radius: 8px;
  width: 200px;
  font-size: 14px;
  position: relative;
}
.result {
  margin-top: 6px;
  font-weight: bold;
  word-break: break-all;
}
</style>
