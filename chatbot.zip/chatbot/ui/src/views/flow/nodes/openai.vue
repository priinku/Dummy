<template>
  <div class="openai-node">
    <Handle type="target" position="left" id="input" />
    <Handle type="source" position="right" id="output" />

    <strong>🤖 OpenAI</strong>

    <div class="field">
      <label>Model</label>
      <select v-model="localData.model" @change="emitUpdate">
        <option value="gpt-3.5-turbo">gpt-3.5-turbo</option>
        <option value="gpt-4o">gpt-4o</option>
      </select>
    </div>

    <div class="field">
      <label>API Key</label>
      <input
        type="password"
        v-model="localData.apiKey"
        placeholder="可选：自定义 API Key"
        @input="emitUpdate"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { reactive } from "vue";
import { Handle } from "@vue-flow/core";

const emit = defineEmits(["update"]);
const props = defineProps<{
  id: string;
  data: {
    model?: string;
    apiKey: string;
  };
}>();

const localData = reactive({
  model: props.data.model || "gpt-3.5-turbo",
  apiKey: props.data.apiKey,
});

function emitUpdate() {
  emit("update", { ...localData });
}
</script>

<style scoped>
.openai-node {
  background-color: #fef3c7;
  border: 1px solid #facc15;
  padding: 10px;
  border-radius: 8px;
  font-size: 14px;
  width: 220px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  position: relative;
}

.field {
  display: flex;
  flex-direction: column;
}

input,
select {
  padding: 4px 6px;
  font-size: 13px;
  border: 1px solid #d1d5db;
  border-radius: 4px;
  background-color: white;
}
</style>
