<template>
  <div class="flow-editor-container">
    <div class="toolbar">
      <input
        v-model="name"
        placeholder="请输入流程名称"
        class="flow-name-input"
      />
      <button @click="save" class="save-button">保存</button>
      <button @click="emit('callHandleShowEditor')" class="save-button">
        取消
      </button>
      <button @click="handleExecute" class="save-button">执行</button>
    </div>

    <div class="main-content">
      <div class="sidebar">
        <div
          class="sidebar-item"
          v-for="type in nodeTypesList"
          :key="type.type"
          :draggable="true"
          @dragstart="onDragStart($event, type)"
        >
          {{ type.label }}
        </div>
      </div>

      <VueFlow
        v-model:nodes="nodes"
        v-model:edges="edges"
        :onConnect="handleConnect"
        :fit-view="true"
        :node-types="nodeTypes"
        class="flow-canvas"
        @connect="handleConnect"
        @drop="onDrop"
        @dragover="onDragOver"
      >
        <Background />
        <Controls />

        <template #node-openai="{ id, data }">
          <div @contextmenu="(e) => showContextMenu(e, id)">
            <OpenAINode
              :id="id"
              :data="data"
              @update="onUpdateNodeData(id, $event)"
            />
          </div>
        </template>
        <template #node-input="{ id, data }">
          <div @contextmenu="(e) => showContextMenu(e, id)">
            <InputNode
              :id="id"
              :data="data"
              @update="onUpdateNodeData(id, $event)"
            />
          </div>
        </template>

        <template #node-output="{ id, data }">
          <div @contextmenu="(e) => showContextMenu(e, id)">
            <OutputNode
              :id="id"
              :data="data"
              @update="onUpdateNodeData(id, $event)"
            />
          </div>
        </template>
      </VueFlow>

      <el-dialog :title="title" v-model="open" width="500px" append-to-body>
        <el-input v-model="input" placeholder="" maxlength="200" />

        <template #footer>
          <div class="dialog-footer">
            <el-button type="primary" @click="execute">確定</el-button>
            <el-button @click="cancel">取り消す</el-button>
          </div>
        </template>
      </el-dialog>
    </div>
  </div>
  <div
    v-if="contextMenu.visible"
    :style="{ top: contextMenu.y + 'px', left: contextMenu.x + 'px' }"
    class="context-menu"
    @click="deleteContextNode"
  >
    🗑 删除节点
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch, getCurrentInstance } from "vue";
import {
  VueFlow,
  useVueFlow,
  applyNodeChanges,
  applyEdgeChanges,
} from "@vue-flow/core";
import { Background } from "@vue-flow/background";
import { Controls } from "@vue-flow/controls";
import OpenAINode from "./nodes/openai.vue";
import InputNode from "./nodes/input.vue";
import OutputNode from "./nodes/output.vue";
import { saveFlow, executeFlow } from "@/api/flow";

import "@vue-flow/core/dist/style.css";
import "@vue-flow/core/dist/theme-default.css";

const {
  addNodes,
  addEdges,
  onNodesChange,
  onEdgesChange,
  updateNode,
  setNodes,
  setEdges,
} = useVueFlow();
const { proxy } = getCurrentInstance();

const open = ref(false);
const emit = defineEmits(["callHandleShowEditor"]);
const props = defineProps<{
  flowId: string;
  flowName: string;
  jsonSchema: string;
}>();

const name = ref("Untitled Flow");
const nodeIdCounter = ref(100);
const input = ref("");

const nodeTypes = {
  openai: OpenAINode,
  input: InputNode,
  output: OutputNode,
};

const nodeTypesList = [
  { type: "input", label: "🟢 输入节点" },
  { type: "openai", label: "🤖 OpenAI 节点" },
  { type: "output", label: "🔴 输出节点" },
];

const nodes = ref([]);
const edges = ref([]);

const contextMenu = reactive({
  visible: false,
  x: 0,
  y: 0,
  nodeId: null as string | null,
});

function handleExecute() {
  input.value = "";
  open.value = true;
  title.value = "执行";
}

function cancel() {
  open.value = false;
}

function showContextMenu(event: MouseEvent, nodeId: string) {
  event.preventDefault();
  contextMenu.visible = true;
  contextMenu.x = event.clientX;
  contextMenu.y = event.clientY;
  contextMenu.nodeId = nodeId;
}

function deleteContextNode() {
  if (contextMenu.nodeId) {
    const id = contextMenu.nodeId;
    setNodes((nds) => nds.filter((n) => n.id !== id));
    setEdges((eds) => eds.filter((e) => e.source !== id && e.target !== id));
    contextMenu.visible = false;
  }
}

window.addEventListener("click", () => {
  contextMenu.visible = false;
});

onMounted(() => {
  console.log("onMounted start");

  onNodesChange((changes) => setNodes((nds) => applyNodeChanges(changes, nds)));
  onEdgesChange((changes) => setEdges((eds) => applyEdgeChanges(changes, eds)));

  console.log(props.jsonSchema);

  if (props.jsonSchema) {
    const parsed = JSON.parse(props.jsonSchema);
    nodes.value = parsed.nodes || [];
    edges.value = parsed.edges || [];
  }
});

const onDragStart = (event: DragEvent, nodeType: any) => {
  event.dataTransfer?.setData("application/node-type", nodeType.type);
  event.dataTransfer!.effectAllowed = "move";
};

const onDragOver = (event: DragEvent) => {
  event.preventDefault();
  event.dataTransfer!.dropEffect = "move";
};

const onDrop = (event: DragEvent) => {
  event.preventDefault();
  const type = event.dataTransfer?.getData("application/node-type");
  if (!type) return;

  const bounds = (event.currentTarget as HTMLElement).getBoundingClientRect();
  const position = {
    x: event.clientX - bounds.left,
    y: event.clientY - bounds.top,
  };

  const newId = `${type}-${nodeIdCounter.value++}`;
  const newNode = {
    id: newId,
    type,
    position,
    data: getDefaultNodeData(type),
  };
  nodes.value.push(newNode);
};

const getDefaultNodeData = (type: string) => {
  switch (type) {
    case "input":
      return { text: "hello" };
    case "openai":
      return { prompt: "", model: "gpt-3.5-turbo", apiKey: "" };
    case "output":
      return { text: "" };
    default:
      return {};
  }
};

function handleConnect({ source, target, sourceHandle, targetHandle }) {
  const sourceNode = nodes.value.find((n) => n.id === source);
  const targetNode = nodes.value.find((n) => n.id === target);

  let flag;

  if (sourceNode.type === "openai" && targetNode.type === "output") {
    flag = true;
  }

  if (sourceNode.type === "input" && targetNode.type === "openai") {
    flag = true;
  }

  if (flag) {
    if (!edges.value.find((e) => e.source === source && e.target === target)) {
      edges.value.push({
        id: `e${source}-${target}`,
        source,
        target,
        targetHandle,
      });
    }
    return true;
  }

  return false;
}

const onUpdateNodeData = (nodeId: string, data: any) => {
  updateNode(nodeId, (node) => {
    node.data = { ...node.data, ...data };
  });
};

const exportFlowToSchema = (nodes, edges) => {
  return {
    nodes: nodes.map((node) => ({
      id: node.id,
      type: node.type,
      data: node.data,
      position: node.position,
    })),
    edges: edges.map((edge) => ({ source: edge.source, target: edge.target })),
  };
};

const save = async () => {
  const payload = exportFlowToSchema(nodes.value, edges.value);
  const basePayload = {
    name: name.value.trim() || "Untitled Flow",
    jsonSchema: JSON.stringify(payload),
  };
  const promise = props.flowId
    ? saveFlow({ id: props.flowId, ...basePayload })
    : saveFlow(basePayload);
  await promise;
  proxy.$modal.msgSuccess("保存成功");
};

const execute = async () => {
  executeFlow({ flowId: props.flowId, input: { text: input.value } });
};

watch(
  () => props.flowName,
  (flowName) => {
    if (flowName) name.value = flowName;
  },
  { immediate: true }
);

watch(
  () => props.jsonSchema,
  (jsonSchema) => {
    if (jsonSchema) {
      const parsed = JSON.parse(jsonSchema);
      nodes.value = parsed.nodes || [];
      edges.value = parsed.edges || [];
    }
  },
  { immediate: true }
);
</script>

<style scoped lang="scss">
.flow-editor-container {
  width: 100vw;
  height: 100vh;
  background-color: #f3f4f6;
  display: flex;
  flex-direction: column;
}
.toolbar {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px;
  background-color: #ffffff;
  border-bottom: 1px solid #e5e7eb;
}
.flow-name-input {
  width: 60%;
  padding: 6px 12px;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  font-size: 14px;
}
.save-button {
  padding: 6px 16px;
  background-color: #3b82f6;
  color: white;
  border: none;
  border-radius: 6px;
  font-weight: 500;
  cursor: pointer;
}
.save-button:hover {
  background-color: #2563eb;
}
.main-content {
  display: flex;
  flex: 1;
  overflow: hidden;
}
.sidebar {
  width: 160px;
  background-color: #ffffff;
  border-right: 1px solid #e5e7eb;
  padding: 10px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.sidebar-item {
  padding: 8px 12px;
  background-color: #f9fafb;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  cursor: grab;
  user-select: none;
}
.sidebar-item:hover {
  background-color: #f3f4f6;
}
.flow-canvas {
  flex: 1;
}
.context-menu {
  position: fixed;
  background: white;
  border: 1px solid #ccc;
  padding: 6px 12px;
  border-radius: 4px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  font-size: 14px;
  z-index: 9999;
  cursor: pointer;
}
.context-menu:hover {
  background-color: #fef2f2;
}
</style>
