<template>
  <div class="app-container" v-show="!showEditor">
    <div class="top-nav">
      <div class="logo-area" @click="navigateToHome">
        <el-button type="primary" icon="Back"></el-button>
      </div>
    </div>
    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button type="primary" plain icon="Plus" @click="handleShowEditor">
          追加
        </el-button>
      </el-col>
    </el-row>
    <el-table
      row-key="id"
      v-loading="loading"
      :data="flowList"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column
        label="流程名称"
        align="center"
        prop="name"
        :show-overflow-tooltip="true"
      />
      <el-table-column
        label="作成時間"
        align="center"
        prop="createTime"
        width="180"
      >
        <template #default="scope">
          <span>{{ parseTime(scope.row.createdAt) }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="操作"
        align="center"
        width="160"
        class-name="small-padding fixed-width"
      >
        <template #default="scope">
          <!-- <el-button link type="primary" @click="showDialog = !showDialog">
            チャット
          </el-button> -->
          <el-button link type="primary" @click="handleShowEditor(scope.row)">
            変更
          </el-button>
          <el-button link type="primary" @click="handleDelete(scope.row)">
            削除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
  <div v-show="showEditor">
    <Editor
      :flowId="flowId"
      :flowName="flowName"
      :jsonSchema="jsonSchema"
      @callHandleShowEditor="handleShowEditor"
    />
  </div>
</template>

<script setup name="Config">
import { listFlow, saveFlow, deleteFlow } from "@/api/flow";
import { ref, reactive, toRefs, getCurrentInstance } from "vue";
import Editor from "./editor";
import { useRouter } from 'vue-router';
const router = useRouter();
const { proxy } = getCurrentInstance();

const showEditor = ref(false);
const flowId = ref("");
const flowName = ref("");
const jsonSchema = ref("");

const flowList = ref([]);
const open = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const total = ref(0);
const dateRange = ref([]);

const data = reactive({
  form: { file: null, flowList: [] },
  queryParams: {
    pageNum: 1,
    pageSize: 100,
  },
});

const { queryParams, form, rules } = toRefs(data);

/** 查询参数列表 */
function getList() {
  loading.value = true;
  listFlow(queryParams.value).then((response) => {
    flowList.value = response.result.rows;
    total.value = response.result.count;
    loading.value = false;
  });
}

function handleShowEditor(e) {
  showEditor.value = !showEditor.value;
  if (e) {
    flowId.value = e.id;
    flowName.value = e.name;
    jsonSchema.value = e.jsonSchema;
  } else {
    flowId.value = "";
    jsonSchema.value = "";
  }
  getList();
}

function handleDelete(row) {
  const flowId = row.id;
  proxy.$modal
    .confirm('流程"' + row.name + '"のデータ項目を削除してもよろしいですか？')
    .then(function () {
      return deleteFlow({ flowId });
    })
    .then(() => {
      getList();
      proxy.$modal.msgSuccess("削除成功");
    })
    .catch(() => {});
}

function navigateToHome() {
  router.push('/home');
}

getList();
</script>

<style lang="scss" scoped>
.top-nav {
  display: flex;
  justify-content: space-between;
  align-items: center;

  .logo-area {
    cursor: pointer;
  }
}
</style>
