<template>
  <div class="file-management-container">
    <!-- 頂部導航和LOGO -->
    <div class="top-nav">
      <div class="logo-area" @click="navigateToHome">
        <el-button type="primary" icon="Back"></el-button>
      </div>
    </div>

    <div class="content-container">
      <!-- 左側區域：上傳按鈕、聊天導航和搜尋欄位 -->
      <div class="left-panel">
        <!-- 上傳區域 -->
        <div class="upload-section">
          <el-button type="primary" plain icon="Plus" @click="handleUpload">
            ファイルアップロード
          </el-button>
        </div>
        <!-- <div class="section upload-section">
          <el-button type="primary" plain icon="Plus" @click="handleUpload">
            ファイルアップロード
          </el-button>
          <el-button type="primary" @click="navigateToLocalchat" class="toLocalChat">
            ローカルチャットへ→
          </el-button>
        </div> -->

        <div class="section tag">
          <div class="collapse-header" @click="toggleTaskCollapse">
            <h4 class="section-title">ファイルアップロード状況
            </h4>
            <el-icon class="collapse-icon" :class="{ 'collapsed': !taskExpanded }">
              <ArrowDown />
            </el-icon>
          </div>

          <el-collapse-transition>
            <div v-show="taskExpanded" class="search-content">
                <!-- 表格頂部操作區域 -->
                <div class="table-header">
                  <div class="table-actions">
                    <el-button size="small" icon="refresh" @click="getUploadStatusList"></el-button>
                  </div>
                </div>
                <el-table v-loading="uploadStatusLoading" :data="uploadStatusList" table-layout="auto">
                  <el-table-column type="selection" width="55" align="center" />
                  <el-table-column label="状態" prop="status" width="66px">
                    <template #default="scope">
                      <span>{{ getStatus(scope.row.status) }}</span>
                    </template>
                  </el-table-column>
                  <el-table-column label="対象" prop="formData">
                    <template #default="scope">
                      <el-tooltip class="item" effect="light" placement="right">
                        <template #content>
                          <div v-html="scope.row.content"></div>
                        </template>
                        <span>{{ getName(scope.row.formData) }}</span>
                      </el-tooltip>

                    </template>
                  </el-table-column>
                  <el-table-column label="作成日時" prop="createdAt" width="82px">
                    <template #default="scope">
                      <span>{{ timeAgo(scope.row.createdAt) }}</span>
                    </template>
                  </el-table-column>
                </el-table>
            </div>
          </el-collapse-transition>
        </div>


        <!-- 搜尋與篩選區域 -->
        <div class="section search-filter-section">
          <!-- 可折疊標題 -->
          <div class="collapse-header" @click="toggleSearchCollapse">
            <h4 class="section-title">検索 & フィルター</h4>
            <el-icon class="collapse-icon" :class="{ 'collapsed': !searchExpanded }">
              <ArrowDown />
            </el-icon>
          </div>

          <!-- 可折疊內容 -->
          <el-collapse-transition>
            <div v-show="searchExpanded" class="search-content">
              <!-- 簡化搜尋表單 -->
              <div class="search-form">
                <el-form :model="queryParams" label-position="top">
                  <!-- 1. 檔案名 -->
                  <el-form-item label="ファイル名">
                    <el-input v-model="queryParams.fileName" placeholder="ファイル名を入力" clearable
                      @keyup.enter="handleQuery">
                      <template #append>
                        <el-button icon="Search" @click="handleQuery"></el-button>
                      </template>
                    </el-input>
                  </el-form-item>

                  <el-form-item label="本文検索">
                    <el-input v-model="queryParams.fileContent" placeholder="本文" clearable>
                    </el-input>
                  </el-form-item>

                  <!-- 2. 時間（開始和結束分開） -->
                  <el-form-item label="期間">
                    <div class="date-inputs">
                      <el-date-picker v-model="startDate" type="date" placeholder="開始日" value-format="YYYY/MM/DD"
                        class="date-picker" />
                      <span class="date-separator">〜</span>
                      <el-date-picker v-model="endDate" type="date" placeholder="終了日" value-format="YYYY/MM/DD"
                        class="date-picker" />
                    </div>
                  </el-form-item>

                  <!-- 3. 上傳用戶 -->
                  <el-form-item label="作成者">
                    <el-input v-model="queryParams.create_by" placeholder="作成者を入力" clearable />
                  </el-form-item>

                  <!-- 4. 管理標籤 -->
                  <el-form-item label="管理タグ">
                    <el-select v-model="queryParams.tags" multiple clearable placeholder="タグを選択" style="width: 100%">
                      <el-option v-for="tag in tagOptions" :key="tag.id" :label="tag.name" :value="tag.id" />
                    </el-select>
                  </el-form-item>

                  <!-- 按鈕 -->
                  <el-form-item>
                    <div class="search-buttons">
                      <el-button type="primary" @click="handleQuery">検索</el-button>
                      <el-button @click="resetQuery">リセット</el-button>
                    </div>
                  </el-form-item>
                </el-form>
              </div>

              <!-- 應用的篩選條件摘要 -->
              <!-- <div v-if="hasActiveFilters" class="active-filters">
                <span class="filter-label">現在の条件:</span>
                <div class="filter-tags">
                  <el-tag v-if="queryParams.keyword" closable @close="queryParams.keyword = ''">
                    {{ queryParams.keyword }}
                  </el-tag>
                  <el-tag v-if="dateRange && dateRange.length" closable @close="clearDateRange">
                    {{ dateRange[0] }} 〜 {{ dateRange[1] }}
                  </el-tag>
                  <el-tag v-if="queryParams.uploader" closable @close="queryParams.uploader = ''">
                    {{ queryParams.uploader }}
                  </el-tag>
                  <el-tag v-for="tag in selectedTags" :key="tag" closable @close="removeTag(tag)">
                    {{ tag }}
                  </el-tag>
                </div>
              </div> -->
            </div>
          </el-collapse-transition>
        </div>

        <div class="section tag">
          <div class="collapse-header" @click="toggleTagCollapse">
            <h4 class="section-title">管理タグ
            </h4>
            <el-icon class="collapse-icon" :class="{ 'collapsed': !TagExpanded }">
              <ArrowDown />
            </el-icon>
          </div>

          <el-collapse-transition>
            <div v-show="TagExpanded" class="search-content">
              <div class="search-form">
                <el-form label-position="top">
                  <el-form-item label="タグ追加">
                    <el-input v-model="addTagName" placeholder="新しいタグ名を入力" clearable @keyup.enter="submitAddTag" />
                    <el-button icon="Plus" type="primary" @click="submitAddTag"></el-button>
                  </el-form-item>
                  <el-form-item label="タグ編集">
                    <el-select v-model="editTagId" placeholder="編集するタグを選択">
                      <el-option v-for="tag in tagOptions" :key="tag.id" :label="tag.name" :value="tag.id" />
                    </el-select>
                    <el-input v-model="editingTagName" placeholder="変更後のタグ名を入力" @keyup.enter="openEditTagDialog" />
                    <el-button icon="edit" type="primary" @click="openEditTagDialog"></el-button>
                  </el-form-item>
                  <el-form-item label="タグ削除">
                    <el-select v-model="deleteTagId" placeholder="削除するタグを選択" @keyup.enter="openDeleteTagDialog">
                      <el-option v-for="tag in tagOptions" :key="tag.id" :label="tag.name" :value="tag.id" />
                    </el-select>
                    <el-button icon="delete" type="primary" @click="openDeleteTagDialog"></el-button>
                  </el-form-item>
                </el-form>
              </div>

            </div>
          </el-collapse-transition>
        </div>
      </div>

      <!-- 右側區域：檔案列表 -->
      <div class="right-panel">
        <!-- 表格檢視 -->
        <div class="section results-section table-view">
          <!-- 表格頂部操作區域 -->
          <div class="table-header">
            <div class="table-title">
              <h3>ファイル管理</h3>
            </div>
            <!-- <div class="pagination-selector">
              <span class="pagination-label">表示件数:</span>
              <el-select v-model="queryParams.pageSize" @change="handleSizeChange" size="small" style="width: 80px">
                <el-option label="10" value="10"></el-option>
                <el-option label="20" value="20"></el-option>
                <el-option label="50" value="50"></el-option>
                <el-option label="100" value="100"></el-option>
              </el-select>
            </div> -->
            <div class="table-actions">
              <el-button size="small" icon="refresh" @click="handleReload"></el-button>
              <el-button size="small" icon="View" @click="handleBatchPreview" :disabled="single"></el-button>
              <el-button size="small" icon="Download" @click="handleBatchDownload" :disabled="single"></el-button>
              <el-button size="small" icon="Delete" type="danger" @click="handleDelete"
                :disabled="multiple"></el-button>
            </div>
          </div>

          <el-table v-loading="loading" :data="sortedData" @selection-change="handleSelectionChange"
            @sort-change="handleSortChange">
            <el-table-column type="selection" width="55" align="center" />
            <el-table-column label="ファイル名" prop="filename" :show-overflow-tooltip="true" sortable="custom" />
            <el-table-column label="アップロード日時" prop="createTime" width="180" sortable="custom">
              <template #default="scope">
                <span>{{ parseTime(scope.row.created_at) }}</span>
              </template>
            </el-table-column>
            <el-table-column label="作成者" prop="create_by" width="110" sortable="custom" />
            <el-table-column label="タグ" prop="tag" width="180" sortable="custom">
              <template #default="{ row }">
                <el-select v-model="row.tag" placeholder="タグを選択" @change="handleTagChange(row)" clearable
                  style="width: 150px">
                  <el-option v-for="tag in tagOptions" :key="tag.id" :label="tag.name" :value="tag.id" />
                </el-select>
              </template>
            </el-table-column>
            <!-- <el-table-column label="アクセス権限" prop="roles" width="200" sortable="custom">
              <template #default="{ row }">
                <el-select v-model="row.roles" placeholder="ロールを選択" @change="handleRoleChange(row)" multiple clearable style="width: 180px">
                  <el-option v-for="role in roleOptions" :key="role.role_id" :label="role.role_name" :value="role.role_id" />
                </el-select>
                デバッグ情報
                <div v-if="roleOptions.length === 0" style="color: red; font-size: 12px;">
                  ロールが読み込まれていません ({{ roleOptions.length }})
                </div>
              </template>
            </el-table-column> -->
          </el-table>

          <div class="pagination-container">
            <el-pagination v-if="total > 0" :current-page="queryParams.pageNum" :page-sizes="[3, 10, 20, 30, 50]"
              :page-size="queryParams.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="total"
              @size-change="handleSizeChange" @current-change="handleCurrentChange" />
          </div>
        </div>
      </div>
    </div>

    <!-- ファイルアップロードダイアログ -->
    <el-dialog :title="title" v-model="open" width="500px" append-to-body>
      <el-form ref="fileRef" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="ファイル" prop="file">
          <input ref="folderInput" type="file" webkitdirectory multiple style="display: none"
            @change="handleFolderChange" />
          <el-button @click="triggerFolderSelect">📁 フォルダ選択</el-button>
          <el-upload class="upload-demo" drag action="" multiple :auto-upload="false" :file-list="form.fileList"
            :on-change="handleFileChange" :on-remove="handleFileDelete">
            <i class="el-icon-upload"></i>
            <div class="el-upload__text">
              ここにファイルをドラッグまたはクリックで選択
            </div>
          </el-upload>
        </el-form-item>
        <!-- <el-form-item label="ファイル名" prop="filename">
          <el-input v-model="form.filename" placeholder="ファイル名を入力" />
        </el-form-item> -->

        <el-form-item label="タグ" prop="tags">
          <el-select v-model="form.tags" multiple :multiple-limit="1" clearable placeholder="タグを選択">
            <el-option v-for="tag in tagOptions" :key="tag.id" :label="tag.name" :value="tag.id" />
          </el-select>
        </el-form-item>

        <el-form-item label="アクセス権限" prop="roles">
          <el-select v-model="form.roles" multiple clearable placeholder="アクセス可能なロールを選択">
            <el-option v-for="role in roleOptions" :key="role.role_id" :label="role.role_name" :value="role.role_id" />
          </el-select>
          <div class="role-help-text">
            <small>選択したロールのユーザーのみがこのファイルにアクセスできます</small>
            <!-- デバッグ情報 -->
            <div v-if="roleOptions.length === 0" style="color: red; font-size: 12px;">
              ロールが読み込まれていません ({{ roleOptions.length }})
            </div>
          </div>
        </el-form-item>
      </el-form>

      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submitForm" :disabled="loading">確定</el-button>
          <el-button @click="cancel">キャンセル</el-button>
        </div>
      </template>
    </el-dialog>

    <el-dialog v-model="editConfirmDialogVisible" title="タグ変更の確認" width="400px">
      <div>タグ　{{ selectedEditTag }}　を　{{ editingTagName }}　に変更してもよろしいですか？</div>

      <template #footer>
        <el-button @click="editConfirmDialogVisible = false">キャンセル</el-button>
        <el-button type="danger" @click="submitEditTag">変更</el-button>
      </template>
    </el-dialog>

    <el-dialog v-model="deleteConfirmDialogVisible" title="タグ削除の確認" width="400px">
      <div>タグ　{{ selectedDeleteTag }}　を削除してもよろしいですか？</div>

      <template #footer>
        <el-button @click="deleteConfirmDialogVisible = false">キャンセル</el-button>
        <el-button type="danger" @click="submitDeleteTag">削除</el-button>
      </template>
    </el-dialog>

    <!-- アクセス権限編集ダイアログ -->
    <el-dialog v-model="roleDialogVisible" title="ファイルアクセス権限の編集" width="500px">
      <div>
        <p><strong>ファイル名:</strong> {{ selectedFile?.filename }}</p>
        <el-form label-position="top">
          <el-form-item label="アクセス可能なロール">
            <el-select v-model="editingRoles" multiple clearable placeholder="ロールを選択">
              <el-option v-for="role in roleOptions" :key="role.role_id" :label="role.role_name" :value="role.role_id" />
            </el-select>
            <div class="role-help-text">
              <small>選択したロールのユーザーのみがこのファイルにアクセスできます</small>
            </div>
          </el-form-item>
        </el-form>
      </div>

      <template #footer>
        <el-button @click="roleDialogVisible = false">キャンセル</el-button>
        <el-button type="primary" @click="submitRoleChange">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { listTask, listTaskOutput } from "@/api/task";
import { listFile, uploadFile, deleteFile, updateFileInfo, addNewTag, editTag, deleteTag, listTag, previewFile, downloadFile, getRolesFile, getRoles, getRolesUserBind, bindFileRole } from "@/api/file";
import { ref, reactive, toRefs, getCurrentInstance, computed, onMounted, onUnmounted } from 'vue';
import { useRouter } from 'vue-router';
import { ArrowDown } from '@element-plus/icons-vue';

const { proxy } = getCurrentInstance();
const router = useRouter();

// データ状態
const fileList = ref([]);
const open = ref(false);
const loading = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");
const dateRange = ref([]);
const viewMode = ref("table"); // デフォルトでテーブル表示を使用する
const activeCollapse = ref(['basicSearch']); // デフォルトで基本検索を開く
const startDate = ref('');
const endDate = ref('');
const taskExpanded = ref(false);
const searchExpanded = ref(false);
const TagExpanded = ref(false);
const editConfirmDialogVisible = ref(false);
const deleteConfirmDialogVisible = ref(false);
const addTagName = ref('');
const editTagId = ref('');
const editingTagName = ref('');
const selectedEditTag = ref('');
const deleteTagId = ref('');
const selectedDeleteTag = ref('');
const tagOptions = ref([]);
const folderInput = ref(null);
const roleOptions = ref([]);
const roleDialogVisible = ref(false);
const selectedFile = ref(null);
const editingRoles = ref([]);
const fileRoleMap = ref(new Map()); // 保存ファイルIDに対応するロールIDの配列

// フォームとクエリ用のデータ
const data = reactive({
  form: {
    file: null,
    fileList: [],
    tags: [],
    roles: []
  },
  queryParams: {
    pageNum: 1,
    pageSize: viewMode.value === 'card' ? 12 : 10,
    fileName: undefined,
    fileContent: undefined,
    create_by: undefined,
    tags: undefined,
    // sortBy: 'date',
    // sortOrder: 'desc'
  },
  rules: {
    fileList: [{ required: true, message: 'ファイルを選択してください', trigger: 'change' }]
  }
});

const type = ref("FILEUPLOAD");
const uploadStatusList = ref([]);
const uploadStatusLoading = ref(false);
const uploadStatusTotal = ref(0);
const uploadStatusQueryParams = reactive({
  pageNum: 1,
  pageSize: 10,
  type: type.value
});

const { queryParams, form, rules } = toRefs(data);

const sortField = ref('')
const sortOrder = ref('')
const sortedData = computed(() => {
  if (!sortField.value || !sortOrder.value) return fileList.value

  return [...fileList.value].sort((a, b) => {
    let valA = a[sortField.value]
    let valB = b[sortField.value]

    if (sortField.value === 'createTime') {
      valA = new Date(valA)
      valB = new Date(valB)
    }

    if (sortOrder.value === 'ascending') return valA > valB ? 1 : -1
    if (sortOrder.value === 'descending') return valA > valB ? -1 : 1
    return 0
  })
})
function handleSortChange({ prop, order }) {
  sortField.value = prop
  sortOrder.value = order
}

// 日付範囲クイックオプション
const dateRangeShortcuts = [
  {
    text: '最近の一週間',
    value: () => {
      const end = new Date();
      const start = new Date();
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
      return [start, end];
    },
  },
  {
    text: '最近1か月',
    value: () => {
      const end = new Date();
      const start = new Date();
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
      return [start, end];
    },
  },
  {
    text: '最近3か月',
    value: () => {
      const end = new Date();
      const start = new Date();
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
      return [start, end];
    },
  },
];

// 計算屬性
const hasActiveFilters = computed(() => {
  return queryParams.value.keyword ||
    (dateRange.value && dateRange.value.length) ||
    queryParams.value.uploader ||
    (queryParams.value.tags && queryParams.value.tags.length);
});

const selectedTags = computed(() => {
  return queryParams.value.tags || [];
});

// 方法
function getList() {
  loading.value = true;
  // 実際のAPI呼び出しにはすべてのクエリパラメータが含まれます
  listFile(proxy.addDateRange(queryParams.value, dateRange.value)).then((response) => {
    // console.log(response);
    fileList.value = response.result.rows;

    // 各ファイルのアクセスデータを初期化
    response.result.rows.forEach(file => {
      file.roles = []; // 初期化アクセス配列
    });

    const fileIdsString = response.result.rows.map(item => item.id).join(',')
    if (fileIdsString) {
      getRoles({fileIds: fileIdsString}).then((res) => {
        console.log('File roles:', res);
        // ファイルのロール権限データを処理する
        if (res.result && res.result.length > 0) {
          res.result.forEach(roleId => {
            // 実際のAPI返却形式に応じて調整が必要
            // 返却形式が {fileId: number, roleId: number} と仮定
            const fileId = roleId.file_id || roleId.fileId;
            const roleIdValue = roleId.role_id || roleId.roleId;
            
            if (!fileRoleMap.value.has(fileId)) {
              fileRoleMap.value.set(fileId, []);
            }
            fileRoleMap.value.get(fileId).push(roleIdValue);
            
            // ファイルオブジェクトのロールデータを同時に更新する
            const file = response.result.rows.find(f => f.id === fileId);
            if (file && !file.roles.includes(roleIdValue)) {
              file.roles.push(roleIdValue);
            }
            
            // 二つのロールが同時に存在するかどうかを確認し、存在する場合は 「both」 と表示する
            const fileRoles = fileRoleMap.value.get(fileId) || [];
            if (fileRoles.includes(1) && fileRoles.includes(2)) {
              file.roles = ['both'];
            }
          });
        }
      });
    }

    total.value = response.result.count;
    loading.value = false;
  });
}

async function getUploadStatusList() {
  uploadStatusLoading.value = true;
  const response = await listTask(uploadStatusQueryParams);
  const rows = response.result.rows;

  // 各IDごとにcontentを取得してマージ
  for (const row of rows) {
    const outputRes = await listTaskOutput({ pageNum: 1, pageSize: 1, taskId: row.id });
    const rawContent = outputRes.result.rows[0]?.content || '';

    let formatted = '';

    try {
      const parsed = JSON.parse(rawContent);
      const success = parsed.success ?? [];
      const failed = parsed.failed ?? [];
      const successText = `✅ 成功: ${success.length}件`;

      let failedText = '';
      if (failed.length > 0) {
        const listItems = failed.map(f => `<li>${f}</li>`).join('');
        failedText = `❌ 失敗(${failed.length}件):<ul>${listItems}</ul>`;
      } else {
        failedText = '❌ 失敗: なし';
      }

      formatted = `${successText}<br>${failedText}`;
    } catch (e) {
      formatted = rawContent;
    }
    row.content = formatted;
  }

  uploadStatusList.value = rows;
  uploadStatusTotal.value = response.result.count;
  uploadStatusLoading.value = false;
}

const getStatus = (status) => {
  switch (status) {
    case 'WAIT':
      return '待機中';
    case 'IN_PROCESS':
      return '処理中';
    case 'FINISHED':
      return '完了';
    case 'FAILED':
      return '失敗';
    case 'CANCEL':
      return 'キャンセル';
    default:
      return status;
  }
};

const getName = (formData) => {
  if (!formData) return '';
  try {
    const parsedData = JSON.parse(formData);
    const firstItem = parsedData.files[0].originalFilename;
    const count = parsedData.files.length - 1;
    return firstItem + (count > 0 ? ` 他${count}件` : '');
  } catch (error) {
    console.error("JSON解析エラー:", error);
    return formData; // 解析に失敗した場合は元の文字列を返す
  }
};

const timeAgo = (dateString) => {
  if (!dateString) return '-';

  const past = new Date(dateString);
  const now = new Date();
  const diffMs = now.getTime() - past.getTime();

  const sec = Math.floor(diffMs / 1000);
  if (sec < 60) return `${sec}秒前`;

  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}分前`;

  const hour = Math.floor(min / 60);
  if (hour < 24) return `${hour}時間前`;

  const day = Math.floor(hour / 24);
  if (day < 365) return `${day}日前`;

  const year = Math.floor(day / 365);  
  return `${year}年前`;
};

function getTagList() {
  loading.value = true;
  listTag().then((response) => {
    tagOptions.value = response.result.rows;
    loading.value = false;
  });
}

function getRoleList() {
  // ロールオプションの設定、組み合わせオプションを含む
  roleOptions.value = [
    { role_id: 1, role_name: 'admin' },
    { role_id: 2, role_name: 'sso' },
    { role_id: 'both', role_name: 'sso + admin' }
  ];
  
  // 原始API呼び出し（必要な場合）
  getRoles().then((response) => {
    console.log('Role list response:', response);
    if (response.result && response.result.rows) {
      // APIが返すロールに組み合わせオプションを追加
      const apiRoles = response.result.rows;
      apiRoles.push({ role_id: 'both', role_name: 'sso + admin (両方)' });
      roleOptions.value = apiRoles;
    }
  }).catch((error) => {
    console.error('Failed to load roles:', error);
    // APIが失敗した場合、手動設定のロールを使用
    console.log('Using manual role options');
  });
}

function getFileRoles(fileId) {
  return fileRoleMap.value.get(fileId) || [];
}

function getRoleName(roleId) {
  const role = roleOptions.value.find(r => r.role_id === roleId);
  return role ? role.role_name : 'Unknown';
}

function openRoleDialog(row) {
  selectedFile.value = row;
  editingRoles.value = getFileRoles(row.id);
  roleDialogVisible.value = true;
}

function submitRoleChange() {
  if (!selectedFile.value) return;
  
  // APIが失敗した場合、手動設定のロールを使用
  // 一時的に模擬データを使用
  fileRoleMap.value.set(selectedFile.value.id, [...editingRoles.value]);
  roleDialogVisible.value = false;
  proxy.$modal.msgSuccess('アクセス権限を更新しました');
}

function navigateToHome() {
  router.push('/home');
}

function hasSearchMatch(item) {
  // 検索条件に合致するかどうかの判定（ハイライト表示）
  if (!queryParams.value.keyword) return false;
  return item.filename.includes(queryParams.value.keyword);
}

function getMatchText(item) {
  // 一致する文字を取得して表示する
  if (queryParams.value.keyword) {
    return queryParams.value.keyword;
  }
  if (dateRange.value && dateRange.value.length) {
    const uploadDate = new Date(item.created_at);
    const month = uploadDate.getMonth() + 1;
    return `${month}月`;
  }
  return '';
}

function onTagChange(val) {
  form.value.tags = val ? [val] : [];
  console.log("Selected tags:", form.value.tags);
}

function handleQuery() {
  updateDateRange()
  queryParams.value.pageNum = 1;
  getList();
}

function resetQuery() {
  dateRange.value = [];
  startDate.value = '';
  endDate.value = '';
  // proxy.resetForm("queryRef");
  queryParams.value = {
    pageNum: 1,
    pageSize: viewMode.value === 'card' ? 12 : 10,
    fileName: undefined,
    fileContent: undefined,
    create_by: undefined,
    tags: undefined,
    // sortBy: 'date',
    // sortOrder: 'desc'
  };
  handleQuery();
}

function submitAddTag() {
  if (!addTagName.value || !addTagName.value.trim()) {
    proxy.$modal.msgError('タグ名を入力してください');
    return;
  }
  const formData = new FormData();
  formData.append("name", addTagName.value); // ← ここで "name" というキー名を使っているか？

  addNewTag(formData)
    .then((res) => {
      if (res.code === 200) {
        proxy.$modal.msgSuccess('タグを追加しました');
        getTagList();
        addTagName.value = '';
      } else {
        proxy.$modal.msgError(res.message || 'タグの追加に失敗しました');
      }
    })
    .catch(() => {
      proxy.$modal.msgError('エラーが発生しました');
    });
}


function handleTagChange(row) {
  updateFileInfo(row)
    .then(() => {
      proxy.$modal.msgSuccess('タグを更新しました');
    })
    .catch(() => {
      proxy.$modal.msgError('タグの更新に失敗しました');
    });
}

function handleRoleChange(row) {
  // ファイルの更新権限
  if (row.roles && row.roles.length > 0) {
    // 「both」オプションが選択されているかどうかを確認する
    if (row.roles.includes('both')) {
      // 「both」を選択した場合、設定は [1, 2] (admin + sso) となります。
      row.roles = [1, 2];
    }
    
    // 選択された各キャラクターにファイル関連付けを作成する
    const promises = row.roles.map(roleId => {
      return bindFileRole({
        roleId: roleId,
        fileId: row.id
      });
    });
    
    Promise.all(promises)
      .then(() => {
        proxy.$modal.msgSuccess('アクセス権限を更新しました');
        // ローカルデータの更新
        fileRoleMap.value.set(row.id, [...row.roles]);
      })
      .catch(() => {
        proxy.$modal.msgError('アクセス権限の更新に失敗しました');
      });
  } else {
    // キャラクターを選択しない場合、すべての権限を削除するか現状を維持するかを選択できます。
    proxy.$modal.msgInfo('権限が設定されていません');
  }
}

function openEditTagDialog() {
  if (!editTagId.value) {
    proxy.$modal.msgWarning("編集するタグを選択してください");
    return;
  }
  const tag = tagOptions.value.find(tag => tag.id === editTagId.value);
  selectedEditTag.value = tag.name;
  editConfirmDialogVisible.value = true;
}

function submitEditTag() {
  if (!editingTagName.value || !editingTagName.value.trim()) {
    proxy.$modal.msgError('変更後のタグ名を入力してください');
    return;
  }
  editConfirmDialogVisible.value = false;
  const formData = new FormData();
  formData.append("id", editTagId.value);
  formData.append("name", editingTagName.value);
  if (selectedEditTag.value === editingTagName.value) {
    proxy.$modal.msgWarning("同じタグ名です");
    return;
  } else {
    editTag(formData)
      .then(() => {
        proxy.$modal.msgSuccess('タグを編集しました');
        editTagId.value = ""
        selectedEditTag.value = ""
        editingTagName.value = ""
        getTagList();
      }).catch((err) => {
        proxy.$modal.msgError(err.message || 'タグの編集に失敗しました');
      })
  }
}

function openDeleteTagDialog() {
  if (!deleteTagId.value) {
    proxy.$modal.msgWarning("削除するタグを選択してください");
    return;
  }
  const tag = tagOptions.value.find(tag => tag.id === deleteTagId.value);
  selectedDeleteTag.value = tag.name;
  deleteConfirmDialogVisible.value = true;
}

function submitDeleteTag() {
  deleteConfirmDialogVisible.value = false;
  deleteTag(deleteTagId.value)
    .then(() => {
      proxy.$modal.msgSuccess('タグを削除しました');
      deleteTagId.value = ""
      selectedDeleteTag.value = ""
      getTagList();
      getList();
    }).catch((err) => {
      proxy.$modal.msgError(err.message || 'タグの削除に失敗しました');
    })
}

function removeTag(tag) {
  const index = queryParams.value.tags.indexOf(tag);
  if (index !== -1) {
    queryParams.value.tags.splice(index, 1);
  }
  handleQuery();
}

function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.id);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

function handleSizeChange(val) {
  queryParams.value.pageSize = val;
  getList();
}

function handleCurrentChange(val) {
  queryParams.value.pageNum = val;
  getList();
}

function handleUpload() {
  reset();
  open.value = true;
  title.value = "ファイルアップロード";
  // 追加：バリデーションのリセット
  proxy.$refs.fileRef?.resetFields();
}

function handleFileChange(_file, fileList) {
  form.value.fileList = fileList
  form.value.file = fileList[0]?.raw ?? null;
}

function handleFileDelete(file, fileList) {
  // ファイル削除時の処理
  form.value.fileList = fileList;
  form.value.file = fileList[0]?.raw ?? null;
}

// フォルダ選択ボタン押下時に input をクリック
const triggerFolderSelect = () => {
  folderInput.value?.click();
};

// フォルダからのファイル選択時
const handleFolderChange = (e) => {
  const files = Array.from(e.target.files);
  files.forEach((file) => {
    const uploadFile = {
      name: file.name, // フォルダ構造は含まれない
      raw: file,
      status: 'ready',
    };
    form.value.fileList.push(uploadFile);
  });
  e.target.value = '';
};

function reset() {
  form.value = {
    file: null,
    fileList: [],
    tags: [],
    roles: []
  };
}

function cancel() {
  open.value = false;
  reset();
}

const tagSelect = ref(null);
function handleTagSelectChange(val) {
  // 自動で閉じる
  tagSelect.value?.blur();
}

function submitForm() {
  try {
    loading.value = true; // アップロード開始時に true に設定
    let filesize = 0; // ファイルサイズの初期化
    let timeout = 0; // タイムアウトの初期化
    proxy.$refs["fileRef"].validate((valid) => {
      const hasFile = form.value.fileList.length > 0;
      if (valid && hasFile) {
        const formData = new FormData();
        // ファイルの指定
        for (let i = 0; i < form.value.fileList.length; i++) {
          formData.append("files", form.value.fileList[i].raw);
          filesize += form.value.fileList[i].raw.size; // ファイルサイズの累積
        }

        // 明示的に配列に変換
        const tagArray = Array.isArray(form.value.tags)
          ? form.value.tags
          : [form.value.tags];

        // tagの指定
        if (tagArray.length > 0) {
          formData.append("tags", JSON.stringify(form.value.tags));
        }

        // ロール権限の指定
        if (form.value.roles && form.value.roles.length > 0) {
          // 「both」オプションが選択されているかどうかを確認する
          let rolesToSubmit = [...form.value.roles];
          if (rolesToSubmit.includes('both')) {
            rolesToSubmit = [1, 2]; // admin + sso
          }
          formData.append("roles", JSON.stringify(rolesToSubmit));
        }

        // 1バイトあたり5ミリ秒のタイムアウト計算
        timeout = filesize * 5;
        if (timeout < 10 * 1000) {
          // タイムアウト最低保障
          timeout = 10 * 1000;
          console.log('タイムアウトを10秒に設定');
        }

        uploadFile(formData, timeout)
          .then(() => {
            proxy.$modal.msgSuccess("ファイルのアップロードタスクを作成しました");
            open.value = false;
            getList();
          })
          .finally(() => {
            loading.value = false; // アップロード完了後に false に設定
          });
      } else {
        loading.value = false; // バリデーション失敗時にも false に設定
      }
    });
  } catch (error) {
    console.error("アップロード中にエラーが発生しました:", error);
    proxy.$modal.msgError("ファイルのアップロード中にエラーが発生しました");
    loading.value = false; // エラー時にも false に設定
  }
}

function handleSingleDelete(row) {
  proxy.$modal.confirm(`「${row.filename}」を削除しますか？`).then(() => {
    deleteFile(row.id).then(() => {
      proxy.$modal.msgSuccess("削除成功");
      getList();
    });
  });
}

function handleReload() {
  getList();
}

function handleBatchPreview() {
  if (ids.value.length !== 1) {
    proxy.$modal.msgError("プレビューするファイルを選択してください");
    return;
  }
  const selectedRow = fileList.value.find(item => item.id === ids.value[0]);
  if (selectedRow) {
    handlePreview(selectedRow);
  }
}

function handleBatchDownload() {
  if (ids.value.length !== 1) {
    proxy.$modal.msgError("ダウンロードするファイルを選択してください");
    return;
  }
  const selectedRow = fileList.value.find(item => item.id === ids.value[0]);
  if (selectedRow) {
    handleDownload(selectedRow);
  }
}

function handleDelete() {
  if (ids.value.length === 0) {
    proxy.$modal.msgError("削除するファイルを選択してください");
    return;
  }

  proxy.$modal.confirm(`選択した${ids.value.length}個のファイルを削除しますか？`).then(() => {
    deleteFile(ids.value)
      .then(() => {
        proxy.$modal.msgSuccess("ファイルが正常に削除されました");
        getList(); // 削除後にリストを更新
      })
      .catch(() => {
        proxy.$modal.msgError("ファイルの削除に失敗しました");
      });
  })
    .catch(() => {
      proxy.$modal.msgInfo("削除がキャンセルされました");
    });
}

function handleEdit(row) {
  proxy.$modal.msgInfo("編集機能は未実装です");
}

function handlePreview(row) {
  previewFile(row.storage_key).then(blob => {
    try {
      if (blob.type === 'application/json') {
        proxy.$modal.msgError("ファイルのプレビューに失敗しました");
        return;
      }
      const url = window.URL.createObjectURL(blob);
      window.open(url, '_blank');
    } catch (error) {
      console.error("エラー:", error);
      proxy.$modal.msgError("ファイルのプレビューに失敗しました");
    }
  }).catch(() => {
    proxy.$modal.msgError("ファイルのプレビューに失敗しました");
  });
}

function handleDownload(row) {
  downloadFile(row.storage_key).then(blob => {
    try {
      if (blob.type === 'application/json') {
        proxy.$modal.msgError("ファイルのダウンロードに失敗しました");
        return;
      }
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = row.filename;
      a.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("エラー:", error);
      proxy.$modal.msgError("ファイルのダウンロードに失敗しました");
    }
  }).catch(() => {
    proxy.$modal.msgError("ファイルのダウンロードに失敗しました");
  });
}

function navigateToLocalchat() {
  router.push('/chat');
}

function updateDateRange() {
  // if (startDate.value && endDate.value) {
  //   dateRange.value = [startDate.value, endDate.value];
  //   handleQuery();
  // } else if (!startDate.value && !endDate.value) {
  //   clearDateRange();
  // }
  dateRange.value = [startDate.value, endDate.value];
}

function clearDateRange() {
  dateRange.value = [];
  startDate.value = '';
  endDate.value = '';
  handleQuery();
}

function toggleTaskCollapse() {
  taskExpanded.value = !taskExpanded.value;
}

function toggleSearchCollapse() {
  searchExpanded.value = !searchExpanded.value;
}

function toggleTagCollapse() {
  TagExpanded.value = !TagExpanded.value;
}

// レスポンシブ処理
function handleResize() {
  const width = window.innerWidth;
  if (width <= 992) {
    searchExpanded.value = false;
  } else {
    searchExpanded.value = true;
  }
}

onMounted(() => {
  window.addEventListener('resize', handleResize);
});

onUnmounted(() => {
  window.removeEventListener('resize', handleResize);
});

// 初期化
getList();
getTagList();
getUploadStatusList();
getRoleList();
</script>

<style lang="scss" scoped>
@import '@/assets/styles/variables.module.scss';

::v-deep(.el-checkbox__input.is-checked .el-checkbox__inner) {
  background-color: $primary-color;
  border-color: $primary-color;
  color: #ffffff;
}

.file-management-container {
  padding: 20px;
  background-color: $light-bg-alt;
  min-height: 100vh;
}

.top-nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;

  .logo-area {
    cursor: pointer;
  }
}

.content-container {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
}

.upload-section {
  :deep(.el-button) {
    width: 80%;
    height: 50px;
    margin: 0 10% 24px 10%;
    font-size: 1.1rem;
  }
}

.left-panel {
  flex: 0 0 28%;
  min-width: 300px;
  padding: 20px;
  // background-color: white;
  border-radius: $border-radius;
  // box-shadow: $shadow;
}

.right-panel {
  flex: 1;
  min-width: 300px;
  padding: 20px;
}

.section {
  align-items: center;
  margin-bottom: 20px;
  background-color: white;
  border-radius: $border-radius;
  padding: 15px;
  box-shadow: $shadow;

}

// メインアクションボタンはメインカラーを使用する.el-button--primary {  background-color: $primary-color;  border-color: $primary-color;    &:hover, &:focus {    background-color: $primary-light;    border-color: $primary-light;  }}

.search-filter-section {
  .search-form {
    display: flex;
    flex-direction: column;
    gap: 15px;
  }

  .active-filters {
    margin-top: 15px;
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    align-items: center;

    .filter-label {
      font-weight: 500;
      margin-right: 5px;
    }

    .el-tag {
      margin-right: 5px;
    }
  }
}

.view-controls {
  display: flex;
  justify-content: space-between;
  align-items: center;

  .sort-options {
    display: flex;
    align-items: center;
    gap: 10px;
  }
}

.card-view {
  .card-container {
    min-height: 200px;
  }

  .card-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 20px;
  }

  .file-card {
    border: 1px solid #e4e7ed;
    border-radius: 8px;
    overflow: hidden;
    transition: all 0.3s;
    position: relative;
    height: 200px;

    &:hover {
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
      transform: translateY(-5px);

      .card-hover-info {
        opacity: 1;
        transform: translateY(0);
      }

      .card-actions {
        opacity: 1;
      }
    }

    .card-content {
      padding: 15px;
      height: 100%;
      display: flex;
      flex-direction: column;
    }

    .card-header {
      margin-bottom: 10px;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;

      .file-name {
        font-weight: 500;
        font-size: 16px;
      }

      .search-match-tag {
        background-color: #ecf5ff;
        color: #409EFF;
        padding: 2px 6px;
        border-radius: 4px;
        font-size: 12px;
      }
    }

    .card-body {
      flex: 1;

      .upload-info {
        color: #909399;
        font-size: 14px;
      }
    }

    .card-hover-info {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 40px;
      background-color: rgba(255, 255, 255, 0.95);
      padding: 15px;
      opacity: 0;
      transform: translateY(10px);
      transition: all 0.3s;
      overflow-y: auto;

      .hover-section {
        margin-bottom: 10px;

        .hover-label {
          font-weight: 500;
          margin-bottom: 5px;
          color: #606266;
        }

        .hover-value {
          color: #303133;
        }
      }
    }

    .card-actions {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      background-color: #f5f7fa;
      padding: 10px;
      display: flex;
      justify-content: space-around;
      opacity: 0.7;
      transition: opacity 0.3s;
    }
  }
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}

.table-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
  padding-bottom: 10px;
  border-bottom: 1px solid #e4e7ed;
}

.table-title h3 {
  margin: 0;
  color: $primary-color;
  font-size: 18px;
  font-weight: 600;
}

.table-actions {
  display: flex;
  gap: 10px;
}

.pagination-selector {
  display: flex;
  align-items: center;
  gap: 8px;
}

.pagination-label {
  font-size: 14px;
  color: #606266;
  white-space: nowrap;
}

.collapse-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: pointer;
  user-select: none;

  &:hover {
    .section-title {
      color: $primary-light;
    }
  }
}

.collapse-icon {
  transition: transform 0.3s ease;
  color: #909399;

  &.collapsed {
    transform: rotate(-90deg);
  }
}

.search-content {
  margin-top: 15px;
}

.el-button+.el-button {
  margin: 0px;
}

.section-title {
  margin-top: 0;
  margin-bottom: 15px;
  font-size: 16px;
  font-weight: 600;
  color: $primary-color;
}

.date-inputs {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;

  .date-picker {
    flex: 1;
  }

  .date-separator {
    color: #909399;
  }
}

.search-buttons {
  display: flex;
  gap: 10px;
}

.filter-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.upload-section {
  display: flex;
  justify-content: space-between;
  align-items: first baseline;
  flex-direction: column;
  gap: 15px;
}

.toLocalChat {
  background-color: #fff;
  color: $primary-dark;

  &:hover {
    color: $secondary-blue;
  }
}

::v-deep(.el-form-item__content) {
  gap: 8px;
}

::v-deep(.el-form-item--default) {
  margin-bottom: 24px;
}

.dialog-footer {
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  gap: 10px;

  &>.el-button:nth-child(2) {
    background-color: #fff;
    color: $primary-dark;

    &:hover {
      color: $secondary-blue;
    }
  }
}

// レスポンシブデザイン
@media (max-width: 992px) {
  .content-container {
    flex-direction: column;
  }

  .left-panel,
  .right-panel {
    width: 100%;
    flex: 1 1 100%;
  }

  .search-filter-section {
    .collapse-header {
      display: flex;
    }
  }

  .table-header {
    flex-wrap: wrap;
    gap: 10px;
  }

  .pagination-selector {
    order: 3;
    flex-basis: 100%;
    justify-content: center;
  }

  .upload-section {
    flex-direction: row;
  }

}

@media (max-width: 820px) {
  .upload-section {
    display: flex;
    justify-content: space-between;
    flex-direction: row;
  }
}

@media (max-width: 768px) {
  .date-inputs {
    flex-direction: column;

    .date-separator {
      display: none;
    }
  }

  .search-buttons {
    flex-direction: column;
  }
}

.role-tags {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px;
}

.role-help-text {
  margin-top: 8px;
  color: #909399;
  font-size: 12px;
}
</style>