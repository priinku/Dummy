<template>
  <div class="unauthorized">
    <h1>401 - アクセス権がありません</h1>
    <p>このページにアクセスする権限がありません。</p>
    <router-link to="/login">
      <button class="login-button">ログインする</button>
    </router-link>
  </div>
</template>

<script>
export default {
  name: "Unauthorized",
};
</script>

<style scoped>
.unauthorized {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  text-align: center;
  background-color: #f0f0f0;
  padding: 20px;
}

.unauthorized-image {
  max-width: 100%;
  height: auto;
  margin-bottom: 30px;
}

h1 {
  font-size: 2.5rem;
  color: #ff5252;
  margin-bottom: 20px;
}

p {
  font-size: 1.25rem;
  color: #666;
  margin-bottom: 30px;
}

.login-button {
  background-color: #212121;
  color: white;
  border: none;
  padding: 15px 30px;
  font-size: 1.2rem;
  cursor: pointer;
  border-radius: 50px;
  transition: background-color 0.3s ease;
}

.login-button:hover {
  background-color: #424242;
}
</style>
