<template>
  <div class="not-found">
    <h1>おっと！403 - アクセスが拒否されました</h1>
    <p>申し訳ありませんが、このページにアクセスする権限がありません。</p>
    <router-link to="/">
      <button class="home-button">ホームに戻る</button>
    </router-link>
  </div>
</template>

<script>
export default {
  name: "NotFound",
};
</script>

<style scoped>
.not-found {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  text-align: center;
  background-color: #f0f0f0;
  padding: 20px;
}

.not-found-image {
  max-width: 100%;
  height: auto;
  margin-bottom: 30px;
}

h1 {
  font-size: 2.5rem;
  color: #ff5252;
  margin-bottom: 20px;
}

p {
  font-size: 1.25rem;
  color: #666;
  margin-bottom: 30px;
}

.home-button {
  background-color: #212121;
  color: white;
  border: none;
  padding: 15px 30px;
  font-size: 1.2rem;
  cursor: pointer;
  border-radius: 50px;
  transition: background-color 0.3s ease;
}

.home-button:hover {
  background-color: #424242;
}
</style>
