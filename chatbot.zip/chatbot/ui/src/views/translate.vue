<template>
  <div class="translate-container">
    <!-- 頁面標題區域 -->
    <div class="page-header">
      <div class="home-button-fixed">
        <el-button type="primary" icon="Back" @click="navigateToHome"></el-button>
      </div>
      <div class="title-section">
        <h1 class="main-title">翻訳</h1>
        <p class="subtitle">AI 駆動の日英翻訳サービス</p>
      </div>
    </div>

    <!-- メイン翻訳エリア - 3カラムレイアウト -->
    <div class="translation-main">
      <!-- 左側：入力エリア -->
      <div class="input-panel">
        <div class="input-section">
          <div class="input-header">
            <span class="lang-label">{{ sourceLang === 'ja' ? '日本語' : 'English' }}</span>
            <div class="input-actions">
              <button class="action-btn" @click="clearInput" title="クリア">
                <i class="fa-solid fa-trash"></i>
              </button>
              <button class="action-btn" @click="copyText" title="コピー">
                <i class="fa-solid fa-copy"></i>
              </button>
            </div>
          </div>
          <div class="input-container">
            <textarea
              v-model="inputText"
              :placeholder="sourceLang === 'ja' ? '日本語を入力してください...' : 'Enter English text...'"
              class="input-textarea"
              @input="handleInput"
              ref="inputTextarea"
            ></textarea>
            <div class="char-count">{{ inputText.length }}/2000</div>
          </div>
        </div>
      </div>

      <!-- 中央：コントロールボタンエリア -->
      <div class="control-panel">
        <!-- 言語切り替え -->
        <div class="language-switch">
          <div class="switch-container">
            <button 
              :class="['switch-btn', { active: sourceLang === 'ja' }]"
              @click="setSourceLanguage('ja')"
            >
              日
            </button>
            <button 
              :class="['switch-btn', { active: sourceLang === 'en' }]"
              @click="setSourceLanguage('en')"
            >
              英
            </button>
          </div>
        </div>

        <!-- 翻訳ボタン -->
        <div class="translate-button-section">
          <button 
            class="translate-btn"
            :disabled="!inputText.trim() || isTranslating"
            @click="translateText"
          >
            <span v-if="!isTranslating" class="btn-content">
              <i class="fa-solid fa-language"></i>
              翻訳
            </span>
            <span v-else class="btn-content">
              <i class="fa-solid fa-rotate"></i>
              翻訳中...
            </span>
          </button>
        </div>
      </div>

      <!-- 右側：出力エリア -->
      <div class="output-panel">
        <div class="output-section">
          <div class="output-header">
            <span class="lang-label">{{ targetLang === 'ja' ? '日本語' : 'English' }}</span>
            <div class="output-actions">
              <button class="action-btn" @click="copyTranslation" title="コピー">
                <i class="fa-solid fa-copy"></i>
              </button>
              <button class="action-btn" @click="playAudio" title="音声再生">
                <i class="fa-solid fa-volume-high"></i>
              </button>
            </div>
          </div>
          <div class="output-container">
            <div v-if="isTranslating" class="loading-placeholder">
              <div class="loading-dots">
                <span></span>
                <span></span>
                <span></span>
              </div>
              <p>翻訳中...</p>
            </div>
            <div v-else-if="translatedText" class="translated-text">
              {{ translatedText }}
            </div>
            <div v-else-if="lastError" class="error-output">
              <div class="error-icon">⚠️</div>
              <p class="error-message">{{ lastError }}</p>
              <button class="retry-btn" @click="translateText">再試行</button>
            </div>
            <div v-else class="empty-output">
              <i class="fa-solid fa-pen-nib"></i>
              <p>翻訳結果はここに表示されます</p>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>
<script>
import { listTaskOutput, addTask } from '@/api/task';
import { ElMessage } from 'element-plus';

export default {
  name: 'TranslatePage',
  data() {
    return {
      sourceLang: 'ja',
      targetLang: 'en',
      inputText: '',
      translatedText: '',
      isTranslating: false,
      maxLength: 2000,
      lastError: null
    }
  },
  mounted() {
  },
  methods: {
    setSourceLanguage(lang) {
      this.sourceLang = lang
      this.targetLang = lang === 'ja' ? 'en' : 'ja'
      this.translatedText = ''
      this.lastError = null
    },
    
    handleInput() {
      if (this.inputText.length > this.maxLength) {
        this.inputText = this.inputText.substring(0, this.maxLength)
      }
    },
    
    async translateText() {
      if (!this.inputText.trim()) return
      
      this.isTranslating = true
      this.translatedText = ''
      this.lastError = null
      
      try {
        //タスクシステムを使用して翻訳タスクを作成する / Use the task system to create translation tasks
        const addTaskResponse = await addTask({
          type: 'TRANSLATE',
          formData: {
            sourceText: this.inputText.trim(),
            sourceLang: this.sourceLang,
            targetLang: this.targetLang
          }
        })
        
        if (addTaskResponse.code !== 200) {
          ElMessage.error('翻訳タスクの作成に失敗しました')
          return
        }

        this.translatedText = '翻訳中...しばらくお待ちください'

        // タスク状態をポーリング
        const timer = setInterval(() => {
          listTaskOutput({
            pageNum: 1,
            pageSize: 1000,
            taskId: addTaskResponse.result.taskId,
          }).then((taskOutputResponse) => {
            const taskOutput = taskOutputResponse.result.rows.filter(
              (output) => output.sort === 1
            )[0]
            
            if (taskOutput.status === "PROCESSING") {
              // まだ処理中
              this.isTranslating = true
            } else if (taskOutput.status === "FINISHED") {
              // 処理完了
              this.translatedText = taskOutput.content.replace(/<think>.*?<\/think>/gs, '').trim()
              this.isTranslating = false
              ElMessage.success("翻訳が完了しました")
              
              clearInterval(timer)
            } else if (taskOutput.status === "FAILED") {
              // 処理失敗
              ElMessage.error("翻訳処理に失敗しました")
              this.translatedText = ""
              this.lastError = "翻訳処理に失敗しました"
              this.isTranslating = false
              clearInterval(timer)
            }
          }).catch((error) => {
            console.error('タスク状態のポーリングに失敗:', error)
            ElMessage.error('翻訳結果の取得に失敗しました')
            this.isTranslating = false
            clearInterval(timer)
          })
        }, 1000)
        
      } catch (error) {
        console.error('翻訳タスクの作成に失敗:', error)
        ElMessage.error('翻訳タスクの作成に失敗しました')
        this.isTranslating = false
      }
    },
    
    clearInput() {
      this.inputText = ''
      this.translatedText = ''
      this.lastError = null
    },
    
    copyText() {
      if (this.inputText) {
        navigator.clipboard.writeText(this.inputText)
        ElMessage.success('クリップボードにコピーしました')
      }
    },
    
    copyTranslation() {
      if (this.translatedText) {
        navigator.clipboard.writeText(this.translatedText)
        ElMessage.success('翻訳をクリップボードにコピーしました')
      }
    },
    
    playAudio() {
      if (this.translatedText) {
        // ここでテキスト読み上げ機能を実装できます
        ElMessage.info('音声再生機能開発中...')
      } else {
        ElMessage.warning('再生可能な翻訳内容がありません')
      }
    },
    
  }
}

</script>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();
const contentGenLoading = ref(false);

function navigateToHome() {
  if (contentGenLoading.value === true) {
    ElMessage.warning("生成中のコンテンツがあります。完了するまで待ってください。");
  } else {
    router.push('./home');
  }
}
</script>

<style lang="scss" scoped>
@import "@/assets/styles/variables.module.scss";

.translate-container {
  height: 100vh;
  background: $light-bg;
  padding: 3rem;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.page-header {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-bottom: 1rem;
  padding: 1rem 1.5rem;
  background: $light-bg-alt;
  border-radius: $border-radius;
  box-shadow: $shadow-sm;
  border: 1px solid $light-border;
  flex-shrink: 0;
}

.home-button-fixed {
  position: fixed;
  top: 75px;
  left: 75px;
  z-index: 1000;
}

.title-section {
  text-align: center;
  
  .main-title {
    font-size: 1.5rem;
    font-weight: 700;
    color: $primary-color;
    margin: 0 0 0.25rem 0;
  }
  
  .subtitle {
    font-size: 0.9rem;
    color: $text-dark;
    opacity: 0.8;
    margin: 0;
  }
}

.translation-main {
  display: flex;
  gap: 1rem;
  flex: 1;
  min-height: 0;
  margin-bottom: 1rem;
}

.input-panel, .output-panel {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.control-panel {
  width: 120px;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  justify-content: center;
  align-items: center;
}

.input-section, .output-section {
  background: $light-bg;
  border-radius: $border-radius;
  box-shadow: $shadow-sm;
  overflow: hidden;
  border: 1px solid $light-border;
  flex: 1;
  display: flex;
  flex-direction: column;
}

.input-header, .output-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.75rem 1rem;
  background: $primary-color;
  color: $text-light;
  
  .lang-label {
    font-size: 0.9rem;
    font-weight: 600;
  }
  
  .input-actions, .output-actions {
    display: flex;
    gap: 0.25rem;
  }
  
  .action-btn {
    background: rgba(255, 255, 255, 0.2);
    border: none;
    border-radius: $border-radius-sm;
    padding: 0.25rem;
    cursor: pointer;
    transition: $transition;
    color: $text-light;
    
    &:hover {
      background: rgba(255, 255, 255, 0.3);
    }
    
    .icon {
      font-size: 0.8rem;
    }
  }
}

.input-container, .output-container {
  padding: 1rem;
  flex: 1;
  position: relative;
  display: flex;
  flex-direction: column;
}

.input-textarea {
  width: 100%;
  flex: 1;
  min-height: 120px;
  border: none;
  outline: none;
  resize: none;
  font-size: 0.9rem;
  line-height: 1.5;
  font-family: inherit;
  background: transparent;
  
  &::placeholder {
    color: rgba(0, 0, 0, 0.4);
  }
}

.char-count {
  position: absolute;
  bottom: 0.5rem;
  right: 1rem;
  font-size: 0.75rem;
  color: rgba(0, 0, 0, 0.5);
}

.language-switch {
  .switch-container {
    display: flex;
    background: $light-bg;
    border-radius: $border-radius;
    padding: 0.25rem;
    border: 1px solid $light-border;
    box-shadow: $shadow-sm;
  }
  
  .switch-btn {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.25rem;
    padding: 0.5rem 0.75rem;
    border: none;
    background: transparent;
    border-radius: $border-radius-sm;
    cursor: pointer;
    transition: $transition;
    font-weight: 500;
    font-size: 0.8rem;
    min-width: 50px;
    
    .flag {
      font-size: 1.2rem;
    }
    
    &.active {
      background: $primary-color;
      color: $text-light;
      box-shadow: $shadow-sm;
    }
    
    &:hover:not(.active) {
      background: rgba(0, 30, 96, 0.1);
    }
  }
}

.translate-button-section {
  display: flex;
  justify-content: center;
  
  .translate-btn {
    background: $primary-color;
    color: $text-light;
    border: none;
    border-radius: $border-radius;
    padding: 0.75rem 1rem;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    transition: $transition;
    box-shadow: $shadow-sm;
    width: 100%;
    
    &:hover:not(:disabled) {
      transform: translateY(-1px);
      box-shadow: $shadow;
    }
    
    &:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    .btn-content {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      justify-content: center;
    }
    
    .icon {
      font-size: 0.9rem;
      
      &.rotating {
        animation: rotate 1s linear infinite;
      }
    }
  }
}

.output-container {
  .loading-placeholder {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    color: rgba(0, 0, 0, 0.6);
    
    .loading-dots {
      display: flex;
      gap: 0.25rem;
      margin-bottom: 0.5rem;
      
      span {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: $primary-color;
        animation: bounce 1.4s ease-in-out infinite both;
        
        &:nth-child(1) { animation-delay: -0.32s; }
        &:nth-child(2) { animation-delay: -0.16s; }
      }
    }
    
    p {
      font-size: 0.9rem;
      margin: 0;
    }
  }
  
  .translated-text {
    font-size: 0.9rem;
    line-height: 1.5;
    color: $text-dark;
    flex: 1;
  }
  
  .empty-output {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    color: rgba(0, 0, 0, 0.4);
    
    .empty-icon {
      font-size: 2rem;
      margin-bottom: 0.5rem;
    }
    
    p {
      font-size: 0.9rem;
      margin-top: 8px;
      text-align: center;
    }
  }
  
  .error-output {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    color: $danger;
    text-align: center;
    
    .error-icon {
      font-size: 2rem;
      margin-bottom: 0.5rem;
    }
    
    .error-message {
      font-size: 0.9rem;
      margin: 0 0 1rem 0;
      max-width: 80%;
      line-height: 1.4;
    }
    
    .retry-btn {
      background: $danger;
      color: white;
      border: none;
      border-radius: $border-radius-sm;
      padding: 0.5rem 1rem;
      cursor: pointer;
      transition: $transition;
      font-size: 0.8rem;
      
      &:hover {
        background: darken($danger, 10%);
        transform: translateY(-1px);
      }
    }
  }
}


@keyframes rotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

@keyframes bounce {
  0%, 80%, 100% {
    transform: scale(0);
  }
  40% {
    transform: scale(1);
  }
}

// レスポンシブデザイン
@media (max-width: 768px) {

.home-button-fixed {
  position: fixed;
  top: 35px;
  left: 30px;
}
    
  .translate-container {
    padding: 0.5rem;
  }
  
  .translation-main {
    flex-direction: column;
  }
  
  .control-panel {
    width: 100%;
    flex-direction: row;
    justify-content: center;
    gap: 2rem;
  }
  
  .page-header {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }
  
  .title-section .main-title {
    font-size: 1.25rem;
  }
  
  .input-container, .output-container {
    padding: 0.75rem;
  }
  
  .translate-btn {
    padding: 0.625rem 1.5rem;
    font-size: 0.9rem;
    width: auto;
  }
}
</style>
