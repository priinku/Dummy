<template>
  <div class="summary-container">
    <div class="summary-header">
      <div class="header-nav">
        <el-button 
          type="primary"
          icon="Back"
          class="home-button-fixed"
          @click="navigateToHome"
        >
          <!-- <el-icon><ArrowLeft /></el-icon>
          ホームに戻る -->
        </el-button>
      </div>
      <h1>要約</h1>
      <p>ファイルをアップロードして要約を生成します</p>
    </div>

    <div class="summary-content">
      <div class="input-section">
        <div class="input-title">
        <h2>入力 </h2>
        <span v-if="inputText.trim()">文字數：{{ inputText.length }}</span>
        </div>
        <!-- タブ切り替え -->
        <el-tabs v-model="activeTab" class="input-tabs" >
          <el-tab-pane label="ファイルアップロード" name="file">
            <div class="upload-container">
              <el-upload
                class="upload-demo"
                drag
                action=""
                multiple
                :auto-upload="false"
                :file-list="fileList"
                :on-change="handleFileChange"
                :on-remove="handleFileRemove"
              >
                <i class="el-icon-upload"></i>
                <div class="el-upload__text">
                  ここにファイルをドラッグまたはクリックで選択
                </div>
              </el-upload>
            </div>
            <div class="file-info" v-if="fileList.length > 0">
              <p>選択されたファイル:</p>
              <ul>
                <li v-for="file in fileList" :key="file.uid">
                  {{ file.name }} ({{ formatFileSize(file.size) }})
                </li>
              </ul>
            </div>
          </el-tab-pane>
          
          <el-tab-pane label="テキスト入力" name="text" >
            <div class="text-input-container">
              <el-input
                v-model="inputText"
                type="textarea"
                :rows="18"
                placeholder="要約したいテキストを直接入力してください..."
                class="input-textarea"
              />
              <!-- <div class="text-info" v-if="inputText.trim()">
                <p>文字数: {{ inputText.length }}</p>
              </div> -->
            </div>
          </el-tab-pane>
        </el-tabs>

        <!-- 要約開始ボタン -->
        <div class="action-buttons">
          <el-button
            type="primary"
            size="large"
            :disabled="!canStartSummary || isProcessing || isExtractingText"
            @click="startSummary"
            class="summary-button"
          >
            <el-icon><Document /></el-icon> &nbsp;&nbsp;
            <span>要約開始</span>
          </el-button>
        </div>
      </div>

      <div class="output-section">
        <div class="output-header">
          <h2>要約結果</h2>
          <el-button
            type="primary"
            size="small"
            :disabled="!summaryText || isProcessing"
            @click="copyToClipboard"
            class="copy-button"
          >
              <i class="fa-solid fa-copy"></i>
          </el-button>
        </div>
        <el-input
          v-model="summaryText"
          type="textarea"
          :rows="24"
          placeholder="要約結果がここに表示されます..."
          readonly
          class="summary-textarea"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { ElMessage } from 'element-plus'
import { DocumentCopy, Document, ArrowLeft } from '@element-plus/icons-vue'
import { extractTextFromFile } from '@/api/file'
import { listTaskOutput, addTask } from '@/api/task'
import { useRouter } from 'vue-router'

const router = useRouter()
const contentGenLoading = ref(false);

const fileList = ref([])
const summaryText = ref('')
const inputText = ref('')
const activeTab = ref('file')
const isProcessing = ref(false)
const isExtractingText = ref(false)

const canStartSummary = computed(() => {
  if (isExtractingText.value) return false
  if (activeTab.value === 'file') {
    return fileList.value.length > 0
  } else {
    return inputText.value.trim().length > 0
  }
})

const goBack = () => {
  router.push('/home')
}

function navigateToHome() {
  if (contentGenLoading.value === true) {
    ElMessage.warning("生成中のコンテンツがあります。完了するまで待ってください。");
  } else {
    router.push('./home');
  }
}

const handleFileChange = async (file, files) => {
  fileList.value = files
  summaryText.value = ''
  
  if (file && file.raw) {
    const fileName = file.name.toLowerCase()
    const supportedExtensions = ['pdf', 'docx', 'txt']
    const fileExtension = fileName.split('.').pop()
    
    if (supportedExtensions.includes(fileExtension)) {
      await extractTextFromUploadedFile(file.raw, file.name)
    }
  }
}

const handleFileRemove = (file, files) => {
  fileList.value = files
  summaryText.value = ''
}

const extractTextFromUploadedFile = async (file, fileName) => {
  isExtractingText.value = true
  
  try {
    ElMessage.info(`${fileName}からテキストを抽出中...`)
    
    const response = await extractTextFromFile(file)
    
    if (response.result && response.result.text) {
      inputText.value = response.result.text
      activeTab.value = 'text'
      ElMessage.success(`テキスト抽出が完了しました (${response.result.length}文字)`)
    } else {
      ElMessage.warning('テキストが抽出できませんでした')
    }
  } catch (error) {
    console.error('テキスト抽出エラー:', error)
    if (error.message && error.message.includes('対応していないファイル形式')) {
      ElMessage.error('対応していないファイル形式です。PDF、DOCX、TXTファイルのみサポートしています。')
    } else {
      ElMessage.error('テキスト抽出中にエラーが発生しました')
    }
  } finally {
    isExtractingText.value = false
  }
}

const startSummary = async () => {
  if (!canStartSummary.value) {
    ElMessage.warning('入力内容を確認してください')
    return
  }

  
  try {
    const addTaskResponse = await addTask({
      type: 'SUMMARY',
      formData: {
        text: inputText.value
      }
    })
    
    if (addTaskResponse.code !== 200) {
      ElMessage.error('要約タスクの作成に失敗しました')
      return;
    }

    summaryText.value = '要約を生成中...しばらくお待ちください。'

    const timer = setInterval(() => {
      listTaskOutput({
        pageNum: 1,
        pageSize: 1000,
        taskId: addTaskResponse.result.taskId,
      }).then((taskOutputResponse) => {
          const t = taskOutputResponse.result.rows.filter(
            (output) => output.sort === 1
          )[0];
          if (t.status === "PROCESSING") {
            // まだ処理中
            isProcessing.value = true;
          } else if (t.status === "FINISHED") {
            // 処理が完了
            summaryText.value = t.content.replace(/<think>.*?<\/think>/gs, '').trim();
            isProcessing.value = false;
            ElMessage.success("要約が完了しました");
            clearInterval(timer);
          } else if (t.status === "FAILED") {
            // 処理が失敗
            ElMessage.error("要約処理に失敗しました");
            summaryText.value = "";
            isProcessing.value = false;
            clearInterval(timer);
          }
        }
      )
    }, 1000)
  } catch (error) {
    console.error('要約処理エラー:', error)
    ElMessage.error('要約処理中にエラーが発生しました')
  } finally {
    isProcessing.value = false
  }
}

const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 Bytes'
  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
}

const copyToClipboard = async () => {
  if (!summaryText.value) {
    ElMessage.warning('コピーするテキストがありません')
    return
  }

  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(summaryText.value)
      ElMessage.success('クリップボードにコピーしました')
    } else {
      const textArea = document.createElement('textarea')
      textArea.value = summaryText.value
      document.body.appendChild(textArea)
      textArea.select()
      document.execCommand('copy')
      document.body.removeChild(textArea)
      ElMessage.success('クリップボードにコピーしました')
    }
  } catch (error) {
    console.error('クリップボードへのコピーに失敗しました:', error)
    ElMessage.error('クリップボードへのコピーに失敗しました')
  }
}
</script>

<style lang="scss" scoped>
@import "@/assets/styles/variables.module.scss";

.summary-container {
  min-height: 100vh;
  background: $light-bg;
  padding: 3rem;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
  display: flex;
  flex-direction: column;
  overflow-x: hidden;
  overflow-y: auto;
}

.summary-header {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-bottom: 1rem;
  padding: 1rem 1.5rem;
  background: $light-bg-alt;
  border-radius: $border-radius;
  box-shadow: $shadow-sm;
  border: 1px solid $light-border;
  flex-shrink: 0;

  h1 {
    font-size: 1.5rem;
    font-weight: 700;
    color: $primary-color;
    margin: 0 0 0.25rem 0;
  }

  p {
    font-size: 0.9rem;
    color: $text-dark;
    opacity: 0.8;
    margin: 0;
  }
}

.summary-content {
  display: flex;
  gap: 1rem;
  flex: 1;
  min-height: 0;
  margin-bottom: 1rem;
  align-items: stretch;
}

.input-section,
.output-section {
  background: $light-bg;
  border-radius: $border-radius;
  box-shadow: $shadow-sm;
  overflow: visible;
  border: 1px solid $light-border;
  flex: 1;
  display: flex;
  flex-direction: column;
  min-height: 0;
}

.input-section {
  .input-title {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.75rem 1rem;
    background: $primary-color;
    color: $text-light;
    border-radius: 12px 12px 0 0 ; 
    
    h2 {
      font-size: 0.9rem;
      font-weight: 600;
      margin: 0;
    }
    
    span {
      font-size: 0.8rem;
      opacity: 0.8;
    }
  }
}

.input-tabs {
  flex: 1;
  display: flex;
  flex-direction: column-reverse;
  padding: 1rem;

  .el-tabs__header {
    margin-bottom: 1rem;
  }

  .el-tab-pane {
    flex: 1;
    display: flex;
    flex-direction: column;
  }
}

.el-tab-pane{
  padding: 0 4px;
}

::v-deep .el-tabs__active-bar{  
    border-radius: 12px 12px 0 0;
    background: $primary-color;
    height: 35px;
    opacity: 0.3;
}

.text-input-container {
  flex: 1;
  display: flex;
  flex-direction: column;
  
  .input-textarea {
    flex: 1;
    min-height: 120px;
    
    :deep(.el-textarea__inner) {
      border: none;
      outline: none;
      resize: none !important;  
      font-size: 0.9rem;
      line-height: 1.5;
      font-family: inherit;
      background: transparent;
      width: 100%;
      height: 100%;
      
      &::placeholder {
        color: rgba(0, 0, 0, 0.4);
      }
    }
  }
}

.text-info {
  margin-top: 10px;
  padding: 10px;
  background-color: #f5f7fa;
  border-radius: $border-radius-sm;
  font-size: 12px;
  color: $text-dark;
  opacity: 0.7;

  p {
    margin: 0;
  }
}

.action-buttons {
  padding: 1rem;
  text-align: center;
  border-top: 1px solid $light-border;
  flex-shrink: 0;
  position: sticky;
  bottom: 0;
  background: $light-bg;
  z-index: 10;
  border-radius: 0 0 12px 12px;

  .summary-button {
    background: $primary-color;
    color: $text-light;
    border: none;
    border-radius: $border-radius;
    padding: 0.75rem 1rem;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    transition: $transition;
    box-shadow: $shadow-sm;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    
    &:hover:not(:disabled) {
      transform: translateY(-1px);
      box-shadow: $shadow;
    }
    
    &:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  }
}

.output-section {
  .output-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.75rem 1rem;
    background: $agent;
    color: $text-light;
    
    h2 {
      font-size: 0.9rem;
      font-weight: 600;
      margin: 0;
    }
    
    .copy-button {
      background: rgba(255, 255, 255, 0.2);
      border: none;
      border-radius: $border-radius-sm;
      padding: 0.25rem;
      cursor: pointer;
      transition: $transition;
      color: $text-light;
      
      &:hover {
        background: rgba(255, 255, 255, 0.3);
      }
    }
  }
}

.upload-container {
  flex: 1;
  display: flex;
  flex-direction: column;
  
  .el-upload {
    flex: 1;
    display: flex;
    flex-direction: column;

    .el-upload-dragger {
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      border: 2px dashed #d9d9d9;
      border-radius: $border-radius;
      background-color: #fafafa;
      transition: $transition;

      &:hover {
        border-color: $primary-color;
        background-color: rgba($primary-color, 0.05);
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      }

      i {
        font-size: 48px;
        color: #c0c4cc;
        margin-bottom: 16px;
      }

      .el-upload__text {
        color: #606266;
        font-size: 14px;
        text-align: center;
      }
    }
  }
}

.file-info {
  margin-top: 20px;
  padding: 15px;
  background-color: #f5f7fa;
  border-radius: $border-radius-sm;

  p {
    margin: 0 0 10px;
    font-weight: 600;
    color: $text-dark;
  }

  ul {
    margin: 0;
    padding-left: 20px;

    li {
      margin-bottom: 5px;
      color: $text-dark;
      opacity: 0.8;
    }
  }
}

.summary-header {
  text-align: center;
  margin-bottom: 20px;
  position: relative;

  .header-nav {
    position: absolute;
    top: 0;
    left: 0;
    z-index: 10;

    // .back-button {
    //   display: flex;
    //   align-items: center;
    //   gap: 8px;
    //   padding: 8px 16px;
    //   font-size: 14px;
    //   color: $primary-color;
    //   border: 1px solid $primary-color;
    //   border-radius: $border-radius;
    //   background: white;
    //   transition: $transition;

    //   &:hover {
    //     background: $primary-color;
    //     color: white;
    //     transform: translateY(-1px);
    //     box-shadow: $shadow-sm;
    //   }

    //   .el-icon {
    //     font-size: 16px;
    //   }
    // }

  .home-button-fixed {
    position: relative;
    top: 25px;
    left: 33px;
    z-index: 1000;
    transition: all 0.3s ease;
  }
  }

  h1 {
    font-size: 2.5rem;
    font-weight: 700;
    color: $text-dark;
    margin-bottom: 8px;
  }

  p {
    font-size: 1rem;
    color: $text-dark;
    opacity: 0.7;
  }
}

.output-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  border-radius: 12px 12px 0 0;

  h2 {
    margin: 0;
  }

  .copy-button {
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
    
    &:hover {
      transform: translateY(-1px);
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
    }
  }
}

.summary-textarea {
  flex: 1;
  padding: 1rem;
  display: flex;
  flex-direction: column;
  
  :deep(.el-textarea__inner) {
    flex: 1;
    border: none;
    outline: none;
    resize: none; 
    font-size: 0.9rem;
    line-height: 1.5;
    font-family: inherit;
    background: transparent;
    width: 100%;
    height: 100%;
    
    &::placeholder {
      color: rgba(0, 0, 0, 0.4);
    }
  }
}

/* Responsive Design */
@media (max-width: 768px) {
  .summary-container {
    padding: 0.5rem;
    padding-top: 4rem; 
  }
  
  .home-button-fixed {
    position: relative;
    top: 20px;
    left: 20px;
    z-index: 1000;
    padding: 8px 12px;
    font-size: 0.8rem;
  }

  .summary-content {
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .summary-header {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
    margin-bottom: 0.5rem;
  }
  
  .summary-header h1 {
    font-size: 1.25rem;
  }
  
  .input-tabs {
    padding: 0.75rem;
  }
  
  .action-buttons {
    padding: 0.75rem;
    position: sticky;
    bottom: 0;
    background: $light-bg;
    border-top: 1px solid $light-border;
    margin-top: auto;
  }
  
  // Adjust minimum height for mobile version 
  .text-input-container .input-textarea {
    min-height: 200px;
  }
  
  .summary-textarea {
    min-height: 200px;
  }
}

@media (max-width: 480px) {
  .summary-container {
    padding-top: 3.5rem;
  }
  
  .home-button-fixed {
    top: 15px;
    left: 15px;
    padding: 6px 10px;
    font-size: 0.75rem;
  }
  
  //
  .text-input-container .input-textarea {
    min-height: 150px;
  }
  
  .summary-textarea {
    min-height: 150px;
  }
}


</style>