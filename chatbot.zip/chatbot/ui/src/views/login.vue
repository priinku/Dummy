<template>
  <div class="login">
    <el-form ref="loginRef" :model="loginForm" :rules="loginRules" class="login-form">
      <h3 class="title">ログイン</h3>
      <el-form-item prop="username">
        <el-input
          v-model="loginForm.username"
          type="text"
          size="large"
          auto-complete="off"
          placeholder="ユーザー名"
        >
          <template #prefix
            ><svg-icon icon-class="user" class="el-input__icon input-icon"
          /></template>
        </el-input>
      </el-form-item>
      <el-form-item prop="password">
        <el-input
          v-model="loginForm.password"
          type="password"
          size="large"
          auto-complete="off"
          placeholder="パスワード"
          @keyup.enter="handleLogin"
        >
          <template #prefix>
            <svg-icon icon-class="lock" class="el-input__icon input-icon" />
          </template>
        </el-input>
      </el-form-item>
      <el-form-item prop="code" v-if="captchaEnabled">
        <el-input
          v-model="loginForm.code"
          size="large"
          auto-complete="off"
          placeholder="確認コード"
          style="width: 63%"
          @keyup.enter="handleLogin"
        >
          <template #prefix
            ><svg-icon icon-class="prompt" class="el-input__icon input-icon"
          /></template>
        </el-input>
        <div class="login-code">
          <div v-html="codeUrl"></div>
        </div>
      </el-form-item>
      <el-checkbox v-model="loginForm.rememberMe" style="margin: 0px 0px 25px 0px"
        >パスワードを記憶する</el-checkbox
      >
      <el-form-item style="width: 100%">
        <el-button
          :loading="loading"
          size="large"
          type="primary"
          style="width: 100%"
          @click.prevent="handleLogin"
        >
          <span v-if="!loading">ログイン</span>
          <span v-else>ログイン...</span>
        </el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script setup>
import useUserStore from "@/store/modules/user";
import { decrypt, encrypt } from "@/utils/jsencrypt";
import Cookies from "js-cookie";

const userStore = useUserStore();
const route = useRoute();
const router = useRouter();
const { proxy } = getCurrentInstance();

const loginForm = ref({
  username: "",
  password: "",
  rememberMe: false,
  code: "",
  uuid: "",
});

const loginRules = {
  username: [
    {
      required: true,
      trigger: "blur",
      message: "ユーザー名を入力してください",
    },
  ],
  password: [
    {
      required: true,
      trigger: "blur",
      message: "パスワードを入力してください",
    },
  ],
  code: [
    {
      required: true,
      trigger: "change",
      message: "確認コードを入力してください",
    },
  ],
};

const codeUrl = ref("");
const loading = ref(false);
const captchaEnabled = ref(false);
const redirect = ref(undefined);

watch(
  route,
  (newRoute) => {
    redirect.value = newRoute.query && newRoute.query.redirect;
  },
  { immediate: true }
);

function ssoLogin() {
  const tenantId = process.env.VITE_AZURE_AD_TENANT_ID;
  const clientId = process.env.VITE_AZURE_AD_CLIENT_ID;
  const redirectUri = encodeURIComponent(process.env.VITE_AZURE_AD_REDIRECT_URI);

  window.location.href =
    `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/authorize` +
    `?client_id=${clientId}` +
    `&response_type=code` +
    `&redirect_uri=${redirectUri}` +
    `&scope=openid profile email` +
    `&response_mode=query` +
    `&state=12345`;
}

function handleLogin() {
  proxy.$refs.loginRef.validate((valid) => {
    if (valid) {
      loading.value = true;
      if (loginForm.value.rememberMe) {
        Cookies.set("username", loginForm.value.username, { expires: 30 });
        Cookies.set("password", encrypt(loginForm.value.password), {
          expires: 30,
        });
        Cookies.set("rememberMe", loginForm.value.rememberMe, { expires: 30 });
      } else {
        Cookies.remove("username");
        Cookies.remove("password");
        Cookies.remove("rememberMe");
      }
      userStore
        .login(loginForm.value)
        .then(() => {
          console.log("Login successful");
          const query = route.query;
          const otherQueryParams = Object.keys(query).reduce((acc, cur) => {
            if (cur !== "redirect") {
              acc[cur] = query[cur];
            }
            return acc;
          }, {});
          router.push({
            path: redirect.value || "/home",
            query: otherQueryParams,
          });
        })
        .catch(() => {
          loading.value = false;
        });
    }
  });
}

function parseSVG(resImg) {
  const parser = new DOMParser();
  const xmlDoc = parser.parseFromString(resImg, "image/svg+xml");
  return xmlDoc.documentElement.outerHTML;
}

function getCookie() {
  const username = Cookies.get("username");
  const password = Cookies.get("password");
  const rememberMe = Cookies.get("rememberMe");
  loginForm.value = {
    username: username === undefined ? loginForm.value.username : username,
    password: password === undefined ? loginForm.value.password : decrypt(password),
    rememberMe: rememberMe === undefined ? false : Boolean(rememberMe),
  };
}

getCookie();
</script>

<style lang="scss" scoped>
@import '@/assets/styles/variables.module.scss';
.login {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
}

.title {
  margin: 0px auto 30px auto;
  text-align: center;
  color: #707070;
}

.login-form {
  border-radius: 6px;
  background: #ffffff;
  width: 400px;
  padding: 25px 25px 5px 25px;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  background-color: #fff;

  .el-input {
    height: 40px;

    input {
      height: 40px;
    }
  }

  .input-icon {
    height: 39px;
    width: 14px;
    margin-left: 0px;
  }
}

.login-tip {
  font-size: 13px;
  text-align: center;
  color: #bfbfbf;
}

.login-code {
  margin-left: 6px;
  width: 35%;
  height: 42px;
  float: right;

  img {
    cursor: pointer;
    vertical-align: middle;
  }
}

.el-login-footer {
  height: 40px;
  line-height: 40px;
  position: fixed;
  bottom: 0;
  width: 100%;
  text-align: center;
  color: #fff;
  font-family: "Noto Serif JP", Arial;
  font-size: 12px;
  letter-spacing: 1px;
}

.login-code-img {
  height: 40px;
  padding-left: 12px;
}

::v-deep(.el-checkbox__input.is-checked .el-checkbox__inner) {
  background-color: $dark-blue-bg;
  border-color: $dark-blue-bg;
  color: #ffffff;
}
</style>
