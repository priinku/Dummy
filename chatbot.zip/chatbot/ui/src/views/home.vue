<template>
  <div class="home-container">
    <div class="company-icon">
      <img src="@/assets/TWLogo.svg" alt="THIRDWAVE Logo" />
    </div>

    <div class="logout-button-container">
      <el-button size="small" type="danger" @click="logout">
        <!-- <el-icon>
          <SwitchButton />
        </el-icon> -->
        ログアウト &nbsp;&nbsp;
        <i class="fa-solid fa-right-from-bracket"></i>
      </el-button>
    </div>
    <div class="dashboard-header">
      <div class="AviaryLogo">
        <img src="../../public/aviaryIcon.svg" alt="Aviary Logo">
      </div>
      <h1>AVIARY</h1>
      <!-- <p>ようこそ</p> -->
    </div>

    <div class="grid-container">
      <div class="grid-item chat" @click="navigateTo('/chat')">
        <div class="icon-container">
          <i class="fas fa-comments"></i>
        </div>
        <div class="grid-content">
          <h2>ローカルチャットに相談</h2>
          <p>アップロード資料に基づいてAIとチャット</p>
        </div>
      </div>
      <div v-show="isAdminUser" class="grid-item file" @click="navigateTo('/file')">
        <div class="icon-container">
          <i class="fas fa-folder-open"></i>
        </div>
        <div class="grid-content">
          <h2>ファイル管理</h2>
          <p>ドキュメントのアップロードと管理</p>
        </div>
      </div>
      <!-- <div class="grid-item chatgpt disabled">
        <div class="icon-container"> <i class="fas fa-robot"></i> </div>
        <div class="grid-content">
          <h2>ChatGPTに相談</h2>
          <p>OpenAIのChatGPTと会話（近日公開）</p>
        </div>
      </div> -->
             <div class="grid-item translate" @click="navigateTo('/translate')">
         <div class="icon-container"> <i class="fas fa-robot"></i> </div>
         <div class="grid-content">
           <h2>翻訳</h2>
           <p>日本語と英語を翻訳する</p>
         </div>
       </div>
       <!-- <div class="grid-item file" @click="navigateTo('/flow')">
         <div class="icon-container">
           <i class="fas fa-folder-open"></i>
         </div>
         <div class="grid-content">
           <h2>FLOW</h2>
           <p>flow</p>
         </div>
       </div> -->
       <div class="grid-item summary" @click="navigateTo('/summary')">
         <div class="icon-container">
           <i class="fas fa-file-alt"></i>
         </div>
         <div class="grid-content">
           <h2>要約</h2>
           <p>ファイルをアップロードして要約を生成</p>
         </div>
       </div>
       <div v-show="isAdminUser" class="grid-item settings" @click="navigateTo('/settings')">
         <div class="icon-container">
           <i class="fas fa-cog"></i>
         </div>
         <div class="grid-content">
           <h2>設定</h2>
           <p>メールなどのプロフィール設定</p>
         </div>
       </div>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from "vue-router";
import { ElMessage, ElMessageBox } from "element-plus";
import { SwitchButton } from "@element-plus/icons-vue";
import useUserStore from "@/store/modules/user";

const router = useRouter();
const userStore = useUserStore();

const isAdminUser = userStore.roles.includes("admin");

const navigateTo = (path) => {
  router.push(path);
};

const openFeatureNotAvailable = () => {
  ElMessage({
    message: "この機能はまだ実装されていません",
    type: "info",
    duration: 3000,
  });
};

function logout() {
  ElMessageBox.confirm(
    "システムからログアウトし、退出しますか？",
    "ログアウト",
    {
      confirmButtonText: "ログアウト",
      cancelButtonText: "キャンセル",
      type: "warning",
    }
  )
    .then(() => {
      userStore.logOut().then(() => {
        location.href = "/home";
      });
    })
    .catch((e) => { console.error("リダイレクト失敗:", e); });
}

</script>

<style lang="scss" scoped>
@import "@/assets/styles/variables.module.scss";

.home-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  padding: 40px 20px 100px;
  background-color: $light-bg-alt;
  color: $text-dark;
}

.company-icon {
  position: absolute;
  top: 0px;
  right: 2%;
  height: 50px;
  margin-top: 2%;

  img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
}

.logout-button-container {
  position: absolute;
  top: 80px;
  right: 2%;
  z-index: 10;
  margin-top: 16px;

  .el-button {
    font-size: 1.2REM;
    padding: 18px 12px;
    border-radius: $border-radius-sm;
    border: none;
  }
}

.welcome-banner {
  width: 70%;
  max-width: 1000px;
  margin-bottom: 40px;
  padding: 30px;
  background: linear-gradient(135deg,
      rgba(49, 87, 170, 0.8) 0%,
      rgba(0, 30, 96, 0.9) 100%);
  border-radius: $border-radius-xl;
  backdrop-filter: blur(10px);
  box-shadow: $shadow-lg;
  border: 1px solid rgba(255, 255, 255, 0.1);
  position: relative;
  overflow: hidden;

  &::before {
    content: "";
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle at center,
        rgba(139, 172, 243, 0.1) 0%,
        transparent 60%);
    animation: shimmer 10s infinite linear;
    z-index: 0;
  }

  .welcome-text {
    text-align: center;
    position: relative;
    z-index: 1;

    h1 {
      font-size: 3rem;
      font-weight: 700;
      margin: 0;
      background: linear-gradient(90deg, #ffffff, #8bacf3);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      text-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    h2 {
      font-size: 2.2rem;
      font-weight: 600;
      margin: 5px 0 20px;
      color: $text-light;
      opacity: 0.9;
    }
  }

  .welcome-stats {
    display: flex;
    justify-content: center;
    gap: 50px;
    margin-top: 20px;
    position: relative;
    z-index: 1;

    .stat-item {
      display: flex;
      flex-direction: column;
      align-items: center;

      .stat-value {
        font-size: 2.5rem;
        font-weight: 700;
        color: #ffffff;
      }

      .stat-label {
        font-size: 1rem;
        color: rgba(255, 255, 255, 0.7);
        margin-top: 5px;
      }
    }
  }
}

.dashboard-header {
  text-align: center;
  margin-bottom: 40px;
  display: flex;
  flex-direction: column;
  align-items: center;

  h1 {
    font-size: 3.5rem;
    font-weight: 700;
    color: $text-dark;
    margin-top: 0px;
    margin-bottom: 8px;
    letter-spacing: 1rem;
    text-align: center;
  }

  p {
    font-size: 1.2rem;
    color: $text-dark;
  }

  .AviaryLogo {
    width: 50%;
    margin-top: 20%;
    margin-bottom: 24px;

    img {
      width: 100%;
      height: 100%;
      object-fit: contain;
    }
  }
}

.grid-container {
  display: flex;
  flex-wrap: wrap;
  gap: 30px;
  width: 100%;
  max-width: 1000px;
  justify-content: center;
}

.grid-item {
  background-color: $dark-glass;
  backdrop-filter: blur(10px);
  border-radius: $border-radius-lg;
  cursor: pointer;
  transition: $transition;
  display: flex;
  padding: 30px;
  box-shadow: $shadow;
  border: 1px solid rgba(255, 255, 255, 0.1);
  overflow: hidden;
  position: relative;
  flex: 0 0 calc(50% - 15px); 
  min-width: 300px; 

  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg,
        rgba(255, 255, 255, 0.1) 0%,
        transparent 100%);
    opacity: 0;
    transition: $transition;
  }

  &:hover {
    transform: translateY(-5px);
    box-shadow: $shadow-lg;

    &::before {
      opacity: 1;
    }

    .icon-container {
      transform: scale(1.1);
    }
  }

  &.chat {
    background: #ffffff;
    border-left: 4px solid $primary-color;
  }

  &.file {
    background: #ffffff;
    border-left: 4px solid $info;
  }

  &.chatgpt {
    background: #ffffff;
    border-left: 4px solid $success;
  }

  &.translate {
    background: #ffffff;
    border-left: 4px solid $success;
  }

  &.settings {
    background: #ffffff;
    border-left: 4px solid $warning;
  }

  &.summary {
    background: #ffffff;
    border-left: 4px solid #9c27b0;
  }

  &.disabled {
    opacity: 0.6;
    cursor: not-allowed;
    pointer-events: none;
    position: relative;

    &::after {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.05);
      z-index: 1;
    }
  }
}

.icon-container {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 60px;
  height: 60px;
  background-color: white;
  border-radius: 50%;
  margin-right: 20px;
  box-shadow: $shadow-sm;
  transition: $transition;
  flex-shrink: 0;

  i {
    font-size: 24px;
  }

  .chat & i {
    color: $primary-color;
  }

  .file & i {
    color: $info;
  }

  .chatgpt & i {
    color: $success;
  }

  .settings & i {
    color: $warning;
  }

  .summary & i {
    color: #9c27b0;
  }
}

.grid-content {
  display: flex;
  flex-direction: column;
  justify-content: center;

  h2 {
    font-size: 1.3rem;
    font-weight: 600;
    margin: 0 0 8px;
    color: $text-dark;
  }

  p {
    font-size: 0.95rem;
    color: $text-dark;
    opacity: 0.7;
    margin: 0;
  }
}

@keyframes shimmer {
  0% {
    transform: rotate(0deg);
  }

  100% {
    transform: rotate(360deg);
  }
}

@media (max-width: 768px) {
  .welcome-banner {
    padding: 20px;

    .welcome-text {
      h1 {
        font-size: 2.2rem;
      }

      h2 {
        font-size: 1.8rem;
      }
    }

    .welcome-stats {
      gap: 30px;

      .stat-item {
        .stat-value {
          font-size: 2rem;
        }

        .stat-label {
          font-size: 0.9rem;
        }
      }
    }
  }

  .grid-container {
    justify-content: center;
  }

  .grid-item {
    padding: 20px;
    flex: 0 0 100%; 
    min-width: auto;
  }

  .icon-container {
    width: 50px;
    height: 50px;
    min-width: 50px;

    i {
      font-size: 20px;
    }
  }

  .grid-content h2 {
    font-size: 1.3rem;
  }
}
</style>
