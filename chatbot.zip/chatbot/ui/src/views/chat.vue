<template>
  <div class="chat-page-container">
    <!-- ホームページに戻るボタン -->
    <div class="home-button-fixed">
      <el-button type="primary" icon="Back" @click="navigateToHome"></el-button>
    </div>

    <!-- 左側の履歴欄 -->
    <div class="sidebar-left" 
         :class="{ 'collapsed': leftSidebarCollapsed }"
         @mouseenter="handleSidebarMouseEnterWithCancel"
         @mouseleave="handleSidebarMouseLeave">
      <div class="sidebar-content" v-show="!leftSidebarCollapsed">
        <!-- サイドバーのタイトルとクリアボタン -->

        <div class="new-chat-button">
          <el-button type="primary" :disabled="isGeneratingContent || newChatButtonDisabled" @click="newchat">新しいチャット</el-button>
        </div>

        <div class="history-header">
          <h3>チャット履歴</h3>
        </div>
        <div class="history-list">
          <div v-for="(item, index) in chatHistoryList" :key="index" class="history-item" @click="loadChatHistory(index)"
            :class="{ 'active': activeChatIndex === index }">
            <div class="history-item-content">
              {{ item.title || `過去のチャット ${index + 1}` }}
            </div>
            <div class="history-item-actions">
              <el-button class="history-action-btn" type="link" icon="Edit"
                @click="openRenameDialog(index)"></el-button>
              <el-button class="history-action-btn" type="link" icon="Delete"
                @click="confirmDeleteChat(index)"></el-button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 中間チャットエリア -->
    <div class="chat-main-area" :class="{ 'input-focused': isFocused }">
      <!-- <div class="chat-header">
          <div class="chat-title">
            <h2>ローカルチャット</h2>
          </div>
          <div class="chat-actions">
            <el-tooltip content="チャットをクリア" placement="top">
              <el-button
                :disabled="message.length === 0"
                type="danger"
                @click="newchat()"
                icon="Delete"
                circle
              />
            </el-tooltip>
          </div>
        </div> -->

      <div class="answer-container">
        <div class="scroll-container" ref="scrollDiv" @scroll="onScroll">
          <p v-if="loadScroll">
            <el class="loading-center" v-loading="loadScroll"></el>
          </p>
          <ul class="message-list" ref="container">
            <div v-if="message.length === 0" class="typewriter">
              <p>ローカルチャットへようこそ</p>
            </div>
            <li v-for="(item, index) in message" :key="index" class="list-item">
              <div v-if="item.role == 'user'" class="user-message">
                <div class="user-content">
                  <MdPreview class="user-preview" :autoFoldThreshold="9999" :editorId="id" :modelValue="item.message"
                    language="en-US" />
                </div>
              </div>
              <div v-else class="assistant-message">
                <div class="avatar-container">
                  <el-avatar :size="60" src="aviaryIcon.svg" fit="contain" />
                  <div
                    v-if="index === message.length - 1 && item.role === 'assistant' && !(item.status === 'FINISHED' || item.status === 'CANCEL' || item.status === 'FAILED')"
                    class="answering-label">
                    回答中...
                  </div>
                </div>
                <svg-icon :icon-class="item.webSearch == 1 ? 'world-search' : ''" />
                <div class="message-content">
                  <div v-if="contentGenLoading && item.message == ''" class="generating-indicator">
                    <span class="dot"></span>
                    <span class="dot"></span>
                    <span class="dot"></span>
                  </div>
                  <div v-else class="assistant-content">
                    <MdPreview :autoFoldThreshold="9999" :editorId="id" :modelValue="item.message" language="en-US" />
                  </div>
                <div v-if="shouldShowFeedback(item, index)" class="feedback-icons">
                  <svg-icon icon-class="mood-happy" class="feedback-btn good-btn" @click="updateStatus('GOOD', item.id, index)" />
                  <svg-icon icon-class="mood-sad-dizzy" class="feedback-btn not-good-btn" @click="updateStatus('NOT_GOOD', item.id, index)" />
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>

      <div class="input-area">
        <div class="input-container glass-panel-light" :class="{ 'compact': !isFocused && !userInput }">
          <div class="input-wrapper">
            <el-input class="chat-input" id="q-input"
              :autosize="{ minRows: isFocused || userInput ? 4 : 1, maxRows: 10 }" v-model="userInput"
              placeholder="質問を自由に入力" type="textarea" @keydown.enter.exact="downEnter"
              @keydown.enter.shift="insertNewLine" @focus="isFocused = true" @blur="isFocused = false" />
            <div class="input-controls">
              <el-tooltip v-if="!contentGenLoading" content="送信" placement="top">
                <el-button v-if="!contentGenLoading" class="send-button" :disabled="contentGenLoading" type="primary"
                  circle @click="gen()">
                  <el-icon>
                    <Position />
                  </el-icon>
                </el-button>
              </el-tooltip>
              <!-- 新增檔案搜索開關 -->
              <!-- <div class="file-search-toggle">
                <el-switch v-model="fileSearchEnabled" active-text="ファイル検索" @change="toggleFileSearch" />
              </div>
              <div class="file-search-toggle">
                <el-switch v-model="allFileSearchEnabled" active-text="全文検索" />
              </div>
              <div class="file-search-toggle">
                <el-switch v-model="useMcp" active-text="mcp" />
              </div> -->
              <!-- <el-tooltip v-if="!contentGenLoading" content="送信" placement="top">
                  <el-button v-if="!contentGenLoading" class="send-button" :disabled="contentGenLoading" type="primary"
                    circle @click="gen()">
                  <el-icon>
                    <Position />
                  </el-icon>
                </el-button>
              </el-tooltip> -->
              <el-tooltip v-if="contentGenLoading" content="キャンセル" placement="top">
                <el-button v-if="contentGenLoading" class="send-button" type="primary" circle @click="stop()">
                  <el-icon>
                    <CloseBold />
                  </el-icon>
                </el-button>
              </el-tooltip>
            </div>
          </div>
          <span class="input-notice">
            誤出力が発生する可能性があります。
          </span>
        </div>
      </div>
    </div>

    <!-- 右側のファイル選択領域 -->
    <!-- <div class="sidebar-right" :class="{ 'collapsed': !fileSearchEnabled || rightSidebarCollapsed }">
      <div class="sidebar-toggle" @click="toggleRightSidebar">
        <i :class="rightSidebarCollapsed ? 'fas fa-chevron-left' : 'fas fa-chevron-right'"></i>
      </div>

      <div class="sidebar-content" v-show="!rightSidebarCollapsed && fileSearchEnabled">
        <div class="file-section-header">
          <h3>ファイル</h3>
          <el-button v-show="isAdminUser" type="primary" @click="navigateToFilePage" class="toFile">
            ファイルへ→
          </el-button>
        </div>

        <!-- ファイルアップロードエリア -->
    <!-- <div class="upload-section">
            <el-button type="primary" plain icon="Plus" @click="openUploadDialog">
              ファイルアップロード
            </el-button>
          </div> 
        <div class="file-list-section">
          <el-table v-loading="tagLoading" :data="taggedfileTable" :tree-props="treeProps" row-key="displayId"
            style="width: 100%" size="large" @selection-change="handleFileSelectionChange">
            <el-table-column type="selection" width="40" />
            <el-table-column label="タグ/ファイル名" prop="name" :show-overflow-tooltip="true">
            </el-table-column>

            
            <el-table-column label="操作" width="80" align="center">
              <template #default="scope">
                <div class="file-actions">
                  <el-button size="small" icon="View" @click="previewFile(scope.row)" title="閲覧" />
            <el-button size="small" icon="Delete" type="danger" @click="deleteFile(scope.row)" title="削除" />
            
                </div>
              </template>
</el-table-column>

</el-table>
</div>
</div>
</div> -->

    <!-- ダイアログボックス -->
    <el-dialog v-if="!feedbackCheck" v-model="commentDialog" title="フィードバック" width="740" class="dialog glass-panel">
      <span>
        <div class="label-container" style="display: flex; justify-content: center; align-items: start">
          <div style="
                white-space: pre;
                margin-top: 10px;
                margin-right: 16px;
                color: white;
              ">
            質問
          </div>
          <MdPreview :autoFoldThreshold="9999" :modelValue="q" />
        </div>
        <div class="label-container" style="display: flex; justify-content: center; align-items: start">
          <div style="
                white-space: pre;
                margin-top: 10px;
                margin-right: 16px;
                color: white;
              ">
            回答
          </div>
          <MdPreview :autoFoldThreshold="9999" :modelValue="a" />
        </div>
        <div style="margin-top: 16px">
          <el-input style="height: 100%" id="q-input" :autosize="{ minRows: 5, maxRows: 10 }" v-model="feedbackComment"
            placeholder="フィードバックを入力" type="textarea" />
        </div>
      </span>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="commentDialog = false">キャンセル</el-button>
          <el-button type="primary" @click="updateComment(feedbackComment, commentId, commentIndex)">送信</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 名前変更ダイアログ -->
    <el-dialog v-model="renameDialogVisible" title="チャットの名前を変更" width="500" class="dialog glass-panel">
      <el-form :model="renameForm" @submit.prevent="handleRenameConfirm">
        <el-form-item label="新しいチャット名">
          <el-input v-model="renameForm.newName" placeholder="新しいチャット名を入力してください" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="renameDialogVisible = false">キャンセル</el-button>
          <el-button type="primary" @click="handleRenameConfirm">保存</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 削除確認ダイアログ -->
    <el-dialog v-model="confirmDeleteDialog" title="確認" width="500" class="dialog glass-panel">
      <div style="color: white;">{{ confirmDeleteMessage }}</div>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="confirmDeleteDialog = false">キャンセル</el-button>
          <el-button type="danger" @click="proceedWithDelete">削除</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- ファイルアップロードダイアログ -->
    <el-dialog v-model="uploadDialogVisible" title="ファイルアップロード" width="500px" class="dialog glass-panel">
      <el-form ref="uploadFormRef" :model="uploadForm" :rules="uploadRules" label-width="100px">
        <el-form-item label="ファイル" prop="file">
          <el-upload class="upload-demo" drag action="" multiple :auto-upload="false" :file-list="uploadForm.fileList"
            :on-change="handleFileChange" :on-remove="handleFileRemove">
            <i class="el-icon-upload"></i>
            <div class="el-upload__text">
              ここに複数のファイルをドラッグまたはクリックで選択
            </div>
          </el-upload>
        </el-form-item>
        <el-form-item label="タグ" prop="tags">
          <el-select v-model="uploadForm.tags" multiple placeholder="タグを追加">
            <el-option v-for="tag in tagOptions" :key="tag.value" :label="tag.label" :value="tag.value" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submitUploadForm">確定</el-button>
          <el-button @click="cancelUpload">キャンセル</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup name="Chat">
import { MdPreview } from "md-editor-v3";
import "md-editor-v3/lib/preview.css";

import { ref, nextTick, onMounted, onUnmounted, computed, getCurrentInstance, reactive } from "vue";
import {
  addTask,
  listTask,
  listTaskOutput,
  updateTaskOutput,
  reNameTaskOutput,
  deleteTaskOutput,
  stopTaskOutput,
  getChatTitle,
  sendFeedbackToCache
} from "@/api/task";

import { listFile, uploadFile, deleteFile, listTag } from "@/api/file";

import { useRouter } from 'vue-router';
import { ElMessage, ElMessageBox } from 'element-plus'
import ngwords from '@/../../config/ngwords.json';
import useUserStore from "@/store/modules/user";
const userStore = useUserStore();


var POLLING_INTERVALS = {
  FIRST_POLL: 3000,    
  SUBSEQUENT_POLL: 200, 
  SECOND_POLL: 3000     
};

var gSECOND_POLL = 3000

const isAdminUser = userStore.roles.includes("admin");

const { proxy } = getCurrentInstance();
const type = ref("CHAT");
const router = useRouter();

const fileList = ref([]);
const taskList = ref([]);
const taskOutputList = ref([]);
const loading = ref(true);
const contentGenLoading = ref(false);
const commentDialog = ref(false);
const total = ref(0);
const chatId = ref("");
const fieldSort = ref(0);
const latestOutputId = ref("latest");
const init = ref(false);
const fileId = ref([]);
const useMcp = ref(false);
const commentId = ref("");
const commentIndex = ref(0);
const q = ref("");
const a = ref("");
const emptyChatTaskId = ref(null)
// 名称変更ダイアログの表示状態
const renameDialogVisible = ref(false);
// 名称変更フォームのデータ
const renameForm = ref({
  newName: '',
  taskId: null,
});
// 選択されたチャット
const selectedChat = ref(null);

// サイドバー折りたたみ狀態 - 默認收起
const leftSidebarCollapsed = ref(true);
const rightSidebarCollapsed = ref(false);
const fileSearchEnabled = ref(true);
const allFileSearchEnabled = ref(true);

// チャット履歴関連
const chatHistoryList = ref([]);
const activeChatIndex = ref(0);
const chatCounter = ref(0);

// 削除確認関連
const confirmDeleteDialog = ref(false);
const confirmDeleteMessage = ref('');
const deleteActionType = ref('');
const chatIndexToDelete = ref(-1);

// ファイル関連
const fileLoading = ref(false);
const selectedFiles = ref([]);
const selectAllFiles = ref(false);
const tagOptions = ref([]);
const tagLoading = ref(false);
const taggedfileTable = ref([]);
const newChatButtonDisabled = ref(false);

// 檢查是否正在生成內容（用於禁用新增聊天按鈕）
const isGeneratingContent = computed(() => {
  // 如果 contentGenLoading 為 true，則禁用
  if (contentGenLoading.value) {
    return true;
  }
  
  // 檢查最後一條消息的狀態
  if (message.value.length > 0) {
    const lastMessage = message.value[message.value.length - 1];
    // 如果最後一條是 assistant 消息
    if (lastMessage.role === 'assistant') {
      // 如果有 status 屬性，檢查是否已完成
      if (lastMessage.status) {
        const finishedStatuses = ['FINISHED', 'CANCEL', 'FAILED'];
        // 如果狀態不是已完成狀態，則禁用
        if (!finishedStatuses.includes(lastMessage.status)) {
          return true;
        }
      } else if (lastMessage.message === '') {
        // 如果沒有 status 但消息為空，可能正在生成，禁用
        return true;
      }
    }
  }
  
  return false;
});

const treeProps = reactive({
  children: 'children',    // 子要素フィールド名
  hasChildren: 'hasChildren', // hasChildren===true の行だけ展開可能
  checkStrictly: false     // 親子連動／独立選択
})

// アップロードダイアログ関連
const uploadDialogVisible = ref(false);
const uploadFormRef = ref(null);
const uploadForm = ref({
  file: null,
  fileList: [],
  tags: []
});
const uploadRules = {
  file: [{ required: true, message: 'ファイルを選択してください', trigger: 'change' }]
};

// 他の変数の場所に追加する
const isFocused = ref(false);

// サイドバーの状態を切り替える
const toggleLeftSidebar = () => {
  leftSidebarCollapsed.value = !leftSidebarCollapsed.value;
};

// マウスがサイドバーに入ると展開
const handleSidebarMouseEnter = () => {
  leftSidebarCollapsed.value = false;
};

// マウスがサイドバーから離れると折りたたむ（高速移動時のちらつき防止のため遅延）
let sidebarLeaveTimer = null;
const handleSidebarMouseLeave = () => {
  sidebarLeaveTimer = setTimeout(() => {
    leftSidebarCollapsed.value = true;
  }, 200);
};

// マウスが再進入するとタイマーをリセット
const handleSidebarMouseEnterWithCancel = () => {
  if (sidebarLeaveTimer) {
    console.log(sidebarLeaveTimer)
    clearTimeout(sidebarLeaveTimer);
    sidebarLeaveTimer = null;
  }
  leftSidebarCollapsed.value = false;
};

const toggleRightSidebar = () => {
  rightSidebarCollapsed.value = !rightSidebarCollapsed.value;
  if (!rightSidebarCollapsed.value) {
    fileSearchEnabled.value = true;
  }
};

// ファイル検索スイッチ
const toggleFileSearch = () => {
  if (fileSearchEnabled.value) {
    rightSidebarCollapsed.value = false;
  } else {
    rightSidebarCollapsed.value = true;
  }
};

// 名称変更ダイアログを開く
const openRenameDialog = (index) => {
  if (contentGenLoading.value === true) {
    ElMessage.warning("生成中のコンテンツがあります。完了するまで待ってください。");
  } else {
    const chat = chatHistoryList.value[index];
    //console.log(chat);
    renameForm.value.newName = chat.title ? chat.title : '';
    renameForm.value.taskId = chat.id;
    selectedChat.value = chat;
    renameDialogVisible.value = true;
  }
};

// 名称変更の実行
const handleRenameConfirm = async () => {
  try {
    reNameTaskOutput({
      taskId: renameForm.value.taskId ? renameForm.value.taskId : latestOutputId.value,
      data: {
        newName: renameForm.value.newName,
      },
    }).then((response) => {
      if (response.code !== 200) {
        ElMessage.error(response.message);
        return;
      }

      ElMessage({
        type: 'success',
        message: `チャット名を変更しました`,
      });
      renameDialogVisible.value = false;
      getTaskList(); // リストを更新
    });
  } catch (error) {
    console.error(error);
    ElMessage.error('名称変更に失敗しました');
  }
};

// 削除確認ダイアログ
const confirmDeleteChat = (index) => {
  if (contentGenLoading.value === true) {
    ElMessage.warning("生成中のコンテンツがあります。完了するまで待ってください。");
  } else {
    const chat = chatHistoryList.value[index];
    console.log(chat);
    ElMessageBox.confirm(
      `チャット ${chat.title} を削除しますか？`,
      '確認',
      {
        confirmButtonText: '削除',
        cancelButtonText: 'キャンセル',
        type: 'warning',
      }
    ).then(() => {
      deleteChat(chat.id);
    }).catch(() => {
      ElMessage({
        type: 'info',
        message: '削除をキャンセルしました',
      });
    });
  }
};

// Deletion process
const deleteChat = async (id) => {
  try {
    deleteTaskOutput({
      taskId: id,
    }).then((response) => {
      if (response.code !== 200) {
        ElMessage.error(response.message);
        return;
      }

      ElMessage({
        type: 'success',
        message: `チャットを削除しました`,
      });
      getTaskList(); // リストを更新

      // 最新のチャットに切り替え
      taskList.value.sort((a, b) => b.id - a.id);
      if (taskList.value.length > 0) {
        chatId.value = taskList.value[0].id;
      } else {
        // チャットがなくなった場合の処理
        init.value = true;
        gen();
        getTaskList();
      }
    });
  } catch (error) {
    console.error(error);
    ElMessage.error('チャット削除に失敗しました');
  }
};

const proceedWithDelete = () => {
  if (deleteActionType.value === 'single' && chatIndexToDelete.value >= 0) {
    chatHistoryList.value.splice(chatIndexToDelete.value, 1);
    if (chatHistoryList.value.length === 0) {
      newchat();
    } else if (activeChatIndex.value >= chatHistoryList.value.length) {
      loadChatHistory(chatHistoryList.value.length - 1);
    } else {
      loadChatHistory(activeChatIndex.value);
    }
  } else if (deleteActionType.value === 'all') {
    chatHistoryList.value = [];
    newchat();
  }

  saveChatHistoryToStorage();
  confirmDeleteDialog.value = false;
};

// チャット履歴をローカルストレージに保存
const saveChatHistoryToStorage = () => {
  localStorage.setItem('chatHistory', JSON.stringify(chatHistoryList.value));
};

// チャット履歴を読み込み中
const loadChatHistory = (index) => {
  if (contentGenLoading.value === true) {
    ElMessage.warning("生成中のコンテンツがあります。完了するまで待ってください。");
  } else {
    activeChatIndex.value = index;
    if (chatHistoryList.value[index]) {
      // ここにはAPIまたはローカルストレージから具体的なチャット内容をロードする必要があります。
      chatId.value = chatHistoryList.value[index].id || '';
      if (chatId.value) {
        // 更新前に表示をリセット
        message.value = [];
        fieldSort.value = 0;
        getTaskOutputList(chatId.value, 1);
      }
    }
  }
};

// タイプライター効果関連
const typewriterContent = ref('ローカルチャットへようこそ');

// 元のオプションを保持する
const mcpOptions = [
  { value: 0, label: "いいえ" },
  { value: 1, label: "はい" },
];

// 利用可能なファイルのシミュレーション
const availableFiles = ref([
  { id: 1, name: '会社概要.pdf' },
  { id: 2, name: '製品マニュアル.pdf' },
  { id: 3, name: '顧客データ.xlsx' },
  { id: 4, name: 'プレゼン資料.pptx' },
  { id: 5, name: '研究レポート.pdf' },
]);

// 元のページング関連パラメータを保持する
const queryParams = ref({
  pageNum: 1,
  pageSize: 100,
  type: type.value,
});

const count = ref(1);
const loadScroll = ref(false);
const noMore = ref(false);
const scrollDiv = ref(null);
const isTyping = ref(false);
const onScroll = () => {
  const el = scrollDiv.value;
  if (!el) return;

  // スクロール位置が上に到達かつデータがまだあり・読み込み中でない場合
  if (el.scrollTop === 0 && !noMore.value && !loadScroll.value) {
    loadMessages();
  }
};

// さらに多くのニュースを読み込む
const loadMessages = async () => {
  // console.log(chatId.value);
  if (chatId.value === "") {
  } else {
    const time = 500;
    const beforeHeight = scrollDiv.value.scrollHeight;

    loadScroll.value = true;
    count.value += 1;
    setTimeout(() => {
      getTaskOutputList(chatId.value, count.value);
    }, time);

    await new Promise((resolve) => setTimeout(resolve, time + 100));
    await nextTick();

    const afterHeight = scrollDiv.value.scrollHeight;
    const delta = afterHeight - beforeHeight;
    scrollDiv.value.scrollTop = delta + scrollDiv.value.scrollTop - 34;

    loadScroll.value = false;
  }
};

// 既存のユーザー入力関連機能を保持する
const userInput = ref("");
const message = ref([]);
const feedbackComment = ref("");
const feedbackCheck = ref(false);

function getTaskList() {
  loading.value = true;
  // チャットを内容を一度クリア
  message.value = [];
  fieldSort.value = 0;

  // // Ragファイルの一覧を取得
  // listFile({ pageNum: 1, pageSize: 1000 }).then((response) => {
  //   fileList.value = response.result.rows;
  // });
  // チャットの一覧を取得
  listTask(queryParams.value).then(async (response) => {
    taskList.value = response.result.rows;
    total.value = response.result.count;

    const existingEmpty = taskList.value.find((t) => t.status === "EMPTY");
    if (existingEmpty && existingEmpty.id) {
      emptyChatTaskId.value = existingEmpty.id;
    } else {
      emptyChatTaskId.value - null
    }

    //チャットカウンターを既存のチャット数で初期化
    if(chatCounter.value === 0 ) {
      chatCounter.value = taskList.value.length;
    }

    if (taskList.value.length > 0) {
      // チャットが存在する場合、最初のチャットを選択
      chatId.value = taskList.value[0].id;
      // チャットの内容を取得
      getTaskOutputList(chatId.value, 1);
    } else {
      // チャットが存在しない場合、チャットを新規作成
      init.value = true;
      gen();
      await new Promise((resolve) => setTimeout(resolve, 100));
      await nextTick();
      getTaskList();
    }
    // チャットの一覧をchatHistoryListに保存
    // 1) 基本標題：優先採用非空字串的 formData/form_data，否則用「新しいチャット n」
    // 2) 去重：同名標題將自動附加 (2)、(3)... 後綴
    const seenTitles = new Map();
    chatHistoryList.value = taskList.value.map((task, index) => {
      const baseTitle = (typeof task.formData === 'string' && task.formData.trim())
        ? task.formData.trim()
        : (typeof task.form_data === 'string' && task.form_data.trim())
          ? task.form_data.trim()
          : `新しいチャット ${index + 1}`;

      const curr = seenTitles.get(baseTitle) || 0;
      const next = curr + 1;
      seenTitles.set(baseTitle, next);

      const uniqueTitle = curr === 0 ? baseTitle : `${baseTitle} ${next}`;
      return {
        id: task.id,
        title: uniqueTitle,
      };
    });

    loading.value = false;
  });
}

// チャットの内容を取得
// Retrieve chat content
function getTaskOutputList(taskId, pageNum) {
  listTaskOutput({ pageNum: pageNum, pageSize: 5, taskId }).then((response) => {
    if (response.result.rows.length === 0) {
      return;
    }
    taskOutputList.value = response.result.rows;
    taskOutputList.value.sort((a, b) => b.sort - a.sort);
    latestOutputId.value =
      taskOutputList.value[taskOutputList.value.length - 1].id;
    if (taskOutputList.value.length > 0) {

      fieldSort.value =
        Math.max(fieldSort.value, taskOutputList.value[0].sort) + 1;
      taskOutputList.value.forEach((op) => {
        const user = {
          role: "user",
          message: JSON.parse(op.metadata).prompt.toString(),
        };
        
        if (op.content) {
          
          message.value.unshift(user, {
            role: "assistant",
            message: op.content,
            id: op.id,
            feedback: JSON.parse(op.feedback),
          });
          message.value[message.value.length - 1].status = op.status;
          if (pageNum === 1) {
            setTimeout(() => {
              scrollToBottom();
            }, 50);
          }
        } else if (op.status === "WAIT" || op.status === "IN_PROCESS") {

          contentGenLoading.value = true;
          message.value.unshift(user, { role: "assistant", message: "" });
          message.value[message.value.length - 1].status = op.status;

          if (pageNum === 1) {
            setTimeout(() => {
              scrollToBottom();
            }, 50);
          }

          // リセット関数
          const reset = (timer) => {
            contentGenLoading.value = false;
            clearTimeout(timer); // clearIntervalではなくclearTimeoutを使用する
          };

          let pollCount = 0; // ポーリングカウンタ
          let timer = null;

          const startPolling = () => {
            const poll = () => {
              pollCount++;
              const currentInterval = pollCount === 1 
                ? POLLING_INTERVALS.FIRST_POLL 
                : POLLING_INTERVALS.SUBSEQUENT_POLL;
              
              console.log(`ポーリング回数: ${pollCount} 回目、間隔: ${currentInterval}ms`);
              
              listTaskOutput({
                pageNum: 1,
                pageSize: 1000,
                taskId: response.result.taskId,
              }).then((response) => {
                if (response.result.rows && response.result.rows.length > 0) {
                  const t = response.result.rows.filter(
                    (output) => output.sort === fieldSort.value - 1
                  )[0];
                  
                  if (t) {
                    if (t.status === "FINISHED") {
                      if (message.value[message.value.length - 1].message === "") {
                        message.value[message.value.length - 1].message = t.content;
                        message.value[message.value.length - 1].id = t.id;
                        message.value[message.value.length - 1].feedback = JSON.parse(
                          t.feedback
                        );
                      }
                      reset(timer);
                    } else if (t.status === "FAILED") {
                      proxy.$modal.msgSuccess(
                        `生成に失敗しました。失敗の理由: ${t.content}`
                      );
                      message.value[message.value.length - 1].status = "FAILED";
                      reset(timer);
                    } else if (t.status === "CANCEL") {
                      message.value[message.value.length - 1].message = "CANCEL";
                      message.value[message.value.length - 1].id = t.id;
                      message.value[message.value.length - 1].feedback = JSON.parse(
                        t.feedback
                      );
                      reset(timer);
                    } else {
                      // タスクはまだ進行中です。引き続きポーリングを続けます。
                      // 二度目以降は短い間隔で使用する
                      const nextInterval = pollCount === 1 
                        ? POLLING_INTERVALS.FIRST_POLL 
                        : POLLING_INTERVALS.SUBSEQUENT_POLL;
                      timer = setTimeout(poll, nextInterval);
                    }
                  } else {
                    console.log("No task output found with sort:", fieldSort.value - 1);
                    // 対応する出力がありません。ポーリングを続行します。
                    const nextInterval = pollCount === 1 
                      ? POLLING_INTERVALS.FIRST_POLL 
                      : POLLING_INTERVALS.SUBSEQUENT_POLL;
                    timer = setTimeout(poll, nextInterval);
                  }
                } else {
                  console.log("No task output found for taskId:", response.result.taskId);
                  // タスク出力が検出されませんでした。ポーリングを続行します。
                  const nextInterval = pollCount === 1 
                    ? POLLING_INTERVALS.FIRST_POLL 
                    : POLLING_INTERVALS.SUBSEQUENT_POLL;
                  timer = setTimeout(poll, nextInterval);
                }
              }).catch((error) => {
                console.error("輪詢請求失敗:", error);
                // エラーが発生した場合もポーリングを継続する（または停止を選択する）
                const nextInterval = pollCount === 1 
                  ? POLLING_INTERVALS.FIRST_POLL 
                  : POLLING_INTERVALS.SUBSEQUENT_POLL;
                timer = setTimeout(poll, nextInterval);
              });
            };
            // 最初のポーリングの前に指定時間を待機する
            timer = setTimeout(poll, POLLING_INTERVALS.FIRST_POLL);
          };
          
          startPolling();
        }
        
        if (response.result.count === message.value.length / 2) {
          noMore.value = true;
        }
      });
    }
  });
}

function downEnter(e) {
  e.preventDefault();
  isFocused.value = false;
  gen();
}

var gtimer;
async function gen() {
  const string = userInput.value;
  const words = ngwords || [];
  const containWords = words.filter(word => string.includes(word));
  if (containWords.length > 0) {
    try {
      await ElMessageBox.confirm(
        `入力に不適切な表現が含まれている可能性があります。<br>` +
        `このまま送信しますか？<br>` +
        `<b>対象ワード: ${containWords.join(", ")}</b>`,
        '確認',
        {
          confirmButtonText: '送信する',
          cancelButtonText: 'キャンセル',
          type: 'warning',
          dangerouslyUseHTMLString: true
        }
      );
    } catch {
      // キャンセルが押された場合
      proxy.$modal.msgSuccess(`送信がキャンセルされました`);
      return;
    }
  }
  console.log("containWords", containWords.join(", "));

  if (init.value) {
    addTask({
      type: type.value,
      formData: {},
    }).then((response) =>{
      if(response && response.code ===2000){
        const createdId =response.result?.taskId;
        if (createdId) {{
          chatId.value = createdId;
          emptyChatTaskId.value = createdId
        }}
      }
    });
    init.value = false;
    return;
  } else if (!userInput.value) {
    return;
  }
  if (contentGenLoading.value) {
    preventDefault();
    return;
  }

  const prompt = userInput.value.trim();
  if (!prompt) {
    proxy.$modal.msgSuccess("質問を入力してください");
    return;
  }
  if(emptyChatTaskId.value) {
    emptyChatTaskId.value = null;
  }
  userInput.value = "";

  setTimeout(() => {
    scrollToBottom();
  }, 50);

  message.value.push({
    role: "user",
    message: prompt,
  });
  message.value.push({
    role: "assistant",
    message: "",
  });

  contentGenLoading.value = true;
  fieldSort.value = fieldSort.value + 1;

  let fileIdArray = [];
  if (fileSearchEnabled.value) {
    // 検索チェックがONの場合
    if (fileId.value.length !== 0) {
      fileIdArray = [...fileId.value];
    }
  }
  console.log("formdata", {
    prompt,
    fieldSort: fieldSort.value,
    fileId: fileIdArray,
    allFileSearch: allFileSearchEnabled.value,
    useMcp: useMcp.value,
  });

  addTask({
    type: type.value,
    formData: chatId.value
      ? {
        prompt,
        fieldSort: fieldSort.value,
        fileId: fileIdArray,
        allFileSearch: allFileSearchEnabled.value,
        useMcp: useMcp.value,
        taskId: chatId.value,
      }
      : {
        prompt,
        fieldSort: fieldSort.value,
        fileId: fileIdArray,
        allFileSearch: allFileSearchEnabled.value,
        useMcp: useMcp.value,
      },
  }).then((response) => {
    if (response.code !== 200) {
      proxy.$modal.msgSuccess(response.message);
      contentGenLoading.value = false;
      return;
    }

    setTimeout(() => {
      scrollToBottom();
    }, 50);

    const reset = (timer) => {
      contentGenLoading.value = false;
      if (fieldSort.value === 1) {
        const query = { chatId: chatId.value };
        getChatTitle(query).then((response) => {
          if (response.code === 200) {
            const rows = response.result?.rows || [];
            if (rows.length > 0) {
              const data = rows[0] || {};
              const title = data.form_data ?? data.formData ?? "";
              if (title) {
                const chat = chatHistoryList.value.find(item => item.id === chatId.value);
                if (chat) {
                  chat.title = title;
                }
              }
            }
          }
        });
      }
      if (timer) {
        clearTimeout(timer);
      }
    };

    gtimer  =  setInterval(() => {
          gSECOND_POLL = 200;
          console.log( gSECOND_POLL);
          listTaskOutput({
            pageNum: 1,
            pageSize: 1000,
            taskId: response.result.taskId,
          }).then((response) => {
            if (!chatId.value) {
              chatId.value = response.result.rows[0].taskId;
            }
            const t = response.result.rows.filter(
              (output) => output.sort === fieldSort.value
            )[0];
            latestOutputId.value = t.id;

            if (t.status === "PROCESSING") {
              message.value[message.value.length - 1].status = "IN_PROCESS";
              message.value[message.value.length - 1].id = t.id;
              message.value[message.value.length - 1].feedback = JSON.parse(
                t.feedback
              );
              const lastMsgObj = message.value[message.value.length - 1].message;
              const fullContent = t.content;
              const displayed = lastMsgObj;
              if (fullContent.length > displayed.length) {
                const newText = fullContent.slice(displayed.length);
                startTypewriterEffect(newText);
              }
            } else if (t.status === "FINISHED" && isTyping.value) {
              // No action needed when typing is in progress and status is FINISHED
              message.value[message.value.length - 1].status = "FINISHED";
            } else if (t.status === "FINISHED" && !isTyping.value) {
              message.value[message.value.length - 1].id = t.id;
              message.value[message.value.length - 1].feedback = JSON.parse(
                t.feedback
              );
              const lastMsgObj = message.value[message.value.length - 1].message;
              const fullContent = t.content;
              const displayed = lastMsgObj;
              if (fullContent.length > displayed.length) {
                const newText = fullContent.slice(displayed.length);
                startTypewriterEffect(newText);
              }
              message.value[message.value.length - 1].status = "FINISHED";
              reset(gtimer);

            } else if (t.status === "FAILED") {
              proxy.$modal.msgSuccess(
                `生成に失敗しました。失敗の理由: ${t.content}`
              );
              message.value[message.value.length - 1].status = "FAILED";
              reset(gtimer);
            } else if (t.status === "CANCEL" && isTyping.value) {
              message.value[message.value.length - 1].id = t.id;
              message.value[message.value.length - 1].feedback = JSON.parse(
                t.feedback
              );
              message.value[message.value.length - 1].status = "CANCEL";
              message.value[message.value.length - 1].message = t.content ? t.content : "CANCEL";
              reset(gtimer);
            } else if (t.status === "CANCEL" && !isTyping.value) {
              // message.value[message.value.length - 1].message = "CANCEL";
              message.value[message.value.length - 1].id = t.id;
              message.value[message.value.length - 1].feedback = JSON.parse(
                t.feedback
              );
              message.value[message.value.length - 1].status = "CANCEL";
              message.value[message.value.length - 1].message = t.content ? t.content : "CANCEL";
              reset(gtimer);
            } else {
              message.value[message.value.length - 1].status = "IN_PROCESS";
            }
          });
          reset(gtimer);


          gtimer  =  setInterval(() => {
          gSECOND_POLL = 200;
          console.log( gSECOND_POLL);
          listTaskOutput({
            pageNum: 1,
            pageSize: 1000,
            taskId: response.result.taskId,
          }).then((response) => {
            if (!chatId.value) {
              chatId.value = response.result.rows[0].taskId;
            }
            const t = response.result.rows.filter(
              (output) => output.sort === fieldSort.value
            )[0];
            latestOutputId.value = t.id;

            if (t.status === "PROCESSING") {
              message.value[message.value.length - 1].status = "IN_PROCESS";
              message.value[message.value.length - 1].id = t.id;
              message.value[message.value.length - 1].feedback = JSON.parse(
                t.feedback
              );
              const lastMsgObj = message.value[message.value.length - 1].message;
              const fullContent = t.content;
              const displayed = lastMsgObj;
              if (fullContent.length > displayed.length) {
                const newText = fullContent.slice(displayed.length);
                startTypewriterEffect(newText);
              }
            } else if (t.status === "FINISHED" && isTyping.value) {
              // No action needed when typing is in progress and status is FINISHED
              message.value[message.value.length - 1].status = "FINISHED";
            } else if (t.status === "FINISHED" && !isTyping.value) {
              message.value[message.value.length - 1].id = t.id;
              message.value[message.value.length - 1].feedback = JSON.parse(
                t.feedback
              );
              const lastMsgObj = message.value[message.value.length - 1].message;
              const fullContent = t.content;
              const displayed = lastMsgObj;
              if (fullContent.length > displayed.length) {
                const newText = fullContent.slice(displayed.length);
                startTypewriterEffect(newText);
              }
              message.value[message.value.length - 1].status = "FINISHED";
              reset(gtimer);

            } else if (t.status === "FAILED") {
              proxy.$modal.msgSuccess(
                `生成に失敗しました。失敗の理由: ${t.content}`
              );
              message.value[message.value.length - 1].status = "FAILED";
              reset(gtimer);
            } else if (t.status === "CANCEL" && isTyping.value) {
              message.value[message.value.length - 1].id = t.id;
              message.value[message.value.length - 1].feedback = JSON.parse(
                t.feedback
              );
              message.value[message.value.length - 1].status = "CANCEL";
              message.value[message.value.length - 1].message = t.content ? t.content : "CANCEL";
              reset(gtimer);
            } else if (t.status === "CANCEL" && !isTyping.value) {
              // message.value[message.value.length - 1].message = "CANCEL";
              message.value[message.value.length - 1].id = t.id;
              message.value[message.value.length - 1].feedback = JSON.parse(
                t.feedback
              );
              message.value[message.value.length - 1].status = "CANCEL";
              message.value[message.value.length - 1].message = t.content ? t.content : "CANCEL";
              reset(gtimer);
            } else {
              message.value[message.value.length - 1].status = "IN_PROCESS";
            }
          });
        }, 1000); 
        
    }, 5000); 
  });
}


function startTypewriterEffect(newText) {
  if (isTyping.value === true || !newText) return;
  isTyping.value = true;
  let idx = 0;
  function typeNextChar() {
    if (
      message.value.length > 0 &&
      (message.value[message.value.length - 1].status === "CANCEL")
    ) {
      message.value[message.value.length - 1].message = "CANCEL";
      isTyping.value = false;
      return;
    }
    let speed;
    if (idx < newText.length) {
      speed = Math.max(10, 2500 / (newText.length))
      message.value[message.value.length - 1].message += newText.charAt(idx);
      idx++;
      if (message.value[message.value.length - 1].status === "FINISHED" || message.value[message.value.length - 1].status === "CANCEL") {
        speed = 5
      }
      setTimeout(typeNextChar, speed);
    } else {
      isTyping.value = false;
    }
  }
  typeNextChar();
}

const stop = async () => {
  await stopTaskOutput(chatId.value, Math.max(fieldSort.value))
  contentGenLoading.value = false
}

function scrollToBottom() {
  let elscroll = proxy.$refs["scrollDiv"];
  elscroll.scrollTop = elscroll.scrollHeight + 30;
}

function updateStatus(feedback, id, index) {
  const taskOutputId = id ? id : latestOutputId.value;
  
  if (message.value[index].feedback?.emoji === feedback) {
    feedback = JSON.stringify({
      emoji: null,
      comment: message.value[index].feedback?.comment,
    });
  } else {
    feedback = JSON.stringify({
      emoji: feedback,
      comment: message.value[index].feedback?.comment,
    });
  }
  updateTaskOutput({
    taskOutputId: taskOutputId,
    data: {
      feedback: feedback,
    },
  }).then((response) => {
    message.value[index].feedback = JSON.parse(feedback);
    // Send feedback signal to FAQ cache service
    const parsedFeedback = JSON.parse(feedback);
    if (parsedFeedback.emoji) {
      // Extract Q&A pair
      let userQuery = '';
      let assistantAnswer = '';
      
      if (index > 0 && message.value[index - 1].role === 'user') {
        userQuery = message.value[index - 1].message;
      }
      if (message.value[index] && message.value[index].role === 'assistant') {
        assistantAnswer = message.value[index].message;
      }
      
      if (userQuery && assistantAnswer) {
        // Map emoji to cache_signal: GOOD -> 1, NOT_GOOD -> 0
        const cache_signal = parsedFeedback.emoji === 'GOOD' ? 1 : 0;
        
        const feedbackData = {
          taskOutputId: taskOutputId,
          cache_signal: cache_signal,
          query: userQuery,
          answer: assistantAnswer
        };
        
        console.log('📤 Sending feedback to cache service:', feedbackData);
        
        sendFeedbackToCache(feedbackData)
          .then(result => {
            console.log('✅ Cache feedback sent successfully:', result);
            if (result.success) {
              ElMessage.success(`Cache updated: ${result.message}`);
            }
          })
          .catch(error => {
            console.error('❌ Error sending cache feedback:', error);
            // Don't show error to user, as main feedback was saved successfully
          });
      } else {
        console.warn('Cannot extract Q&A pair for cache feedback');
      }
    }
  });
}

function updateComment(comment, id, index) {
  if (message.value[index].feedback?.comment === comment) {
    comment = JSON.stringify({
      emoji: message.value[index].feedback?.emoji,
      comment: message.value[index].feedback?.comment,
    });
  } else {
    comment = JSON.stringify({
      emoji: message.value[index].feedback?.emoji,
      comment: comment,
    });
  }
  updateTaskOutput({
    taskOutputId: id ? id : latestOutputId.value,
    data: {
      feedback: comment,
    },
  }).then((response) => {
    message.value[index].feedback = JSON.parse(comment);
    feedbackCheck.value = true;
    commentDialog.value = false;
  });
}

async function newchat() {
  // 檢查是否正在生成內容
  if (isGeneratingContent.value) {
    ElMessage.warning("生成中のコンテンツがあります。完了するまで待ってください。");
    return;
  }
  
  if (contentGenLoading.value === true) {
    ElMessage.warning("生成中のコンテンツがあります。完了するまで待ってください。");
  } else {
    newChatButtonDisabled.value = true;
    if(emptyChatTaskId.value) {
      message.value = [];
      fieldSort.value = 0;
      chatId.value = emptyChatTaskId.value;
      const idx = chatHistoryList.value.findIndex(c => c.id === emptyChatTaskId.value);
      if (idx >= 0) activeChatIndex.value = idx;
      getTaskOutputList(chatId.value, 1);
    } else {
      message.value = [];
      chatId.value = "";
      fieldSort.value = 0;
      init.value = true;
      chatCounter.value += 1;
      gen();
      await new Promise((resolve) => setTimeout(resolve, 100));
      await nextTick();
      getTaskList();
      if (chatHistoryList.value.length > 0) {
        // 新しいチャットにフォーカスを移す
        activeChatIndex.value = 0;
      }
    }
    setTimeout(() => {
      newChatButtonDisabled.value = false;
    }, 1000);
  }
  setTimeout(() => {
    newChatButtonDisabled.value = false;
  }, 300);
}

function insertNewLine(e) {
  e.preventDefault();
  userInput.value += "\n";
}

function navigateToHome() {
  if (contentGenLoading.value === true) {
    ElMessage.warning("生成中のコンテンツがあります。完了するまで待ってください。");
  } else {
    router.push('./home');
  }
}

// ファイルを選択
const selectFile = (file) => {
  // 今は何もしない
};


// マウス移動モニター - マウスが左側に近づいたか検出
const handleMouseMove = (e) => {
  // マウスが左側から50px未満の距離にあり、サイドバーが折りたたまれている場合、サイドバーを展開する
  if (e.clientX < 50 && leftSidebarCollapsed.value) {
    leftSidebarCollapsed.value = false;
    // 存在する可能性のある離脱タイマーをクリアする
    if (sidebarLeaveTimer) {
      clearTimeout(sidebarLeaveTimer);
      sidebarLeaveTimer = null;
    }
  }
};

// 初期化
onMounted(() => {
  // FontAwesomeアイコンを追加
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css';
  document.head.appendChild(link);

  // 添加全局滑鼠移動監聽器
  window.addEventListener('mousemove', handleMouseMove);

  // チャットリストの取得 & チャットの内容の取得表示
  getTaskList();
  createTagTable();
});

// 組件卸載時移除監聽器
onUnmounted(() => {
  window.removeEventListener('mousemove', handleMouseMove);
});

// ファイルリストを取得する
function getFileList() {
  fileLoading.value = true;
  listFile({ pageNum: 1, pageSize: 1000 }).then((response) => {
    fileList.value = response.result.rows;
    fileLoading.value = false;
  });
}

// async function getTagList() {
//   tagLoading.value = true;
//   listTag().then((response) => {
//     tagOptions.value = response.result.rows;
//     tagLoading.value = false;
//   });
// }

async function createTagTable() {
  let dispCounter = 0;
  try {
    const tagResponse = await listTag();
    tagOptions.value = tagResponse.result.rows;
    tagLoading.value = false;

    taggedfileTable.value = [
      ...tagOptions.value.map(tag => ({
        displayId: ++dispCounter,
        id: tag.id,
        name: tag.name,
        isTag: true,
        children: [],
      })),
      {
        displayId: ++dispCounter,
        id: 0,
        name: 'タグ無し',
        isTag: true,
        children: [],
      }
    ];

    const fileResponse = await listFile({ pageNum: 1, pageSize: 1000 });
    fileList.value = fileResponse.result.rows;
    fileLoading.value = false;

    fileList.value.forEach(file => {
      // file.tagId が未定義なら「タグ無し」の id=0 行へ
      const targetId = file.tag ?? 0;
      const row = taggedfileTable.value.find(r => r.id === targetId);
      if (row) {
        row.children.push({
          displayId: ++dispCounter,
          id: file.id,
          isTag: false,
          name: file.filename,
        });
      }
    });
  } catch (error) {
    console.error("Error creating tag table:", error);
  }
}

function handleUpload() {
  open.value = true;
  title.value = "ファイルアップロード";
  proxy.$modal.msgSuccess("ファイルアップロード機能は実装中です");
  // ここで file.vue のアップロード機能を呼び出すことができます
}

// アップロードダイアログを開く
function openUploadDialog() {
  uploadDialogVisible.value = true;
  uploadForm.value = {
    file: null,
    fileList: [],
    tags: []
  };
}

// アップロードをキャンセル
function cancelUpload() {
  uploadDialogVisible.value = false;
  uploadForm.value = {
    file: null,
    fileList: [],
    tags: []
  };
}

// ファイル変更処理
function handleFileChange(file) {
  uploadForm.value.file = file.raw;
  uploadForm.value.fileList = [file];
}

// ファイル処理の削除
function handleFileRemove() {
  uploadForm.value.file = null;
  uploadForm.value.fileList = [];
}

// アップロードフォームを送信
function submitUploadForm() {
  uploadFormRef.value.validate((valid) => {
    if (valid && uploadForm.value.file) {
      const formData = new FormData();
      formData.append("file", uploadForm.value.file);

      // タグ情報を追加する
      if (uploadForm.value.tags && uploadForm.value.tags.length) {
        formData.append("tags", JSON.stringify(uploadForm.value.tags));
      }

      uploadFile(formData).then(() => {
        proxy.$modal.msgSuccess("ファイルのアップロードに成功しました");
        uploadDialogVisible.value = false;
        getFileList();
      });
    }
  });
}

// すべてのファイルを選択
function handleSelectAllFiles(val) {
  val ? selectedFiles.value = fileList.value.map(file => file.id) : selectedFiles.value = [];
}

// ファイル選択の変更
function handleFileSelectionChange(selection) {
  const fileRows = selection.filter(item => item.isTag === false)
  const currentFileIds = fileRows.map(item => item.id)
  const newSelection = fileRows.filter(item => !selectedFiles.value.includes(item.id));
  const deselectedFiles = selectedFiles.value.filter(id => !currentFileIds.includes(id))
    .map(id => fileList.value.find(file => file.id === id));
  if (newSelection.length > 0) {
    // チェックがONになった場合の処理
    newSelection.forEach(file => {
      if (!fileId.value.includes(file.id)) {
        fileId.value.push(file.id);
      }
    });
  } else {
    // チェックがOFFになった場合の処理
    deselectedFiles.forEach(file => {
      fileId.value = fileId.value.filter(id => id !== file.id);
    });
  }
  selectedFiles.value = currentFileIds;
  selectAllFiles.value = selectedFiles.value.length === fileList.value.length;
}


// ファイルのプレビュー
function previewFile(file) {
  window.open(`/api/file/preview/${file.id}`, '_blank');
}

// ファイルを削除する
// function deleteFile(file) {
//   proxy.$modal.confirm(`「${file.filename}」を削除しますか？`).then(() => {
//     deleteFile(file.id).then(() => {
//       proxy.$modal.msgSuccess("削除成功");
//       getFileList();
//     });
//   });
// }

// ファイルページに移動
function navigateToFilePage() {
  if (contentGenLoading.value === true) {
    ElMessage.warning("生成中のコンテンツがあります。完了するまで待ってください。");
  } else {
    router.push('/file');
  }
}

// 判斷是否應該顯示 feedback 按鈕
function shouldShowFeedback(item, index) {
  // 只對 assistant 消息顯示 feedback
  if (item.role !== 'assistant') {
    return false;
  }
  
  // 如果正在生成內容且消息為空，不顯示 feedback
  if (contentGenLoading.value && item.message === '') {
    return false;
  }
  
  // 如果已經有 feedback emoji，不顯示 feedback 按鈕
  if (item.feedback?.emoji) {
    return false;
  }
  
  // 檢查狀態：只有 FINISHED 狀態才顯示 feedback
  // 排除處理中、失敗、取消等狀態
  const validStatuses = ['FINISHED'];
  if (item.status && !validStatuses.includes(item.status)) {
    return false;
  }
  
  // 確保有實際的內容輸出
  if (!item.message || item.message.trim() === '') {
    return false;
  }
  
  // 確保不isLastMessage是最後一個正在處理的消息
  const isLastMessage = index === message.value.length - 1;
  if (isLastMessage && contentGenLoading.value) {
    return false;
  }

  // タイプライターエフェクトが実行中の場合、フィードバックボタンを表示しない
  // すべてのコンテンツが表示完了するまで待機してからフィードバックを表示する
  if (isTyping.value && isLastMessage) {
    return false;
  }

  return true
}
</script>

<style lang="scss" scoped>
@import '@/assets/styles/btn.scss';

::v-deep(.el-switch.is-checked .el-switch__core) {
  background-color: $dark-blue-bg !important;
  border-color: $dark-blue-bg !important;
}

::v-deep(div.default-theme p) {
  margin: 0;
}

// ページコンテナ
.chat-page-container {
  display: flex;
  height: 100vh;
  background: $light-bg-alt; // 淺米色背景
  color: $text-dark;
  position: relative;
  overflow: hidden;
}

// 左側の履歴サイドバー
.sidebar-left {
  width: 18vw;
  height: calc(100% - 70px);
  margin-top: 70px;
  background-color: rgba(249, 249, 249, 0.9); // 淡灰米色背景
  backdrop-filter: blur(5px);
  border-right: 1px solid rgba(0, 0, 0, 0.05);
  transition: $transition;
  position: fixed; // 懸浮效果
  left: 0;
  top: 0;
  z-index: 100;
  box-shadow: $shadow;
  border-radius: 0 $border-radius-lg $border-radius-lg 0;

  &.collapsed {
    width: 20px;
    
    // 折りたたんだ状態でもマウスイベントが発生するようにする
    &:hover {
      width: 18vw;
      z-index: 101;
    }
  }

  .sidebar-content {
    display: flex;
    flex-direction: column;
    height: 100%;
    padding: 20px;
    overflow: hidden;
  }



  .new-chat-button {
    margin-bottom: 20px;

    .el-button {
      height: 50px;
      width: 100%;
      font-size: 1.2rem;
      border-radius: 12px;
      background-color: $primary-light !important;
      border-color: $primary-light !important;
      color: white !important;

      &:hover {
        background-color: lighten($primary-light, 8%) !important;
        border-color: lighten($primary-light, 8%) !important;
      }

      &:disabled {
        background-color: rgba($primary-light, 0.5) !important;
        border-color: rgba($primary-light, 0.5) !important;
        color: rgba(255, 255, 255, 0.7) !important;
      }
    }
  }

  .history-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;

    h3 {
      margin: 0;
      font-size: 0.9rem;
      font-weight: 600;
      color: $text-dark;
    }
  }

  .history-list {
    flex: 1;
    overflow-y: auto;
    font-size: 0.9rem;

    .history-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 15px;
      border-radius: $border-radius;
      margin-bottom: 8px;
      cursor: pointer;
      transition: $transition;
      background-color: rgba(255, 255, 255, 0.5);

      &.active {
        background-color: rgba($primary-light, 0.85);
        color: white;
      }

      &:hover {
        background-color: rgba($dark-blue-bg, 0.8);
        color: #ffffff;

        &.active {
          background-color: rgba($primary-light, 0.9);
        }

        .history-item-actions {
          opacity: 1;
        }
      }

      .history-item-content {
        flex: 1;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .history-item-actions {
        display: flex;
        opacity: 0;
        transition: $transition;

        .history-action-btn {
          font-size: 14px;
          padding: 2px;

          &:hover {
            background-color: #ffffff;
            color: $blue;
          }
        }
      }
    }
  }
}

// 右側のファイル選択サイドバー
.sidebar-right {
  width: 18vw;
  height: 100%;
  background-color: rgba(249, 249, 249, 0.9); // 淡灰米色背景
  backdrop-filter: blur(5px);
  border-left: 1px solid rgba(0, 0, 0, 0.05);
  transition: $transition;
  position: fixed;
  right: 0;
  top: 0;
  z-index: 100;
  box-shadow: $shadow;
  border-radius: $border-radius-lg 0 0 $border-radius-lg;

  &.collapsed {
    width: 10px;
    border-left: none;
    box-shadow: none;

    &:hover {
      transform: translateX(-15px);
    }
  }

  .sidebar-toggle {
    position: absolute;
    top: 50%;
    left: -15px;
    width: 30px;
    height: 50px;
    background-color: $primary-light;
    border-radius: 8px;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    z-index: 11;
    box-shadow: $shadow;
    transition: $transition;
    color: $text-dark;

    &:hover {
      background-color: lighten($primary-light, 8%);
    }

    i {
      color: white;
      font-size: 12px;
    }
  }

  .sidebar-content {
    height: 100%;
    padding: 20px;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }

  .file-section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;

    h3 {
      margin: 0;
      font-size: 16px;
      font-weight: 600;
      color: $text-dark;
    }
  }

  .toFile {
    background-color: #fff;
    color: $primary-color;

    &:hover {
      color: $primary-light;
      background-color: rgba($primary-light, 0.1);
    }
  }

  .upload-section {
    margin-bottom: 20px;
    display: flex;
    gap: 10px;

    .el-button {
      flex: 1;
    }
  }

  .file-list-section {
    flex: 1;
    overflow-y: auto;

    .file-name-cell {
      cursor: pointer;
      color: $primary-color;

      &:hover {
        text-decoration: underline;
      }

      pointer-events: none;
    }

    .file-actions {
      display: flex;
      justify-content: center;
      gap: 5px;
    }
  }
}

// メインチャットエリア
.chat-main-area {
  flex: 1;
  display: flex;
  flex-direction: column;
  padding:16px;
  padding-bottom: 16vh;
  overflow: hidden;
  margin-left: 19vw;
  width: 100%;
  position: relative;
  // max-width: 62vw;
  // min-width: 500px;
}


.chat-page-container:has(.sidebar-left.collapsed + .chat-main-area) .chat-main-area {
  // max-width: 80vw;
  margin-left: 6.5vw;
}

.chat-page-container:has(.chat-main-area + .sidebar-right.collapsed) .chat-main-area {
  max-width: 80vw;
  margin-left: 19vw;
}

.chat-page-container:has(.sidebar-left.collapsed + .chat-main-area + .sidebar-right.collapsed) .chat-main-area {
  max-width: 98vw;
  margin-left: 1vw;
}

.chat-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;

  .chat-title {
    h2 {
      margin: 0;
      font-size: 1.8rem;
      font-weight: 600;
      color: $text-dark;
    }
  }
}

// チャット内容エリア
::v-deep(.el-textarea__inner:focus) {
  box-shadow: none;
}

.answer-container {
  flex: 1;
  border-radius: $border-radius-lg;
  background-color: rgba(255, 255, 255, 0.5);
  backdrop-filter: blur(5px);
  overflow: hidden;
  box-shadow: $shadow;
  transition: all 0.3s ease;
  
  .chat-main-area.input-focused & {
    flex: 0.9;
  }
}

.scroll-container {
  height: 100%;
  overflow-y: auto;
  padding: 20px;
  scrollbar-width: none;
  
  // コンテナの幅が1200pxを超える場合、左右のパディングを増やしコンテンツをより集中させる
  @media (min-width: 1200px) {
    padding-left: max(20px, calc((100% - 1200px) / 2 + 20px));
    padding-right: max(20px, calc((100% - 1200px) / 2 + 20px));
  }
  
  // コンテナの幅が1600pxを超える場合、さらにパディングを増やす
  @media (min-width: 1600px) {
    padding-left: max(20px, calc((100% - 1400px) / 2 + 20px));
    padding-right: max(20px, calc((100% - 1400px) / 2 + 20px));
  }
}

.message-list {
  padding: 0;
  margin: 0;
  list-style: none;
  
  // ページ幅が1200pxを超える場合、メッセージリストの最大幅を制限し中央揃えにする
  @media (min-width: 1200px) {
    max-width: 1200px;
    margin: 0 auto;
  }
  
  // ページ幅が1600pxを超える場合、さらに幅を制限する
  @media (min-width: 1600px) {
    max-width: 1400px;
  }
}

// ユーザーメッセージ
.user-message {
  display: flex;
  justify-content: end;
  margin: 16px 0px 16px 15%;
  width: 85%;
  flex-direction: row-reverse;
  text-align: end;

  .user-preview :deep(p) {
    display: block;
    padding: 0;
    border-radius: 0;
    word-break: break-word;
    overflow-wrap: break-word;
    word-wrap: break-word;
    text-align: left;
  }

}
::v-deep(.md-editor-preview-wrapper) {
  padding: 0;
}

.user-content {
  max-width: 80%;
  margin-right: 16px;
  position: relative;
  padding:  0.8rem;
  box-shadow: $shadow-sm;
  color: $text-dark;
  border-radius: 12px;
}

// アシスタントメッセージ
.assistant-message {
  display: flex;
  margin: 0 0 24px 0;
  align-items: flex-start;
}

::v-deep(.md-editor-preview) {
  word-break: break-word;
  overflow-wrap: break-word;
  word-wrap: break-word;
}

.avatar-container {
  margin-right: 16px;

  .el-avatar {
    border-radius: $border-radius !important;
    background: none !important;
  }
}

.message-content {
  max-width: 80%;
  display: flex;
  justify-content: center;
  flex-direction: column;
}

.assistant-content {
  padding: 12px 16px;
  position: relative;
  // background-color: $baby-blue-bg;
  border-radius: $border-radius;
  color: $text-light;

  ::v-deep(.md-editor-previewOnly) {
    background: none !important;
  }
}

.dialog-footer {
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  gap: 10px;

  // Primary ボタン（保存、確定など）- ホバー効果の強化
  .el-button--primary {
    background-color: $primary-light !important;
    border-color: $primary-light !important;
    color: white !important;
    transition: all 0.3s ease;

    &:hover {
      background-color: lighten($primary-light, 12%) !important;
      border-color: lighten($primary-light, 12%) !important;
      color: white !important;
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba($primary-light, 0.4);
    }

    &:active {
      transform: translateY(0);
      box-shadow: 0 2px 6px rgba($primary-light, 0.3);
    }
  }

  // 危険ボタン（削除）- ホバー効果の強化
  .el-button--danger {
    background-color: $danger !important;
    border-color: $danger !important;
    color: white !important;
    transition: all 0.3s ease;

    &:hover {
      background-color: lighten($danger, 8%) !important;
      border-color: lighten($danger, 8%) !important;
      color: white !important;
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba($danger, 0.4);
    }

    &:active {
      transform: translateY(0);
      box-shadow: 0 2px 6px rgba($danger, 0.3);
    }
  }

  // デフォルトボタン（キャンセル）- ホバー効果の強化
  .el-button:not(.el-button--primary):not(.el-button--danger) {
    transition: all 0.3s ease;

    &:hover {
      background-color: rgba(0, 0, 0, 0.05);
      border-color: rgba(0, 0, 0, 0.2);
      color: $text-dark;
      transform: translateY(-1px);
    }

    &:active {
      transform: translateY(0);
    }
  }
}

// フィードバックアイコン
.feedback-icons {
  display: flex;
  flex-direction: row;
  gap: 12px;
  margin-left: 12px;
  padding: 8px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 12px;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  opacity: 0;
  animation: feedbackEx 0.55s ease-out 3s 1 forwards;

  .feedback-btn {
    cursor: pointer;
    font-size: 28px;
    transition: all 0.3s ease;
    padding: 8px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 44px;
    min-height: 44px;

    &:hover {
      transform: scale(1.15);
      background: rgba(255, 255, 255, 0.2);
    }

    &.good-btn {
      color: #eaeaea;
      
      &:hover {
        color: #22c55e;
        // box-shadow: 0 0 20px rgba(74, 222, 128, 0.3);
      }
    }

    &.not-good-btn {
      color: #eaeaea;
      
      &:hover {
        color: #ef4444;
        // box-shadow: 0 0 20px rgba(248, 113, 113, 0.3);
      }
    }
  }
}

// タイプライター効果
.typewriter {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;

  p {
    width: 400px;
    font-size: 1.8rem;
    color: $primary-color;
    text-align: center;
    border-right: 0.15em solid $primary-light;
    white-space: nowrap;
    margin: 20vh auto;
    overflow: hidden;
    letter-spacing: 0.05em;
    animation: typing 1.5s steps(15, end), blink-caret 0.75s step-end infinite;
  }
}

@keyframes typing {
  from {
    width: 0
  }

  to {
    width: 400px
  }
}

@keyframes blink-caret {

  from,
  to {
    border-color: transparent
  }

  50% {
    border-color: $primary-light
  }
}

@keyframes feedbackEx {
  from {
    top: -20px;
    opacity: 0;
  }

  to {
    top: 0;
    opacity: 1;
  }
}

// 入力エリア
.input-area {
  position: absolute;
  width: 100%;
  padding-left: 28px;
  right: 16px;
  bottom: 20px;
  z-index: 20;
}

.input-container {
  padding: 16px;
  border-radius: $border-radius-lg;
  background-color: rgba($light-bg-alt, 0.85);
  box-shadow: $shadow;
  transition: all 0.3s ease;

  &.compact {
    padding: 8px 16px;

    .input-wrapper {
      max-height: 50px;
      overflow: hidden;
    }
  }
}

.input-wrapper {
  position: relative;
  border-radius: $border-radius;
  background-color: rgba(255, 255, 255, 0.5);
  overflow: hidden;
}

.chat-input {
  width: 100%;
}

.chat-input :deep(.el-textarea__inner) {
  background-color: transparent;
  border: none;
  color: $text-dark;
  background-color: rgba(255, 255, 255, 1);
  padding: 16px;
  padding-bottom: 60px;
  font-size: 1rem;
  box-shadow: none;
  resize: none;

  &::placeholder {
    color: rgba(0, 0, 0, 0.4);
  }

  &:focus {
    outline: none;
  }
}

.input-controls {
  position: absolute;
  bottom: 0;
  // left: 0;
  right: 0px;
  padding: 10px 16px;
  display: flex;
  justify-content: end;
  align-items: center;
  //border-top: 1px solid rgba(0, 0, 0, 0.05);
  // background-color: rgba(255, 255, 255, 0.8);
  width: 50px;

  :deep(.el-tooltip) {
    position: absolute;
    bottom: 8x;
    right: 8px;
  }
}

.file-search-toggle {
  display: flex;
  align-items: center;
}

.send-button {
  background-color: $primary-light;
  border-color: $primary-light;

  &:hover {
    background-color: lighten($primary-light, 10%);
    border-color: lighten($primary-light, 10%);
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
  }
}

.input-notice {
  display: block;
  margin-top: 8px;
  font-size: 0.8rem;
  color: rgba(0, 0, 0, 0.4);
}

// アニメーションを読み込み中
.loader {
  width: 60px;
  aspect-ratio: 4;
  --_g: no-repeat radial-gradient(circle closest-side, #ffffff 90%, transparent);
  background:
    var(--_g) 0% 50%,
    var(--_g) 50% 50%,
    var(--_g) 100% 50%;
  background-size: calc(100%/3) 100%;
  animation: l7 1s infinite linear;
  margin: 16px auto;
}

@keyframes l7 {
  33% {
    background-size: calc(100%/3) 0%, calc(100%/3) 100%, calc(100%/3) 100%
  }

  50% {
    background-size: calc(100%/3) 100%, calc(100%/3) 0%, calc(100%/3) 100%
  }

  66% {
    background-size: calc(100%/3) 100%, calc(100%/3) 100%, calc(100%/3) 0%
  }
}

// ダイアログボックスのスタイル
.dialog {

  :deep(.el-dialog__header),
  :deep(.el-dialog__body),
  :deep(.el-dialog__footer) {
    background-color: transparent;
    color: $text-light;
  }

  :deep(.el-dialog__title) {
    color: $text-light;
  }

  :deep(.el-dialog__headerbtn .el-dialog__close) {
    color: $text-light;
  }
}

// ダイアログボックスのスタイル
.glass-panel {
  background-color: $dark-glass;
  backdrop-filter: blur(5px);
  border-radius: $border-radius;
  border: 1px solid rgba(255, 255, 255, 0.1);
  box-shadow: $shadow;
}

.glass-panel-light {
  background-color: $dark-glass-light;
  backdrop-filter: blur(5px);
  border-radius: $border-radius;
  border: 1px solid rgba(255, 255, 255, 0.1);
  box-shadow: $shadow;
}

// レスポンシブデザイン
@media (max-width: 992px) {
  .chat-main-area {
    min-width: 300px;
    padding: 15px;
    padding-bottom: 15vh;
  }
}

@media (max-width: 768px) {

  .sidebar-left:not(.collapsed),
  .sidebar-right:not(.collapsed) {
    width: 100%;
    max-width: 280px;
  }

  .chat-main-area {
    padding: 15px 20px;
  }

  .sidebar-left.collapsed+.chat-main-area {
    padding-left: 40px;
  }

  .sidebar-right.collapsed~.chat-main-area {
    padding-right: 20px;
  }

  // レスポンシブデザインのモバイル版ではサイドバーは片側のみ開くことが許可されています
  .sidebar-left:not(.collapsed)~.sidebar-right:not(.collapsed) {
    display: none;
  }

  .user-content,
  .assistant-content {
    max-width: 90%;
  }

  .typewriter {
    display: none;
  }

  .avatar-container {
    display: none;
  }

  .message-content {
    max-width: 100%;
  }

  .user-message {
    justify-content: end;
    padding: 0px 0% 0 0;
  }

  .input-area {
    width: 96%;
  }

  .answer-container{
    margin-bottom: 12vh;
  }

}

.section {
  margin-bottom: 20px;
  background-color: white;
  border-radius: $border-radius;
  padding: 15px;
  box-shadow: $shadow;
}

  // メインアクションボタンはメインカラーを使用する.el-button--primary {  background-color: $primary-color;  border-color: $primary-color;    &:hover, &:focus {    background-color: $primary-light;    border-color: $primary-light;  }}

.home-button-fixed {
  position: fixed;
  top: 20px;
  left: 20px;
  z-index: 1000;

  .el-button {
    background-color: $primary-light !important;
    border-color: $primary-light !important;
    color: white !important;

    &:hover {
      background-color: lighten($primary-light, 8%) !important;
      border-color: lighten($primary-light, 8%) !important;
    }
  }
}

.generating-indicator {
  display: flex;
  gap: 4px;
  margin-top: 10px;
  align-items: center;

  .dot {
    width: 8px;
    height: 8px;
    background-color: $primary-color;
    border-radius: 50%;
    animation: blink 1.2s infinite ease-in-out;
  }

  .dot:nth-child(2) {
    animation-delay: 0.2s;
  }

  .dot:nth-child(3) {
    animation-delay: 0.4s;
  }
}

@keyframes blink {

  0%,
  80%,
  100% {
    opacity: 0;
    transform: scale(0.8);
  }

  40% {
    opacity: 1;
    transform: scale(1);
  }
}

.answering-label {
  margin-top: 4px;
  font-size: 12px;
  color: #999;
  text-align: center;
  animation: blink-label 1.5s infinite;
}

@keyframes blink-label {

  0%,
  100% {
    opacity: 0.3;
  }

  50% {
    opacity: 1;
  }
}
</style>
