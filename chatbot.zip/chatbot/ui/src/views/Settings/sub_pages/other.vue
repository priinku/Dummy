<template>
    <div class="other-setting">
        <div class="content-container">
            <div class="right-panel">
                <h1>その他</h1>
            </div>
        </div>
    </div>
</template>

<script setup>
// 必要なインポートがあれば追加
</script>

<style lang="scss" scoped>
@import '@/assets/styles/variables.module.scss';

.other-setting {
    padding: 0;  
    background: linear-gradient(135deg, $light-bg-alt 0%, #f8f9ff 100%);  
    height: 100%;
    width: 100%;
}

.content-container {
  padding: 0;
}

.right-panel {
  padding: 20px;
}
</style>