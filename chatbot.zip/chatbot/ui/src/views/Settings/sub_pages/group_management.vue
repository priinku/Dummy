<template>
  <div class="group-management-container">
    <div class="content-container">
      <!-- 左パネル: グループツリー -->
      <div class="left-panel">
        <div class="tree-section">
          <div class="tree-header">
            <h3>グループ構造</h3>
            <el-button type="primary" icon="Plus" size="small" @click="createRootGroup" :loading="loading">
              新規グループ作成
            </el-button>
          </div>
          <div class="group-tree-container">
            <div v-if="groupTreeData.length === 0" class="no-groups-container">
              <div class="no-groups-message">
                <p>グループが登録されていません</p>
              </div>
            </div>
            <el-tree v-else ref="groupTreeRef" :data="groupTreeData" :props="groupTreeProps" node-key="id"
              :default-expand-all="true" @node-click="handleNodeClick" :highlight-current="true" :indent="20"
              :expand-on-click-node="false" :check-on-click-node="false" />
          </div>
        </div>
      </div>

      <!-- 右パネル: グループ詳細 -->
      <div class="right-panel">
        <div class="section details-section">
          <div class="details-header">
            <h3>{{ selectedGroup ? selectedGroup.label : 'グループを選択してください' }}</h3>
          </div>

          <div v-if="selectedGroup" class="group-details">
            <div class="detail-item">
              <label>グループ名:</label>
              <div class="editable-field">
                <el-input v-model="selectedGroup.label" placeholder="グループ名を入力" :disabled="!isEditingName" />
                <el-button v-if="!isEditingName" type="primary" icon="Edit" size="small" @click="enableNameEdit">
                  編集
                </el-button>
                <div v-else class="edit-actions">
                  <el-button type="success" icon="Check" size="small" @click="saveNameEdit">保存</el-button>
                  <el-button type="info" icon="Close" size="small" @click="cancelNameEdit">キャンセル</el-button>
                </div>
              </div>
            </div>

            <div class="detail-item">
              <label>属性:</label>
              <el-input v-model="selectedGroup.attributes" type="textarea" :rows="3" placeholder="属性を入力" />
            </div>

            <div class="detail-item">
              <label>グループカラー:</label>
              <div class="color-selection-container">
                <div class="color-usage-selection">
                  <el-radio-group v-model="selectedGroup.useGroupColor" @change="handleColorUsageChange">
                    <el-radio :label="1">使用する</el-radio>
                    <el-radio :label="0">使用しない</el-radio>
                  </el-radio-group>
                </div>

                <div v-if="selectedGroup.useGroupColor" class="color-controls">
                  <div class="color-preview-sample" :style="{ backgroundColor: selectedGroup.colorCode || '#f5f7fa' }"
                    :class="{ 'no-color': !selectedGroup.colorCode }">
                  </div>
                  <div class="color-actions">
                    <el-button type="primary" icon="Edit" size="small" @click="openColorPicker">
                      カラー変更
                    </el-button>
                    <el-button type="warning" icon="Refresh" size="small" @click="setRandomColor">
                      ランダム設定
                    </el-button>
                  </div>
                  <el-color-picker ref="colorPickerRef" v-model="selectedGroup.colorCode" :predefine="predefinedColors"
                    show-alpha @change="handleColorChange" style="display: none;" />
                </div>

                <div v-else class="color-disabled-message">
                  <span class="disabled-text">カラーは使用されません</span>
                </div>
              </div>
            </div>

            <!-- カラーピッカー（自動表示用） -->
            <el-color-picker ref="colorPickerRef" v-model="selectedGroup.colorCode" :predefine="predefinedColors"
              show-alpha @change="handleColorChange" size="large"
              style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 9999; visibility: hidden;" />

            <div class="detail-item">
              <label>システム属性:</label>
              <div class="system-attributes">
                <div class="attribute-row">
                  <span class="attribute-label">作成日時:</span>
                  <span class="attribute-value">{{ selectedGroup.createdAt || '未設定' }}</span>
                </div>
                <div class="attribute-row">
                  <span class="attribute-label">作成ユーザー:</span>
                  <span class="attribute-value">{{ selectedGroup.createByName || selectedGroup.create_by_name || '未設定'
                  }}</span>
                </div>
                <div class="attribute-row">
                  <span class="attribute-label">最終更新日時:</span>
                  <span class="attribute-value">{{ selectedGroup.updatedAt || '未設定' }}</span>
                </div>
                <div class="attribute-row">
                  <span class="attribute-label">最終更新ユーザー:</span>
                  <span class="attribute-value">{{ selectedGroup.updatedByName || selectedGroup.updated_by_name || '未設定'
                  }}</span>
                </div>
                <div class="attribute-row" v-if="selectedGroup.deletedAt">
                  <span class="attribute-label">削除日時:</span>
                  <span class="attribute-value">{{ selectedGroup.deletedAt }}</span>
                </div>
                <div class="attribute-row" v-if="selectedGroup.deletedBy">
                  <span class="attribute-label">削除ユーザー:</span>
                  <span class="attribute-value">{{ selectedGroup.deletedBy }}</span>
                </div>
              </div>
            </div>

            <div class="action-buttons">
              <el-button type="primary" icon="Plus" @click="addSubGroup">
                子グループを追加
              </el-button>
              <el-button type="success" icon="Check" @click="saveGroup">
                保存
              </el-button>
              <el-button type="danger" icon="Delete" @click="deleteGroupHandler" v-if="selectedGroup.groupId">
                削除
              </el-button>
            </div>
          </div>

          <div v-else class="no-selection">
            <p>左側のツリーからグループを選択してください</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, nextTick, onMounted } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import { getGroupList, createGroup, updateGroup, deleteGroup } from '@/api/group';

const groupTreeData = ref([]);

const predefinedColors = ref([
  '#ff4500',
  '#ff8c00',
  '#ffd700',
  '#90ee90',
  '#00ced1',
  '#1e90ff',
  '#c71585',
  '#409EFF',
  '#67C23A',
  '#E6A23C',
  '#F56C6C',
  '#909399'
]);

const groupTreeProps = reactive({
  children: 'children',
  label: 'label'
});

const selectedGroup = ref(null);
const originalGroupSnapshot = ref(null);
const groupTreeRef = ref(null);
const colorPickerRef = ref(null);
const isEditingName = ref(false);
const originalGroupName = ref('');
const loading = ref(false);

async function handleNodeClick(newData) {
  if (selectedGroup.value && hasUnsavedChanges()) {
    try {
      await ElMessageBox.confirm(
        '変更内容が保存されていません。保存しますか？',
        '確認',
        {
          confirmButtonText: '保存して移動',
          cancelButtonText: '破棄して移動',
          type: 'warning',
          distinguishCancelAndClose: true,
        }
      );
      await saveGroup(); // 保存後に切り替え
    } catch (action) {
      if (action === 'cancel') {
        // 「破棄して移動」を選んだ場合
        // 何もせずに次へ進む
      } else {
        // 「×」ボタンや「キャンセル」で処理中断
        return;
      }
    }
  }
  selectedGroup.value = { ...newData };
  originalGroupSnapshot.value = JSON.parse(JSON.stringify(newData));
  isEditingName.value = false;
  originalGroupName.value = newData.label;
}

function hasUnsavedChanges() {
  if (!selectedGroup.value || !originalGroupSnapshot.value) return false;

  const current = JSON.stringify({
    label: selectedGroup.value.label,
    attributes: selectedGroup.value.attributes,
    colorCode: selectedGroup.value.colorCode,
    useGroupColor: selectedGroup.value.useGroupColor
  });

  const original = JSON.stringify({
    label: originalGroupSnapshot.value.label,
    attributes: originalGroupSnapshot.value.attributes,
    colorCode: originalGroupSnapshot.value.colorCode,
    useGroupColor: originalGroupSnapshot.value.useGroupColor
  });
  return current !== original;
}

function handleColorChange(color) {
  if (selectedGroup.value) {
    if (color !== null) {
      selectedGroup.value.colorCode = color;
    }
  }
}

function enableNameEdit() {
  isEditingName.value = true;
  originalGroupName.value = selectedGroup.value.label;
}

async function saveNameEdit() {
  if (selectedGroup.value && selectedGroup.value.label.trim()) {
    try {
      await saveGroupToAPI();
      updateTreeNodeLabel(selectedGroup.value.id, selectedGroup.value.label);
      updateTimestamp();
      isEditingName.value = false;
    } catch (error) {
      ElMessage.error('グループ名の更新に失敗しました');
      console.error(error);
    }
  } else {
    ElMessage.error('グループ名を入力してください');
  }
}

function cancelNameEdit() {
  if (selectedGroup.value) {
    selectedGroup.value.label = originalGroupName.value;
  }
  isEditingName.value = false;
}

function openColorPicker() {
  if (colorPickerRef.value) {
    // 次のティックでカラーピッカーを自動表示
    nextTick(() => {
      colorPickerRef.value.show();
    });
  }
}

function setRandomColor() {
  if (selectedGroup.value) {
    const randomColor = predefinedColors.value[Math.floor(Math.random() * predefinedColors.value.length)];
    selectedGroup.value.colorCode = randomColor;
  }
}

function handleColorUsageChange(useColor) {
  if (selectedGroup.value) {
    selectedGroup.value.useColor = useColor;
    selectedGroup.value.useGroupColor = useColor ? 1 : 0;
  }
}

function updateTimestamp() {
  if (selectedGroup.value) {
    const now = new Date().toLocaleString('ja-JP', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    }).replace(/\//g, '-');
    selectedGroup.value.updatedAt = now;
    //selectedGroup.value.updatedBy = 'admin';
  }
}

function updateTreeNodeLabel(nodeId, newLabel) {
  const updateTree = (nodes) => {
    for (let node of nodes) {
      if (node.id === nodeId) {
        node.label = newLabel;
        return true;
      }
      if (node.children && updateTree(node.children)) {
        return true;
      }
    }
    return false;
  };
  updateTree(groupTreeData.value);
}

async function createRootGroup() {
  ElMessageBox.prompt('新しいグループ名を入力してください', '新規グループ作成', {
    confirmButtonText: '作成',
    cancelButtonText: 'キャンセル',
    inputPattern: /\S+/,
    inputErrorMessage: 'グループ名を入力してください'
  }).then(async ({ value }) => {
    try {
      loading.value = true;

      const groupData = {
        groupName: value,
        parentId: null,
        colorCode: '#409EFF',
        useGroupColor: false,
        attributes: ''
      };

      const response = await createGroup(groupData);
      if (response.code === 200) {
        await loadGroups();
        ElMessage.success('グループが作成されました');
      } else {
        ElMessage.error('グループの作成に失敗しました');
      }
    } catch (error) {
      console.error(error);
      ElMessage.error('グループの作成中にエラーが発生しました');
    } finally {
      loading.value = false;
    }
  }).catch(() => {
  });
}

async function addSubGroup() {
  if (!selectedGroup.value) return;

  ElMessageBox.prompt('新しい子グループ名を入力してください', '子グループ追加', {
    confirmButtonText: '追加',
    cancelButtonText: 'キャンセル',
    inputPattern: /\S+/,
    inputErrorMessage: 'グループ名を入力してください'
  }).then(async ({ value }) => {
    try {
      loading.value = true;

      const groupData = {
        groupName: value,
        parentId: selectedGroup.value.groupId || null,
        useGroupColor: false,
        attributes: ''
      };

      const response = await createGroup(groupData);
      if (response.code === 200) {
        await loadGroups();
        ElMessage.success('子グループが追加されました');
      } else {
        ElMessage.error('子グループの追加に失敗しました');
      }
    } catch (error) {
      console.error(error);
      ElMessage.error('子グループの追加中にエラーが発生しました');
    } finally {
      loading.value = false;
    }
  }).catch(() => {
  });
}

async function saveGroup() {
  if (!selectedGroup.value) return;

  try {
    loading.value = true;
    await saveGroupToAPI();
    await loadGroups();

    // 保存したグループの最新データをツリーから再取得して selectedGroup を更新
    const updated = findGroupInTree(groupTreeData.value, selectedGroup.value.groupId);
    if (updated) {
      selectedGroup.value = { ...updated };
      originalGroupSnapshot.value = JSON.parse(JSON.stringify(updated)); // 🔁 更新！
    }

    ElMessage.success('グループが保存されました');
  } catch (error) {
    console.error('Group save error:', error);
    ElMessage.error(`グループの保存に失敗しました: ${error.message || error}`);
  } finally {
    loading.value = false;
  }
}

async function deleteGroupHandler() {
  if (!selectedGroup.value || !selectedGroup.value.groupId) return;

  ElMessageBox.confirm(
    `グループ "${selectedGroup.value.label}" を削除しますか？`,
    '確認',
    {
      confirmButtonText: '削除',
      cancelButtonText: 'キャンセル',
      type: 'warning',
    }
  ).then(async () => {
    try {
      loading.value = true;

      const response = await deleteGroup(selectedGroup.value.groupId);
      if (response.code === 200) {
        await loadGroups();
        selectedGroup.value = null;
        ElMessage.success('グループが削除されました');
      } else {
        ElMessage.error('グループの削除に失敗しました');
      }
    } catch (error) {
      console.error(error);
      ElMessage.error('グループの削除中にエラーが発生しました');
    } finally {
      loading.value = false;
    }
  }).catch(() => {
  });
}

async function loadGroups() {
  try {
    loading.value = true;
    const response = await getGroupList();
    if (response.code === 200) {
      groupTreeData.value = response.result || [];
      await nextTick();
    } else {
      ElMessage.error('グループ一覧の取得に失敗しました');
    }
  } catch (error) {
    console.error(error);
    ElMessage.error('グループ一覧の取得中にエラーが発生しました');
  } finally {
    loading.value = false;
  }
}

// 注意: この関数は現在使用されていませんが、将来の互換性のために保持されています
// バックエンドから既に構造化されたデータが提供されるため、フロントエンドでの再処理は不要です
function buildGroupTree(groups) {
  const groupMap = new Map();
  const rootGroups = [];

  const flattenGroups = (groupList) => {
    const result = [];
    groupList.forEach(group => {
      const groupId = group.id ? parseInt(group.id.replace('group-', '')) : null;
      result.push({
        groupId: groupId,
        groupName: group.label,
        parentId: null,
        attributes: group.attributes || '',
        colorCode: group.colorCode || group.color_code || '#409EFF',
        useGroupColor: group.useGroupColor || group.use_group_color || 0,
        createdAt: group.createdAt || group.created_at,
        createBy: group.createBy || group.create_by,
        updatedAt: group.updatedAt || group.updated_at,
        updatedBy: group.updatedBy || group.updated_by
      });
      if (group.children && group.children.length > 0) {
        const childGroups = flattenGroups(group.children);
        childGroups.forEach(child => {
          child.parentId = groupId;
        });
        result.push(...childGroups);
      }
    });
    return result;
  };

  const flatGroups = flattenGroups(groups);

  flatGroups.forEach(group => {
    const treeNode = {
      id: group.groupId,
      groupId: group.groupId,
      label: group.groupName,
      parentId: group.parentId,
      attributes: group.attributes || '',
      color: group.colorCode || null,
      useGroupColor: group.useGroupColor === 1,
      createdAt: group.createdAt,
      createdBy: group.createBy,
      createByName: group.createByName || group.create_by_name,
      updatedAt: group.updatedAt,
      updatedBy: group.updatedBy,
      updatedByName: group.updatedByName || group.updated_by_name,
      children: []
    };
    groupMap.set(group.groupId, treeNode);
  });

  flatGroups.forEach(group => {
    const treeNode = groupMap.get(group.groupId);
    if (group.parentId && groupMap.has(group.parentId)) {
      groupMap.get(group.parentId).children.push(treeNode);
    } else {
      rootGroups.push(treeNode);
    }
  });

  return rootGroups;
}

function convertColorToHex(color) {
  if (!color) return null;

  // If already in hex format, return as is
  if (color.startsWith('#')) {
    return color;
  }

  // Convert RGBA to hex
  if (color.startsWith('rgba(') || color.startsWith('rgb(')) {
    const values = color.match(/\d+/g);
    if (values && values.length >= 3) {
      const r = parseInt(values[0]);
      const g = parseInt(values[1]);
      const b = parseInt(values[2]);
      return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
    }
  }

  // Fallback to default color if format is unrecognized
  return '#409EFF';
}

async function saveGroupToAPI() {
  if (!selectedGroup.value) return;
  // Use the selectedGroup's parentId directly, with fallback to tree search
  let parentId = selectedGroup.value.parent_id;

  // Only search the tree if parentId is undefined and we have a groupId
  if (parentId === undefined && selectedGroup.value.groupId) {
    const originalGroup = findGroupInTree(groupTreeData.value, selectedGroup.value.groupId);
    parentId = originalGroup?.parentId || null;
  } else if (parentId === undefined) {
    parentId = null;
  }

  const convertedColor = convertColorToHex(selectedGroup.value.colorCode);

  const groupData = {
    groupId: selectedGroup.value.groupId || null,
    groupName: selectedGroup.value.label,
    parentId: parentId,
    colorCode: convertedColor,
    useGroupColor: selectedGroup.value.useGroupColor || false,
    attributes: selectedGroup.value.attributes || ''
  };

  if (selectedGroup.value.groupId) {
    await updateGroup(selectedGroup.value.groupId, groupData);
  } else {
    await createGroup(groupData);
  }
}

function findGroupInTree(groups, groupId) {
  for (const group of groups) {
    if (group.groupId === groupId) {
      return group;
    }
    if (group.children && group.children.length > 0) {
      const found = findGroupInTree(group.children, groupId);
      if (found) return found;
    }
  }
  return null;
}

onMounted(() => {
  loadGroups();
});
</script>

<style lang="scss" scoped>
@import '@/assets/styles/variables.module.scss';

.group-management-container {
  padding: 0;
  background-color: $light-bg-alt;
  height: 100%;
  width: 100%;
}

.content-container {
  display: flex;
  height: 100%;
  gap: 20px;
  padding: 20px;
  box-sizing: border-box;
}

.left-panel {
  width: 40%;
  min-width: 300px;
  background: linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%);
  border-radius: $border-radius;
  padding: 20px;
  box-shadow: 0 4px 12px rgba(88, 126, 206, 0.15);
  border: 1px solid rgba(88, 126, 206, 0.1);
}

.right-panel {
  flex: 1;
  background: linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%);
  border-radius: $border-radius;
  padding: 20px;
  box-shadow: 0 4px 12px rgba(88, 126, 206, 0.15);
  border: 1px solid rgba(88, 126, 206, 0.1);
}

.tree-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.tree-header h3 {
  margin: 0;
  color: $primary-color;
  font-size: 18px;
  font-weight: 600;
}

.details-header h3 {
  margin: 0 0 20px 0;
  color: $primary-color;
  font-size: 18px;
  font-weight: 600;
}

.group-tree-container {
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  padding: 10px;
  max-height: 600px;
  overflow-y: auto;
  overflow-x: auto;
}

.section {
  height: 100%;
}

.group-details {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.detail-item {
  display: flex;
  flex-direction: column;
  gap: 8px;

  label {
    font-weight: 600;
    color: #606266;
  }
}

.action-buttons {
  display: flex;
  gap: 10px;
  margin-top: 20px;
  
  .el-button {
    border-radius: 8px !important;
    font-weight: 500 !important;
    transition: all 0.3s ease !important;
    
    &:hover {
      transform: translateY(-2px) !important;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15) !important;
    }
  }
  
  .el-button--primary {
    background: linear-gradient(135deg, #587ece 0%, #8bacf3 100%) !important;
    border: none !important;
    
    &:hover {
      background: linear-gradient(135deg, #4a6bb8 0%, #7a9ee8 100%) !important;
    }
  }
  
  .el-button--success {
    background: linear-gradient(135deg, #67c23a 0%, #85ce61 100%) !important;
    border: none !important;
    
    &:hover {
      background: linear-gradient(135deg, #5daf34 0%, #73c956 100%) !important;
    }
  }
  
  .el-button--danger {
    background: linear-gradient(135deg, #f56c6c 0%, #f78989 100%) !important;
    border: none !important;
    
    &:hover {
      background: linear-gradient(135deg, #f45656 0%, #f67e7e 100%) !important;
    }
  }
}

.color-selection-container {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.color-usage-selection {
  margin-bottom: 10px;
}

.color-controls {
  display: flex;
  align-items: center;
  gap: 15px;
}

.color-preview-sample {
  width: 30px;
  height: 30px;
  border-radius: 4px;
  border: 1px solid #dcdfe6;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  flex-shrink: 0;
}

.color-preview-sample.no-color {
  background: repeating-linear-gradient(45deg,
      #f5f7fa,
      #f5f7fa 5px,
      #e4e7ed 5px,
      #e4e7ed 10px);
}

.color-disabled-message {
  padding: 10px;
  background-color: #f5f7fa;
  border: 1px solid #e4e7ed;
  border-radius: 4px;
  color: #909399;
  font-style: italic;
}

.disabled-text {
  font-size: 14px;
}

.color-preview-container {
  display: flex;
  align-items: center;
  gap: 10px;
}

.color-preview {
  width: 30px;
  height: 30px;
  border-radius: 4px;
  border: 1px solid #dcdfe6;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.color-code {
  font-family: 'Courier New', monospace;
  font-size: 14px;
  color: #606266;
  background-color: #f5f7fa;
  padding: 4px 8px;
  border-radius: 4px;
  border: 1px solid #e4e7ed;
  min-width: 80px;
  text-align: center;
}

.editable-field {
  display: flex;
  align-items: center;
  gap: 10px;
}

.edit-actions {
  display: flex;
  gap: 5px;
}

.color-actions {
  display: flex;
  gap: 5px;
  margin-left: 10px;
}

.color-preview.no-color {
  background: repeating-linear-gradient(45deg,
      #f5f7fa,
      #f5f7fa 5px,
      #e4e7ed 5px,
      #e4e7ed 10px);
}

.system-attributes {
  background-color: #f8f9fa;
  border: 1px solid #e9ecef;
  border-radius: 4px;
  padding: 15px;
}

.attribute-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 5px 0;
  border-bottom: 1px solid #e9ecef;
}

.attribute-row:last-child {
  border-bottom: none;
}

.attribute-label {
  font-weight: 600;
  color: #495057;
  min-width: 120px;
}

.attribute-value {
  color: #6c757d;
  font-family: 'Courier New', monospace;
  font-size: 13px;
}

.no-selection {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 200px;
  color: #c0c4cc;
  font-size: 16px;
}

.no-groups-container {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 200px;
  padding: 20px;
}

.no-groups-message {
  text-align: center;
  color: #909399;
}

.no-groups-message p {
  margin: 0 0 15px 0;
  font-size: 16px;
}

/* カラーピッカーのサイズを大きくするカスタムスタイル */
:deep(.el-color-picker__panel) {
  width: 350px !important;
  height: 400px !important;
}

:deep(.el-color-picker__panel .el-color-svpanel) {
  width: 320px !important;
  height: 200px !important;
}

:deep(.el-color-picker__panel .el-color-hue-slider) {
  width: 320px !important;
  height: 20px !important;
}

:deep(.el-color-picker__panel .el-color-alpha-slider) {
  width: 320px !important;
  height: 20px !important;
}

:deep(.el-color-picker__panel .el-color-predefine) {
  width: 320px !important;
}

:deep(.el-color-picker__panel .el-color-predefine__colors) {
  width: 100% !important;
}

:deep(.el-color-picker__panel .el-input) {
  width: 120px !important;
}

/* 深い階層のツリー表示を改善 */
:deep(.el-tree-node) {
  white-space: nowrap;
}

:deep(.el-tree-node__content) {
  height: auto;
  min-height: 32px;
  padding: 4px 0;
}

:deep(.el-tree-node__label) {
  font-size: 14px;
  line-height: 1.4;
  word-break: break-word;
  white-space: normal;
}

/* 深い階層でのインデント調整 */
:deep(.el-tree-node__children) {
  overflow: visible;
}

/* 階層の深さに応じた視覚的な区別 */
:deep(.el-tree-node[aria-level="4"] .el-tree-node__content) {
  background-color: #f8f9fa;
}

:deep(.el-tree-node[aria-level="5"] .el-tree-node__content) {
  background-color: #f1f3f4;
}

:deep(.el-tree-node[aria-level="6"] .el-tree-node__content) {
  background-color: #e8eaed;
}

@media (max-width: 992px) {
  .content-container {
    flex-direction: column;
  }

  .left-panel {
    width: 100%;
    min-width: auto;
  }

  .group-tree-container {
    max-height: 400px;
  }
}
</style>
