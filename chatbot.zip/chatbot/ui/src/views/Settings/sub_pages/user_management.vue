<template>
  <div class="user-management-container">

    <div class="content-container">
      <!-- メインコンテンツエリア -->
      <div class="right-panel">
        <!-- 表格檢視 -->
        <div class="section results-section table-view">
          <!-- 表格頂部操作區域 -->
          <div class="table-header">
            <div class="table-title">
              <h3>ユーザー管理</h3>
            </div>

          </div>

          <div class="table-header">
            <div class="table-actions">
              <el-button type="info" icon="Filter" round @click="filterExpanded = !filterExpanded">フィルタ</el-button>
              <el-button type="success" icon="Plus" round @click="handleCreate">登録</el-button>
              <el-button type="primary" icon="Setting" round @click="openGroupManagement">グループ管理</el-button>
            </div>
          </div>

          <transition name="fade">
            <div v-if="filterExpanded" class="filter-content">
              <el-form :model="queryParams" ref="queryRef" label-width="120px">
                <el-form-item label="ユーザー名">
                  <el-input v-model="queryParams.keyword" placeholder="検索したいユーザー名を入力" clearable
                    @keyup.enter="filterQuery">
                    <template #append>
                      <el-button icon="Search" @click="filterQuery"></el-button>
                    </template>
                  </el-input>
                </el-form-item>

                <!-- <el-form-item label="ロール">
                    <el-select v-model="queryParams.tags" multiple placeholder="タグを選択" clearable style="width: 100%">
                      <el-option v-for="tag in tagOptions" :key="tag.value" :label="tag.label" :value="tag.value" />
                    </el-select>
                  </el-form-item> -->

                <el-form-item label="状態">
                  <el-select v-model="queryParams.flag" placeholder="状態を選択" clearable style="width: 100%">
                    <el-option label="有効" :value="1"></el-option>
                    <el-option label="無効" :value="0"></el-option>
                  </el-select>
                </el-form-item>

                <!-- 按鈕 -->
                <el-form-item>
                  <div class="apply-buttons">
                    <el-button type="primary" @click="filterQuery">適用</el-button>
                    <el-button @click="resetQuery">リセット</el-button>
                  </div>
                </el-form-item>
              </el-form>
            </div>
          </transition>

          <el-table v-loading="loading" :data="userList" @selection-change="handleSelectionChange">
            <el-table-column type="selection" width="55" align="center" />
            <el-table-column label="ID" width="80" prop="id"></el-table-column>
            <el-table-column label="ユーザー名" prop="user_name" :show-overflow-tooltip="true" />
            <!-- <el-table-column label="ロール" width="200">
              <template #default="scope">
                <span v-if="scope.row.user_name === 'admin'"><el-tag>管理者</el-tag></span>
                <span v-else><el-tag>ユーザー</el-tag></span>
              </template>
            </el-table-column> -->
            <el-table-column label="状態" width="180">
              <template #default="scope">
                <el-switch v-model="scope.row.status" active-value="1" inactive-value="0"
                  @change="handleStatusChange(scope.row)"></el-switch>
              </template>
            </el-table-column>
            <el-table-column label="操作" align="center" width="130" class-name="small-padding fixed-width">
              <template #default="scope">
                <el-tooltip content="変更" placement="top" v-if="scope.row.id !== 1">
                  <el-button link type="primary" icon="Edit" @click="openEditDialog(scope.row)"></el-button>
                </el-tooltip>
                <el-tooltip content="削除" placement="top" v-if="scope.row.id !== 1">
                  <el-button link type="primary" icon="Delete" @click="handleDelete(scope.row)"></el-button>
                </el-tooltip>
                <el-tooltip content="パスワードをリセットする" placement="top">
                  <el-button link type="primary" icon="Key" @click="openPasswordResetDialog(scope.row)"></el-button>
                </el-tooltip>
              </template>
            </el-table-column>
          </el-table>

          <pagination v-show="total > 0" :total="total" v-model:page="queryParams.pageNum"
            v-model:limit="queryParams.pageSize" @pagination="getList" />
        </div>
      </div>
    </div>
    <el-dialog :title="title" v-model="createUserDialog" width="1000px" append-to-body :lock-scroll="false"
      :modal-append-to-body="false">
      <div class="user-edit-container">
        <div class="user-form-section">
          <el-form ref="userRef" :model="form" :rules="rules" label-width="120px">
            <el-form-item label="ユーザー名" prop="user_name">
              <el-input v-model="form.user_name" placeholder="ユーザー名を入力" />
            </el-form-item>
            <el-form-item label="パスワード" prop="password">
              <el-input v-model="form.password" placeholder="パスワードを入力" type="password" show-password />
            </el-form-item>
            <el-form-item label="メールアドレス" prop="mail_address">
              <el-input v-model="form.mail_address" placeholder="メールアドレスを入力" />
            </el-form-item>
            <el-form-item label="電話番号" prop="phone_num">
              <el-input v-model="form.phone_num" placeholder="電話番号を入力" />
            </el-form-item>
            <!-- <el-form-item label="ロール" prop="tags">
              <el-select v-model="form.tags" multiple placeholder="ロールを選択" clearable style="width: 100%">
                <el-option v-for="tag in tagOptions" :key="tag.value" :label="tag.label" :value="tag.value" />
              </el-select>
            </el-form-item> -->
            <el-form-item label="状態" prop="flag">
              <el-select v-model="form.flag" placeholder="状態を選択" clearable style="width: 100%">
                <el-option label="有効" :value="1"></el-option>
                <el-option label="無効" :value="0"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item>
              <div class="dialog-footer">
                <div class="left-actions">
                  <el-button @click="createUserDialog = false">キャンセル</el-button>
                  <el-button type="primary" @click="handleSubmitCreate" :disabled="!isFormValid">
                    登録
                  </el-button>
                </div>
              </div>
            </el-form-item>
          </el-form>
        </div>
        <div class="group-settings-section">
          <h3>Group IDs</h3>
          <div class="selected-groups-display">
            <div class="selected-groups-tags">
              <el-tag v-for="group in selectedGroupsForDisplayCreate" :key="group.value" :color="group.color" closable
                @close="removeGroupTagCreate(group.value)" class="group-tag">
                {{ group.label }}
              </el-tag>
              <span v-if="selectedGroupsForDisplayCreate.length === 0" class="no-groups-text">
                選択されたグループはありません
              </span>
            </div>
          </div>
          <div class="group-tree-container tree-border">
            <el-tree ref="groupTreeCreateRef" :data="groupTreeData" :props="groupTreeProps" show-checkbox node-key="id"
              :check-strictly="true" @check="handleGroupCheckCreate" />
          </div>
        </div>
      </div>
    </el-dialog>
    <el-dialog :title="title" v-model="editUserDialog" width="1000px" append-to-body :lock-scroll="false"
      :modal-append-to-body="false">
      <div class="user-edit-container">
        <div class="user-form-section">
          <el-form ref="userRef" :model="form" :rules="rules" label-width="120px">
            <el-form-item label="ユーザー名" prop="user_name">
              <el-input v-model="form.user_name" placeholder="ユーザー名を入力" />
            </el-form-item>
            <el-form-item label="メールアドレス" prop="mail_address">
              <el-input v-model="form.mail_address" placeholder="メールアドレスを入力" />
            </el-form-item>
            <el-form-item label="電話番号" prop="phone_num">
              <el-input v-model="form.phone_num" placeholder="電話番号を入力" />
            </el-form-item>
            <!-- <el-form-item label="ロール" prop="tags">
              <el-select v-model="form.tags" multiple placeholder="ロールを選択" clearable style="width: 100%">
                <el-option v-for="tag in tagOptions" :key="tag.value" :label="tag.label" :value="tag.value" />
              </el-select>
            </el-form-item> -->
            <el-form-item label="状態" prop="flag">
              <el-select v-model="form.flag" placeholder="状態を選択" clearable style="width: 100%">
                <el-option label="有効" :value="1"></el-option>
                <el-option label="無効" :value="0"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item>
              <div class="dialog-footer">
                <div class="left-actions">
                  <el-button @click="handleCancel">キャンセル</el-button>
                  <el-button type="primary" @click="handleUpdate">
                    変更
                  </el-button>
                </div>
                <!--
                <div class="delete-actions">
                  <el-button type="danger" @click="DeleteDialog">削除</el-button>
                </div>-->
              </div>
            </el-form-item>
          </el-form>
        </div>
        <div class="group-settings-section">
          <h3>Group IDs</h3>
          <div class="selected-groups-display">
            <div class="selected-groups-tags">
              <el-tag v-for="group in selectedGroupsForDisplay" :key="group.value" :color="group.color" closable
                @close="removeGroupTag(group.value)" class="group-tag">
                {{ group.label }}
              </el-tag>
              <span v-if="selectedGroupsForDisplay.length === 0" class="no-groups-text">
                選択されたグループはありません
              </span>
            </div>
          </div>
          <div class="group-tree-container tree-border">
            <el-tree ref="groupTreeRef" :data="groupTreeData" :props="groupTreeProps" show-checkbox node-key="id"
              :check-strictly="true" @check="handleGroupCheck" />
          </div>
        </div>
      </div>
    </el-dialog>
    <el-dialog :title="title" v-model="deleteUserDialog" width="600px" append-to-body :lock-scroll="false"
      :modal-append-to-body="false">
      <div class="delete-content">
        <h2>本当にユーザーを削除しますか？</h2>
        <div class="dialog-footer">
          <div class="left-actions">
            <el-button @click="deleteUserDialog = false">キャンセル</el-button>
            <el-button type="danger" @click="handleDelete">削除</el-button>
          </div>
        </div>
      </div>
    </el-dialog>

    <el-dialog :title="title" v-model="resetPasswordDialog" width="600px" append-to-body :lock-scroll="false"
      :modal-append-to-body="false">
      <el-form ref="userRef" :model="form" :rules="rules" label-width="120px">
        <el-form-item label="パスワード" prop="password">
          <el-input v-model="form.password" placeholder="パスワードを入力" type="password" show-password />
        </el-form-item>
      </el-form>
        <span class="dialog-footer">
          <el-button @click="resetPasswordDialog = false">キャンセル</el-button>
          <el-button type="primary" @click="handleResetPassword">更新</el-button>
        </span>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, toRefs, getCurrentInstance, computed } from 'vue';
import { delUser, changeUserStatus, getUserList, createUser, updateUser, getUserGroups , changeUserPassword} from "@/api/user";
import { getGroupList } from "@/api/group";

const { proxy } = getCurrentInstance();
const emit = defineEmits(['navigate-to-group']);

// 數據狀態
const loading = ref(true);
const multiple = ref(true);
const total = ref(0);
const filterExpanded = ref(false);
const open = ref("");
const title = ref("");
const createUserDialog = ref(false);
const editUserDialog = ref(false);
const deleteUserDialog = ref(false);
const resetPasswordDialog = ref(false);

const ids = ref([]);

const userList = ref([]);

// タグオプション
const tagOptions = [
  { label: '管理者', value: 'admin' },
  { label: 'ユーザー', value: 'user' }
];

const rules = reactive({
  user_name: [
    { required: true, message: "ユーザー名を入力してください", trigger: "blur" },
    { min: 4, message: "ユーザー名は4文字以上で入力してください", trigger: "blur" }
  ],
  password : [
    { required: true, message: "パスワードを入力してください。", trigger: "blur" },
    { min: 8, message: "パスワードは8文字以上で入力してください", trigger: "blur" }
  ]
});


// 用於表單和查詢的數據
const data = reactive({
  form: {
    id: null,
    user_name: "",
    password : "",
    mail_address: "",
    phone_num: "",
    tags: [],
    flag: ""
  },
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    keyword: '',
    tags: [],
    flag: ''
  }
});

const { queryParams, form } = toRefs(data);

// グループ設定関連のデータ
const selectedGroupIds = ref([]);
const selectedGroupIdsCreate = ref([]);
const groupTreeData = ref([]);

const groupTreeProps = reactive({
  children: 'children',
  label: 'label'
});

// フォームバリデーション状態を監視するcomputed
const isFormValid = computed(() => {
  const username = form.value.user_name;
  return username && username.length >= 4;
});

// 選択されたグループを表示用に変換するcomputed
const selectedGroupsForDisplay = computed(() => {
  const result = [];
  const findNodeById = (nodes, id, level = 1) => {
    for (const node of nodes) {
      if (node.id === id) return { ...node, level };
      if (node.children) {
        const found = findNodeById(node.children, id, level + 1);
        if (found) return found;
      }
    }
    return null;
  };

  const getGroupColor = (node) => {
    if (node.useGroupColor === 1 && node.colorCode) {
      return node.colorCode;
    }
    return '#909399';
  };

  selectedGroupIds.value.forEach(id => {
    const node = findNodeById(groupTreeData.value, id);
    if (node) {
      result.push({
        value: id,
        label: node.label,
        color: getGroupColor(node)
      });
    }
  });

  return result;
});

function handleStatusChange(row) {
  let text = row.status === "1" ? "有効" : "無効";
  proxy.$modal
    .confirm('本当に' + row.user_name + "アカウントを" + text + 'にしますか?')
    .then(function () {
      return changeUserStatus(row.id, row.status);
    })
    .then(() => {
      proxy.$modal.msgSuccess(text + "成功");
    })
    .catch(function () {
      row.status = row.status === "0" ? "1" : "0";
    });
}

// 作成用選択されたグループを表示用に変換するcomputed
const selectedGroupsForDisplayCreate = computed(() => {
  const result = [];
  const findNodeById = (nodes, id, level = 1) => {
    for (const node of nodes) {
      if (node.id === id) return { ...node, level };
      if (node.children) {
        const found = findNodeById(node.children, id, level + 1);
        if (found) return found;
      }
    }
    return null;
  };

  const getGroupColor = (node) => {
    if (node.useGroupColor === 1 && node.colorCode) {
      return node.colorCode;
    }
    return '#909399';
  };

  selectedGroupIdsCreate.value.forEach(id => {
    const node = findNodeById(groupTreeData.value, id);
    if (node) {
      result.push({
        value: id,
        label: node.label,
        color: getGroupColor(node)
      });
    }
  });

  return result;
});

// 方法
function getList() {
  loading.value = true;
  getUserList(queryParams.value).then((response) => {
    userList.value = response.result.rows.map(user => ({
      id: user.user_id,
      user_name: user.user_name,
      mail_address: user.email || '',
      phone_num: user.phonenumber || '',
      tags: [],
      status: user.status
    }));
    total.value = response.result.count;
    loading.value = false;
  }).catch((error) => {
    console.error('ユーザー一覧の取得に失敗しました:', error);
    loading.value = false;
  });
}

function filterQuery() {
  queryParams.value.pageNum = 1;
  getList();
}

function resetQuery() {
  proxy.resetForm("queryRef");
  queryParams.value = {
    pageNum: 1,
    pageSize: 10,
    keyword: '',
    tags: [],
    flag: ''
  };
  getList();
}

function handleSelectionChange(selection) {
  multiple.value = !selection.length;
}

function handleSizeChange(val) {
  queryParams.value.pageSize = val;
  getList();
}

function handleCurrentChange(val) {
  queryParams.value.pageNum = val;
  getList();
}

function handleCreate() {
  reset();
  open.value = true;
  title.value = "ユーザー登録";
  // 追加：バリデーションのリセット
  proxy.$refs.userRef?.resetFields();
  createUserDialog.value = true;
}

function handleSubmitCreate() {
  proxy.$refs.userRef.validate((valid) => {
    if (valid) {
      const userData = {
        userName: form.value.user_name,
        email: form.value.mail_address,
        password: form.value.password,
        phonenumber: form.value.phone_num,
        groupIds: selectedGroupIdsCreate.value
      };

      createUser(userData).then((response) => {
        proxy.$message.success('ユーザーが正常に作成されました');
        createUserDialog.value = false;
        getList(); // リストを再取得
      }).catch((error) => {
        console.error('ユーザー作成に失敗しました:', error);
        proxy.$message.error(error.response?.data?.message || 'ユーザー作成に失敗しました');
      });
    }
  });
}

function handleCancel() {
  editUserDialog.value = false;
}

function handleUpdate() {
  proxy.$refs.userRef.validate((valid) => {
    if (valid) {
      const userData = {
        userId: form.value.id,
        userName: form.value.user_name,
        email: form.value.mail_address,
        phonenumber: form.value.phone_num,
        groupIds: selectedGroupIds.value
      };

      updateUser(userData).then((response) => {
        proxy.$message.success('ユーザーが正常に更新されました');
        editUserDialog.value = false;
        getList();
      }).catch((error) => {
        console.error('ユーザー更新に失敗しました:', error);
        proxy.$message.error(error.response?.data?.message || 'ユーザー更新に失敗しました');
      });
    }
  });
}

function reset() {
  form.value = {
    id: null,
    user_name: "",
    mail_address: "",
    phone_num: "",
    tags: [],
    flag: false // デフォルトで無効
  };
  selectedGroupIdsCreate.value = [];
  if (proxy.$refs.groupTreeCreateRef) {
    proxy.$refs.groupTreeCreateRef.setCheckedKeys([]);
  }
}

function openEditDialog(user) {
  proxy.$refs.userRef?.resetFields();
  form.value = {
    id: user.id,
    user_name: user.user_name,
    mail_address: user.mail_address || "",
    phone_num: user.phone_num || "",
    tags: user.tags ? [...user.tags] : [],
    flag: user.flag
  };
  title.value = "ユーザー編集";
  resetGroupSettings();

  getUserGroups(user.id).then((response) => {
    const userGroupIds = response.result || [];
    selectedGroupIds.value = userGroupIds;

    if (proxy.$refs.groupTreeRef) {
      proxy.$refs.groupTreeRef.setCheckedKeys(userGroupIds);
    }
  }).catch((error) => {
    console.error('ユーザーグループの取得に失敗しました:', error);
    selectedGroupIds.value = [];
  });

  editUserDialog.value = true;
}

function openPasswordResetDialog(user) {
  proxy.$refs.userRef?.resetFields();
  form.value = {
    id: user.id,
    password: ""
  };
  resetPasswordDialog.value = true;
}
function handleResetPassword(){
  const newpasswd = form.value.password;
  if(newpasswd && newpasswd.length >= 8) {
    changeUserPassword(form.value.id, newpasswd)
    .then( result => {
      resetPasswordDialog.value = false;
      proxy.$message.success('パスワードが変更されました');
     } ).catch( (error) => {
        console.error('パスワード変更に失敗しました:', error);
        proxy.$message.error(error.response?.data?.message || 'パスワード変更に失敗しました');
     });
  }
}

function DeleteDialog() {
  deleteUserDialog.value = true;
  title.value = "ユーザー削除";
}

function handleDelete(row) {
  const userIds = row.id || ids.value;
  proxy.$modal
    .confirm("このユーザーを削除しますか？")
    .then(function () {
      return delUser(userIds);
    })
    .then(() => {
      getList();
      proxy.$modal.msgSuccess("ユーザーの削除に成功しました");
    })
    .catch(() => { });
}

// グループツリーのチェック処理
function handleGroupCheck(data, checked) {
  const checkedNodes = proxy.$refs.groupTreeRef.getCheckedNodes();
  let allSelectedIds = checkedNodes.map(node => node.id);

  // 子要素が選択された場合、親要素も自動選択する
  if (checked) {
    const addParentNodes = (nodeId) => {
      const findParent = (nodes, targetId, parent = null) => {
        for (const node of nodes) {
          if (node.id === targetId) {
            return parent;
          }
          if (node.children) {
            const found = findParent(node.children, targetId, node);
            if (found) return found;
          }
        }
        return null;
      };

      const parent = findParent(groupTreeData.value, nodeId);
      if (parent && !allSelectedIds.includes(parent.id)) {
        allSelectedIds.push(parent.id);
        proxy.$refs.groupTreeRef.setChecked(parent.id, true, false);
        addParentNodes(parent.id); // 再帰的に祖先も選択
      }
    };

    addParentNodes(data.id);
  } else {
    // 親要素のチェックが外れた場合、子要素も連動してチェックを外す
    const removeChildNodes = (nodeId) => {
      const findNodeById = (nodes, id) => {
        for (const node of nodes) {
          if (node.id === id) return node;
          if (node.children) {
            const found = findNodeById(node.children, id);
            if (found) return found;
          }
        }
        return null;
      };

      const node = findNodeById(groupTreeData.value, nodeId);
      if (node && node.children) {
        node.children.forEach(child => {
          // 子要素のチェックを外す
          proxy.$refs.groupTreeRef.setChecked(child.id, false, false);
          // selectedGroupIdsからも削除
          allSelectedIds = allSelectedIds.filter(id => id !== child.id);
          // 再帰的に孫要素も処理
          removeChildNodes(child.id);
        });
      }
    };

    removeChildNodes(data.id);
  }

  selectedGroupIds.value = allSelectedIds;
}

// ユーザー編集ダイアログを開く際にグループ設定をリセット
function resetGroupSettings() {
  selectedGroupIds.value = [];
  if (proxy.$refs.groupTreeRef) {
    proxy.$refs.groupTreeRef.setCheckedKeys([]);
  }
}

// グループタグの削除処理
function removeGroupTag(groupId) {
  selectedGroupIds.value = selectedGroupIds.value.filter(id => id !== groupId);

  if (proxy.$refs.groupTreeRef) {
    const currentCheckedKeys = proxy.$refs.groupTreeRef.getCheckedKeys();
    const updatedKeys = currentCheckedKeys.filter(key => key !== groupId);
    proxy.$refs.groupTreeRef.setCheckedKeys(updatedKeys);
  }
}

// グループタグの削除処理（作成用）
function removeGroupTagCreate(groupId) {
  selectedGroupIdsCreate.value = selectedGroupIdsCreate.value.filter(id => id !== groupId);

  if (proxy.$refs.groupTreeCreateRef) {
    const currentCheckedKeys = proxy.$refs.groupTreeCreateRef.getCheckedKeys();
    const updatedKeys = currentCheckedKeys.filter(key => key !== groupId);
    proxy.$refs.groupTreeCreateRef.setCheckedKeys(updatedKeys);
  }
}

// グループツリーのチェック処理（作成用）
function handleGroupCheckCreate(data, checked) {
  const checkedNodes = proxy.$refs.groupTreeCreateRef.getCheckedNodes();
  let allSelectedIds = checkedNodes.map(node => node.id);

  // 子要素が選択された場合、親要素も自動選択する
  if (checked) {
    const addParentNodes = (nodeId) => {
      const findParent = (nodes, targetId, parent = null) => {
        for (const node of nodes) {
          if (node.id === targetId) {
            return parent;
          }
          if (node.children) {
            const found = findParent(node.children, targetId, node);
            if (found) return found;
          }
        }
        return null;
      };

      const parent = findParent(groupTreeData.value, nodeId);
      if (parent && !allSelectedIds.includes(parent.id)) {
        allSelectedIds.push(parent.id);
        proxy.$refs.groupTreeCreateRef.setChecked(parent.id, true, false);
        addParentNodes(parent.id);
      }
    };

    addParentNodes(data.id);
  } else {
    // 親要素のチェックが外れた場合、子要素も連動してチェックを外す
    const removeChildNodes = (nodeId) => {
      const findNodeById = (nodes, id) => {
        for (const node of nodes) {
          if (node.id === id) return node;
          if (node.children) {
            const found = findNodeById(node.children, id);
            if (found) return found;
          }
        }
        return null;
      };

      const node = findNodeById(groupTreeData.value, nodeId);
      if (node && node.children) {
        node.children.forEach(child => {
          proxy.$refs.groupTreeCreateRef.setChecked(child.id, false, false);
          allSelectedIds = allSelectedIds.filter(id => id !== child.id);
          removeChildNodes(child.id);
        });
      }
    };

    removeChildNodes(data.id);
  }

  selectedGroupIdsCreate.value = allSelectedIds;
}

function openGroupManagement() {
  emit('navigate-to-group');
}

// グループデータをAPIから取得
function loadGroupData() {
  getGroupList().then((response) => {
    groupTreeData.value = response.result || [];
  }).catch((error) => {
    console.error('グループデータの取得に失敗しました:', error);
    groupTreeData.value = [];
  });
}

// 初期化
getList();
loadGroupData();
</script>

<style lang="scss" scoped>
@import '@/assets/styles/variables.module.scss';

html,
body {
  margin: 0;
  padding: 0;
  height: 100%;
}

// Element UIダイアログのレイアウトシフトを防止
:global(.el-popup-parent--hidden) {
  padding-right: 0 !important;
}

.user-management-container {
  padding: 0;
  background-color: $light-bg-alt;
  height: 100%;
  width: 100%;
}

.content-container {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  padding: 0;
  min-width: 0;
}

.sidebar {
  width: 20%;
  height: 100vh;
  min-width: 200px;
  padding: 0;
}

.right-panel {
  flex: 1 1 0;
  min-width: 0;
  padding: 20px;
  box-sizing: border-box;
  overflow-x: auto;
}

.section {
  align-items: center;
  margin-bottom: 20px;
  background-color: white;
  border-radius: $border-radius;
  padding: 15px;
  box-shadow: $shadow;
}

// 主動作按鈕使用主色調
.el-button--primary {
  background-color: $primary-color;
  border-color: $primary-color;

  &:hover {
    background-color: $primary-light;
    border-color: $primary-light;
  }
}

.el-button--success {
  background: linear-gradient(135deg, #67c23a 0%, #85ce61 100%) !important;
  border: none !important;
  color: #fff !important;
  border-radius: 8px !important;
  font-weight: 500 !important;
  transition: all 0.3s ease !important;

  &:hover {
    background: linear-gradient(135deg, #5daf34 0%, #73c956 100%) !important;
    transform: translateY(-2px) !important;
    box-shadow: 0 4px 12px rgba(103, 194, 58, 0.3) !important;
  }
}

.el-button--info {
  background: linear-gradient(135deg, #587ece 0%, #8bacf3 100%) !important;
  border: none !important;
  color: #fff !important;
  border-radius: 8px !important;
  font-weight: 500 !important;
  transition: all 0.3s ease !important;

  &:hover {
    background: linear-gradient(135deg, #4a6bb8 0%, #7a9ee8 100%) !important;
    transform: translateY(-2px) !important;
    box-shadow: 0 4px 12px rgba(88, 126, 206, 0.3) !important;
  }
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: center;
}

.table-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
  padding-bottom: 10px;
  border-bottom: 1px solid #e4e7ed;
}

.table-title h3 {
  margin: 0;
  color: $primary-color;
  font-size: 18px;
  font-weight: 600;
}

.table-actions {
  display: flex;
  gap: 10px;
}

.el-button+.el-button {
  margin: 0px;
}

.apply-buttons {
  display: flex;
  gap: 10px;
}

.fade-enter-active,
.fade-leave-active {
  transition: all 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
  transform: translateY(-10px);
}

.dialog-footer {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
  width: 100%;
}

.left-actions {
  display: flex;
  gap: 10px;
  align-items: center;
}

.left-actions>.el-button:first-child {
  background-color: #fff;
  color: $primary-dark;
  border: 1px solid $primary-dark;
}

.left-actions>.el-button:first-child:hover {
  color: $secondary-blue;
  background: #f5f7fa;
}

.delete-actions {
  display: flex;
  align-items: center;

  // ボタンの背景色・文字色を強制的に上書き（グローバル適用）
  ::v-deep .el-button--danger {
    background-color: #C62828 !important;
    border-color: #C62828 !important;
    color: #FFFFFF !important;
  }

  ::v-deep .el-button--danger:hover {
    background-color: #8B0000 !important;
    border-color: #8B0000 !important;
    color: #FFFFFF !important;
  }
}

// ユーザー編集ダイアログのレイアウト
.user-edit-container {
  display: flex;
  gap: 30px;
  min-height: 400px;
}

.user-form-section {
  flex: 1;
  min-width: 400px;
}

.group-settings-section {
  flex: 1;
  min-width: 400px;

  h3 {
    margin: 0 0 15px 0;
    color: $primary-color;
    font-size: 16px;
    font-weight: 600;
  }
}

.selected-groups-display {
  margin-bottom: 15px;
}

.selected-groups-tags {
  height: 128px;
  padding: 8px;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  background-color: #fff;
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: flex-start;
  overflow-y: auto;
  align-content: flex-start;
}

.group-tag {
  margin: 0;
  color: #fff;
  font-weight: 500;
  border-radius: 12px !important;
  padding: 4px 12px !important;
  font-size: 13px !important;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1) !important;
  transition: all 0.2s ease !important;

  &:hover {
    transform: translateY(-1px) !important;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15) !important;
  }
}

.no-groups-text {
  color: #c0c4cc;
  font-size: 14px;
  font-style: italic;
}

.group-tree-container {
  height: 300px;
  overflow-y: auto;
  padding: 10px;

  .el-tree {
    background: transparent;
  }

  .el-tree-node__content {
    height: 32px;
    line-height: 32px;
  }

  .el-tree-node__label {
    font-size: 14px;
  }
}

// レスポンシブ対応
@media (max-width: 1200px) {
  .user-edit-container {
    flex-direction: column;
    gap: 20px;
  }

  .user-form-section,
  .group-settings-section {
    min-width: auto;
  }
}

// 響應式設計
@media (max-width: 992px) {
  .content-container {
    flex-direction: column;
    min-width: 0;
  }

  .right-panel {
    width: 100%;
    min-width: 0;
    flex: 1 1 100%;
  }

  .table-header {
    flex-wrap: wrap;
    gap: 10px;
  }
}
</style>
