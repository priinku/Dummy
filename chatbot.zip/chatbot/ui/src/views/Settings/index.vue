<template>
  <div class="settings-container">
    <!-- サイドバー部分 -->
      <div class="home-button">
        <el-button type="primary" icon="Back" @click="navigateToHome"></el-button>
      </div>
    <div class="sidebar">
      <div class="sidebar-header">
        <h2 class="sidebar-title">設定</h2>
      </div>
      <div class="sidebar-link-area">  
        <el-menu
          :default-active="activeMenu"
          class="el-menu"
          @select="handleMenuSelect"
        >
          <el-menu-item index="user">ユーザー管理</el-menu-item>
          <el-menu-item index="group">グループ管理</el-menu-item>
          <el-menu-item index="timeout">タイムアウト設定</el-menu-item>
          <!-- <el-menu-item index="model">モデル管理</el-menu-item>
          <el-menu-item index="other">その他</el-menu-item> -->
        </el-menu>
      </div>
    </div>
    
    <!-- メインコンテンツ部分 -->
    <main class="main-content">
      <!-- サブページのコンテンツを切り替えて表示（トランジション効果なし） -->
      <component :is="currentComponent" @navigate-to-group="handleNavigateToGroup" />
    </main>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import UserManagement from './sub_pages/user_management.vue';
import GroupManagement from './sub_pages/group_management.vue';
import ModelManagement from './sub_pages/model_management.vue';
import Other from './sub_pages/other.vue';
import TimeoutSettings from './TimeoutSettings.vue';

const router = useRouter();
const route = useRoute();

// 現在のアクティブなメニュー
const activeMenu = ref('user');

// コンポーネントマッピング
const components = {
  user: UserManagement,
  group: GroupManagement,
  model: ModelManagement,
  other: Other,
  timeout: TimeoutSettings
};

// 現在表示するコンポーネント
const currentComponent = computed(() => components[activeMenu.value]);

// メニュー選択時の処理
function handleMenuSelect(index) {
  activeMenu.value = index;
  // URLは変更せずに内部状態のみ変更
}

// グループ管理への遷移処理
function handleNavigateToGroup() {
  activeMenu.value = 'group';
}

function navigateToHome() {
  router.push('/home');
}

// 初期表示時にURLのパラメータがあれば設定
onMounted(() => {
  const subpage = route.query.page;
  if (subpage && components[subpage]) {
    activeMenu.value = subpage;
  }
});
</script>

<style lang="scss" scoped>
@import '@/assets/styles/variables.module.scss';

::v-deep(.el-switch.is-checked .el-switch__core) {
  background-color: $dark-blue-bg !important;
  border-color: $dark-blue-bg !important;
}

.settings-container {
  display: flex;
  height: 100vh;
}

.home-button {
  position: fixed;
  top: 20px;
  left: 35px;
  z-index: 1000;
}

h2.sidebar-title {
  color: #001e60;
  font-size: 2rem;
  margin-top: 0;
  font-weight: 600;
}

.sidebar-header {
  display: flex;
  justify-content: center;
  padding-top: 10px;
  font-size: 1.5rem;
}

.sidebar {
  background-color: rgba(249, 249, 249, 0.9);
  backdrop-filter: blur(5px);
  border-right: 1px solid rgba(0, 0, 0, 0.05);
  height: 92.5%;
  max-width: 20%;
  min-width: 250px;
  overflow-x: hidden;
  box-sizing: border-box;
  padding: 20px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  border-radius: 0 12px 12px 0;
  position: fixed;
  left: 0;
  bottom: 0;
  z-index: 100;
  transition: all 0.3s ease;
}

.sidebar-link-area {
  font-size: 24px;
  padding-top: 0px;
  padding: 20px;
}

.el-menu {
  border-right: none !important;
  box-shadow: none !important;
  background: transparent;
}

/* メニューアイテムの基本スタイル */
.el-menu-item {
  color: #333333 !important;
  font-size: 16px !important;
  background-color: rgba(255, 255, 255, 0.5) !important;
  border-radius: 8px !important;
  margin-bottom: 8px !important;
  transition: all 0.3s ease !important;
  padding: 12px 15px !important;
  cursor: pointer !important;
}

/* メニューアイテムのホバー状態 */
.el-menu-item:hover {
  background-color: rgba(255, 255, 255, 0.8) !important;
  color: #001e60 !important;
}

/* アクティブなメニューアイテム */
.el-menu-item.is-active {
  background-color: #3157aa !important;
  color: white !important;
  font-weight: bold !important;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1) !important;
}

.main-content {
  flex: 1;
  padding: 2rem;
  background: #fefefc;
  padding-top: 40px;
  min-width: 0;
  overflow-x: auto;
  margin-left: 20%;
  width: 80%;
}

/* 響應式設計 */
@media (max-width: 992px) {
  .sidebar {
    max-width: 280px;
    min-width: 250px;
  }
  
  .main-content {
    margin-left: 280px;
    width: calc(100% - 280px);
  }
}

@media (max-width: 768px) {
  .sidebar {
    width: 100%;
    max-width: 100%;
    min-width: auto;
    position: relative;
    height: auto;
  }
  
  .main-content {
    margin-left: 0;
    width: 100%;
    padding: 1rem;
  }
  
  .settings-container {
    flex-direction: column;
  }
}
</style>  