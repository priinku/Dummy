<template>
  <div class="timeout-settings">
    <el-card class="settings-card">
      <template #header>
        <div class="card-header">
          <h3>セッションタイムアウト設定</h3>
          <p class="description">自動ログアウトの時間と警告オプションを設定</p>
        </div>
      </template>

      <el-form :model="form" label-width="200px" class="settings-form">
        <!-- Enable/Disable timeout / タイムアウト有効/無効 -->
        <el-form-item label="自動ログアウトを有効にする">
          <el-switch
            v-model="form.enabled"
            active-text="有効"
            inactive-text="無効"
            @change="handleEnabledChange"
          />
        </el-form-item>

        <!-- Timeout duration setting / タイムアウト時間設定 -->
        <el-form-item label="タイムアウト時間" v-if="form.enabled">
          <el-select v-model="form.timeoutMinutes" placeholder="タイムアウト時間を選択">
            <el-option
              v-for="option in timeoutOptions"
              :key="option.value"
              :label="option.label"
              :value="option.value"
            />
          </el-select>
        </el-form-item>

        <!-- Warning time setting / 警告時間設定 -->
        <el-form-item label="警告時間" v-if="form.enabled">
          <el-select v-model="form.warningMinutes" placeholder="警告時間を選択">
            <el-option
              v-for="option in warningOptions"
              :key="option.value"
              :label="option.label"
              :value="option.value"
            />
          </el-select>
        </el-form-item>

        <!-- Whether to allow session extension / セッション延長を許可するか -->
        <el-form-item label="セッション延長を許可" v-if="form.enabled">
          <el-switch
            v-model="form.allowExtend"
            active-text="許可"
            inactive-text="不許可"
          />
        </el-form-item>

        <!-- Extended session time / 延長セッション時間 -->
        <el-form-item label="延長セッション時間" v-if="form.enabled && form.allowExtend">
          <el-select v-model="form.extendMinutes" placeholder="延長時間を選択">
            <el-option
              v-for="option in timeoutOptions"
              :key="option.value"
              :label="option.label"
              :value="option.value"
            />
          </el-select>
        </el-form-item>

        <!-- Page visibility setting / ページ可視性設定 -->
        <el-form-item label="ページが可視の時のみカウント" v-if="form.enabled">
          <el-switch
            v-model="form.onlyWhenVisible"
            active-text="はい"
            inactive-text="いいえ"
          />
          <div class="form-tip">
            有効にすると、ページが不可視の時（他のタブに切り替えた時など）はカウントを一時停止します
          </div>
        </el-form-item>

        <!-- Development environment setting / 開発環境設定 -->
        <el-form-item label="開発環境で有効にする" v-if="form.enabled">
          <el-switch
            v-model="form.enableInDevelopment"
            active-text="有効"
            inactive-text="無効"
          />
          <div class="form-tip">
            開発環境でタイムアウト機能を有効にするかどうか
          </div>
        </el-form-item>

        <!-- Current status display / 現在の状態表示 -->
        <el-form-item label="現在の状態" v-if="form.enabled">
          <div class="status-display">
            <el-tag :type="isTimeoutActive ? 'success' : 'info'">
              {{ isTimeoutActive ? '有効' : '無効' }}
            </el-tag>
            <span v-if="isTimeoutActive" class="remaining-time">
              残り時間: {{ remainingTimeDisplay }}
            </span>
          </div>
        </el-form-item>

         <!-- Action buttons / 操作ボタン -->
         <el-form-item class="bts-flex">
           <el-button type="primary" @click="saveSettings" :loading="saving">
             設定を保存
           </el-button>
           <el-button @click="resetSettings">
             デフォルト値にリセット
           </el-button>
           <el-button type="success" @click="testTimeout" v-if="form.enabled">
             タイムアウトテスト (30秒)
           </el-button>
           <el-button type="warning" @click="quickTest" v-if="form.enabled">
             クイックテスト (10秒)
           </el-button>
         </el-form-item>
      </el-form>
    </el-card>

    <!-- Information card / 説明カード -->
    <el-card class="info-card">
      <template #header>
        <h4>機能説明</h4>
      </template>
      <div class="info-content">
        <ul>
          <li><strong>タイムアウト時間：</strong>ユーザーが無活動後に自動ログアウトする時間</li>
          <li><strong>警告時間：</strong>タイムアウト前にどのくらいの時間で警告ダイアログを表示するか</li>
          <li><strong>セッション延長：</strong>ユーザーが警告時にセッション時間を延長できるかどうか</li>
          <li><strong>ページ可視性：</strong>タブを切り替えた時にカウントを一時停止するかどうか</li>
          <li><strong>開発環境：</strong>開発モードでタイムアウト機能を有効にするかどうか</li>
        </ul>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onUnmounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { 
  getConfig, 
  updateConfig, 
  resetConfig, 
  timeoutOptions, 
  warningOptions 
} from '@/utils/timeoutConfig'
import timeoutService from '@/utils/timeoutService'

// Reactive data / リアクティブデータ
const form = reactive({
  enabled: true,
  timeoutMinutes: 15, // 15 minute / 15分
  warningMinutes: 2, // 2 minutes before warning / 2分前警告
  allowExtend: true,
  extendMinutes: 15, // 15 minute extension / 15分延長
  onlyWhenVisible: true,
  enableInDevelopment: true // Enable in development environment / 開発環境で有効
})

const saving = ref(false)
const isTimeoutActive = ref(false)
const remainingTime = ref(0)

// Computed properties / 計算プロパティ
const remainingTimeDisplay = computed(() => {
  if (remainingTime.value <= 0) return 'タイムアウト'
  const minutes = Math.floor(remainingTime.value / 60000)
  const seconds = Math.floor((remainingTime.value % 60000) / 1000)
  return `${minutes}:${seconds.toString().padStart(2, '0')}`
})

// Methods / メソッド
const loadSettings = () => {
  const config = getConfig()
  Object.assign(form, config)
}

const saveSettings = async () => {
  saving.value = true
  try {
    updateConfig(form)
    ElMessage.success('設定が保存されました')
    
    // Restart timeout service / タイムアウトサービスを再起動
    timeoutService.stop()
    timeoutService.start()
    
    updateTimeoutStatus()
  } catch (error) {
    ElMessage.error('設定の保存に失敗しました')
  } finally {
    saving.value = false
  }
}

const resetSettings = async () => {
  try {
    await ElMessageBox.confirm(
      'すべての設定をデフォルト値にリセットしますか？',
      '設定リセット',
      {
        confirmButtonText: '確定',
        cancelButtonText: 'キャンセル',
        type: 'warning'
      }
    )
    
    const defaultConfig = resetConfig()
    Object.assign(form, defaultConfig)
    ElMessage.success('設定がリセットされました')
  } catch (error) {
    // User cancelled / ユーザーがキャンセル
  }
}

const testTimeout = async () => {
  try {
    await ElMessageBox.confirm(
      'タイムアウト機能をテストしますか？30秒タイムアウトでテストします。',
      'タイムアウトテスト',
      {
        confirmButtonText: '確定',
        cancelButtonText: 'キャンセル',
        type: 'warning'
      }
    )
    
    // Set test timeout / テストタイムアウトを設定
    timeoutService.stop()
    timeoutService.setTimeoutDuration(0.5) // 30 seconds / 30秒
    timeoutService.start()
    
    ElMessage.info('テストが開始されました。30秒後にタイムアウトが発生します')
  } catch (error) {
    // User cancelled / ユーザーがキャンセル
  }
}

const quickTest = async () => {
  try {
    await ElMessageBox.confirm(
      'クイックテストを実行しますか？10秒タイムアウトでテストします。',
      'クイックテスト',
      {
        confirmButtonText: '確定',
        cancelButtonText: 'キャンセル',
        type: 'warning'
      }
    )
    
    // Set quick test timeout / クイックテストタイムアウトを設定
    timeoutService.stop()
    timeoutService.setTimeoutDuration(0.17) // 10 seconds / 10秒
    timeoutService.start()
    
    ElMessage.info('クイックテストが開始されました。10秒後にタイムアウトが発生します')
  } catch (error) {
    // User cancelled / ユーザーがキャンセル
  }
}

const updateTimeoutStatus = () => {
  isTimeoutActive.value = timeoutService.isActive
  if (isTimeoutActive.value) {
    remainingTime.value = timeoutService.getRemainingTime()
  } else {
    remainingTime.value = 0
  }
}

// Lifecycle / ライフサイクル
onMounted(() => {
  loadSettings()
  updateTimeoutStatus()
  
  // Periodically update status / 定期的に状態を更新
  const statusInterval = setInterval(updateTimeoutStatus, 1000)
  
  onUnmounted(() => {
    clearInterval(statusInterval)
  })
})
</script>

<style lang="scss" scoped>
.timeout-settings {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.settings-card {
  margin-bottom: 20px;
  
  .card-header {
    h3 {
      margin: 0 0 8px 0;
      color: #303133;
    }
    
    .description {
      margin: 0;
      color: #606266;
      font-size: 14px;
    }
  }
}

.settings-form {
  .el-form-item {
    margin-bottom: 24px;
    
    .form-tip {
      font-size: 12px;
      color: #909399;
      margin-top: 4px;
    }
  }
}

.status-display {
  display: flex;
  align-items: center;
  gap: 12px;
  
  .remaining-time {
    font-family: 'Courier New', monospace;
    color: #606266;
  }
}

.info-card {
  .info-content {
    ul {
      margin: 0;
      padding-left: 20px;
      
      li {
        margin-bottom: 8px;
        line-height: 1.5;
        
        strong {
          color: #303133;
        }
      }
    }
  }
}

.bts-flex > ::v-deep(.el-form-item__content) {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 8px;
}

@media (max-width: 768px) {
  .timeout-settings {
    padding: 10px;
  }
  
  .settings-form {
    .el-form-item {
      :deep(.el-form-item__label) {
        width: 100% !important;
        text-align: left;
        margin-bottom: 8px;
      }
    }
  }
}
</style>

