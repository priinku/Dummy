<script setup lang="ts">
import useUserStore from "@/store/modules/user";
import { onMounted } from "vue";

const userStore = useUserStore();
const route = useRoute();
const router = useRouter();

onMounted(async () => {
  const urlParams = new URLSearchParams(window.location.search);
  const authCode = urlParams.get("auth_code");

  if (authCode) {
    userStore
      .exchange(authCode)
      .then(() => {
        console.log("SSO Login successful");
        const query = route.query;
        const otherQueryParams = Object.keys(query).reduce((acc, cur) => {
          if (cur !== "redirect") {
            acc[cur] = query[cur];
          }
          return acc;
        }, {});

        console.log("Redirecting to home...");
        router.push({
          path: "/home",
          query: otherQueryParams,
        });

        console.log("SSO login successful, redirected to home.");
      })
      .catch(() => {
        //loading.value = false;
      });
  }
});
</script>
