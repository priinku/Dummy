import { getInfo, login, logout,exchange } from "@/api/login";
import defAva from "@/assets/icon_default.png";
import { getToken, removeToken, setToken,setSsoToken } from "@/utils/auth";
import timeoutService from "@/utils/timeoutService";
import { removeSsoToken } from "../../utils/auth";

const useUserStore = defineStore("user", {
  state: () => ({
    token: getToken(),
    id: "",
    name: "",
    nickName: "",
    deptId: "",
    avatar: "",
    roles: [],
    permissions: [],
  }),
  actions: {
    exchange(authCode){
      return new Promise((resolve, reject) => {
        exchange(authCode)
          .then((res) => {
            setSsoToken(res.result.token);
            this.token = res.result.token;
            // Start timeout service after successful login / ログイン成功後にタイムアウトサービスを開始
            timeoutService.start();
            resolve();
          })
          .catch((error) => {
            reject(error);
          });
      });
    },
    login(userInfo) {
      const username = userInfo.username.trim();
      const password = userInfo.password;
      const code = userInfo.code;
      const uuid = userInfo.uuid;
      return new Promise((resolve, reject) => {
        login(username, password, code, uuid)
          .then((res) => {
            setToken(res.result.token);
            this.token = res.result.token;
            // Start timeout service after successful login / ログイン成功後にタイムアウトサービスを開始
            timeoutService.start();
            resolve();
          })
          .catch((error) => {
            reject(error);
          });
      });
    },
    getInfo() {
      return new Promise((resolve, reject) => {
        getInfo()
          .then((res) => {
            const user = res.result.userInfo;
            downloadAvatar(user.avatar).then((avatar) => {
              if (res.result.roles && res.result.roles.length > 0) {
                this.roles = res.result.roles;
                this.permissions = res.result.permissions;
              } else {
                this.roles = ["ROLE_DEFAULT"];
              }
              this.id = user.userId;
              this.name = user.userName;
              this.nickName = user.nickName;
              this.avatar = avatar;
              this.deptId = user.deptId;
              resolve(res.result);
            })
          })
          .catch((error) => {
            console.log("error, ", error);
            reject(error);
          });
      });
    },
    logOut() {
      return new Promise((resolve, reject) => {
        logout(this.token)
          .then(() => {
            this.token = "";
            this.roles = [];
            this.permissions = [];
            removeToken();
            removeSsoToken();
            // Stop timeout service on logout / ログアウト時にタイムアウトサービスを停止
            timeoutService.stop();
            resolve();
          })
          .catch((error) => {
            reject(error);
          });
      });
    },
  },
});

async function downloadAvatar(filename) {
  if (filename == "" || filename == null) {
    return defAva;
  } else {
    return defAva;
    // const response = await downloadByFilename({ filename });
    // const result = 'data:image/png;base64,' + response.result;
    // return result;
  }
}

export default useUserStore;
