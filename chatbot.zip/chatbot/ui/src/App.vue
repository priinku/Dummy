<template>
  <router-view :key="$route.fullPath" />
  <!-- Timeout Warning Dialog -->
  <TimeoutWarning />
</template>

<script setup>
import { onMounted, nextTick } from 'vue'
import { handleThemeStyle } from "@/utils/theme"
import TimeoutWarning from '@/components/TimeoutWarning/index.vue'

onMounted(() => {
  nextTick(() => {
    handleThemeStyle("#212121");
  });
})
</script>
