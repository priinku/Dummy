<template>
  <el-dialog
    v-model="visible"
    :title="dialogTitle"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    :show-close="false"
    width="400px"
    center
  >
    <div class="timeout-warning-content">
      <div class="warning-icon">
        <i :class="iconClass" :style="{ color: iconColor }"></i>
      </div>
      
    <div class="warning-message">
      <h3>{{ warningMessage }}</h3>
      <p v-if="remainingTime > 0" class="countdown">
        残り時間: <span class="time-display">{{ formattedTime }}</span>
      </p>
      <p class="description">{{ description }}</p>
    </div>
    </div>

    <template #footer>
      <div class="dialog-footer">
        <el-button 
          type="primary" 
          @click="extendSession"
          :loading="extending"
        >
          セッション延長
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { ElMessage } from 'element-plus'
import useUserStore from '@/store/modules/user'

const userStore = useUserStore()

// Responsive Data / レスポンシブデータ
const visible = ref(false)
const remainingTime = ref(0)
const extending = ref(false)

// timer / タイマー
let countdownTimer = null

// Computed Properties / 計算プロパティ
const dialogTitle = computed(() => {
  return 'セッションタイムアウト間近'
})

const iconClass = computed(() => {
  return 'fas fa-exclamation-triangle'
})

const iconColor = computed(() => {
  return '#E6A23C'
})

const warningMessage = computed(() => {
  const minutes = Math.floor(remainingTime.value / 60000)
  if (minutes > 0) {
    return `セッションが${minutes}分後にタイムアウトします`
  } else {
    return 'セッションがまもなくタイムアウトします'
  }
})

const description = computed(() => {
  return 'システムを継続して使用する場合は、「セッション延長」ボタンをクリックしてください。時間切れになると自動的にログアウトします。'
})

const formattedTime = computed(() => {
  const minutes = Math.floor(remainingTime.value / 60000)
  const seconds = Math.floor((remainingTime.value % 60000) / 1000)
  return `${minutes}:${seconds.toString().padStart(2, '0')}`
})

// Method / メソッド
const startCountdown = () => {
  if (countdownTimer) {
    clearInterval(countdownTimer)
  }
  
  countdownTimer = setInterval(() => {
    remainingTime.value -= 1000
    if (remainingTime.value <= 0) {
      remainingTime.value = 0
      clearInterval(countdownTimer)
    }
  }, 1000)
}

const stopCountdown = () => {
  if (countdownTimer) {
    clearInterval(countdownTimer)
    countdownTimer = null
  }
}

const extendSession = async () => {
  extending.value = true
  try {
    // Trigger extend session event / セッション延長イベントをトリガー
    window.dispatchEvent(new CustomEvent('extend-session'))
    
    ElMessage.success('セッションが30分延長されました')
    visible.value = false
    stopCountdown()
  } catch (error) {
    ElMessage.error('セッション延長に失敗しました')
  } finally {
    extending.value = false
  }
}


const showWarning = (detail) => {
  remainingTime.value = detail.remainingTime || 60000 // 預設 60 秒
  visible.value = true
  
  if (remainingTime.value > 0) {
    startCountdown()
  }
}

// Lifecycle / ライフサイクル
onMounted(() => {
  
  // Listen for timeout warning event / タイムアウト警告イベントを監視
  window.addEventListener('timeout-warning', (event) => {
    showWarning(event.detail)
  })
  
  // Listen for timeout logout event / タイムアウトログアウトイベントを監視
  window.addEventListener('timeout-logout', () => {
    // Auto logout without showing dialog / ダイアログを表示せずに自動ログアウト
    userStore.logOut().then(() => {
      window.location.href = '/login'
    })
  })
  
})

onUnmounted(() => {
  stopCountdown()
  window.removeEventListener('timeout-warning', showWarning)
  window.removeEventListener('timeout-logout', () => {})
  window.removeEventListener('extend-session', () => {})
})
</script>

<style lang="scss" scoped>
.timeout-warning-content {
  text-align: center;
  padding: 20px 0;
  
  .warning-icon {
    font-size: 48px;
    margin-bottom: 20px;
    
    i {
      animation: pulse 2s infinite;
    }
  }
  
  .warning-message {
    h3 {
      margin: 0 0 15px 0;
      color: #303133;
      font-size: 18px;
    }
    
    .countdown {
      margin: 10px 0;
      font-size: 16px;
      
      .time-display {
        font-weight: bold;
        color: #F56C6C;
        font-family: 'Courier New', monospace;
        font-size: 18px;
      }
    }
    
    .description {
      margin: 15px 0 0 0;
      color: #606266;
      font-size: 14px;
      line-height: 1.5;
    }
  }
}

.dialog-footer {
  text-align: center;
  
  .el-button {
    margin: 0 10px;
    min-width: 100px;
  }
}

@keyframes pulse {
  0% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.1);
  }
  100% {
    transform: scale(1);
  }
}

// 最終警告時的緊急樣式
.timeout-warning-content.final-warning {
  .warning-icon i {
    animation: urgent-pulse 1s infinite;
  }
  
  .time-display {
    color: #F56C6C !important;
    animation: blink 1s infinite;
  }
}

@keyframes urgent-pulse {
  0% {
    transform: scale(1);
    color: #F56C6C;
  }
  50% {
    transform: scale(1.2);
    color: #ff0000;
  }
  100% {
    transform: scale(1);
    color: #F56C6C;
  }
}

@keyframes blink {
  0%, 50% {
    opacity: 1;
  }
  51%, 100% {
    opacity: 0.3;
  }
}
</style>

