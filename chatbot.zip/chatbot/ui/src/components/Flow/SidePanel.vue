<template>
  <div class="side-panel" v-if="selectedNode">
    <h3>節點屬性</h3>
    <label>名稱：</label>
    <input v-model="selectedNode.title" />

    <label>位置：</label>
    <p>X: {{ selectedNode.x }} / Y: {{ selectedNode.y }}</p>

    <button @click="deleteNode">刪除節點</button>
  </div>
</template>

<script setup>
const props = defineProps({
  selectedNode: Object,
});
const emit = defineEmits(['delete-node']);

const deleteNode = () => {
  emit('delete-node', props.selectedNode?.id);
};
</script>

<style scoped>
.side-panel {
  position: fixed;
  right: 0;
  top: 0;
  width: 240px;
  height: 100vh;
  padding: 20px;
  background: #fafafa;
  border-left: 1px solid #ccc;
}
input {
  width: 100%;
  margin-bottom: 10px;
}
button {
  background: #f44336;
  color: white;
  border: none;
  padding: 6px 12px;
  border-radius: 4px;
}
</style>
