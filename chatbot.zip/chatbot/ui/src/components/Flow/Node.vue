<template>
  <div
    class="node"
    :style="{
      left: `${x}px`,
      top: `${y}px`
    }"
    @mousedown="startDrag"
    ref="nodeEl"
  >
    <div class="node-title">{{ title }}</div>
    <Port type="in" />
    <Port type="out" />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import Port from './Port.vue'

const props = defineProps({
  id: String,
  x: Number,
  y: Number,
  title: String
})
const emit = defineEmits(['update:position'])

const nodeEl = ref(null)
const isDragging = ref(false)
let offsetX = 0
let offsetY = 0

function startDrag(e) {
  isDragging.value = true
  offsetX = e.clientX - props.x
  offsetY = e.clientY - props.y
  document.addEventListener('mousemove', onDrag)
  document.addEventListener('mouseup', stopDrag)
}

function onDrag(e) {
  if (!isDragging.value) return
  const newX = e.clientX - offsetX
  const newY = e.clientY - offsetY
  emit('update:position', props.id, newX, newY)
}

function stopDrag() {
  isDragging.value = false
  document.removeEventListener('mousemove', onDrag)
  document.removeEventListener('mouseup', stopDrag)
}
</script>

<style scoped>
.node {
  position: absolute;
  background-color: white;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
  cursor: move;
  user-select: none;
  min-width: 120px;
  text-align: center;
}

.node-title {
  font-weight: bold;
  color: #333;
}
</style>

