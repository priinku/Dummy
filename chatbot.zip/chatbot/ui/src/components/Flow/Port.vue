<template>
  <div
    class="port"
    :class="typeClass"
    @mousedown.stop="startConnection"
  ></div>
</template>

<script setup>
const props = defineProps({
  type: { type: String, default: 'out' }, // 'in' or 'out'
});

const emit = defineEmits(['start-connection']);

const startConnection = () => {
  emit('start-connection', props.type);
};

const typeClass = computed(() => ({
  'port-in': props.type === 'in',
  'port-out': props.type === 'out',
}));
</script>

<style scoped>
.port {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: #6c6c6c;
  cursor: pointer;
}
.port-in {
  background: #4caf50;
}
.port-out {
  background: #2196f3;
}
</style>
