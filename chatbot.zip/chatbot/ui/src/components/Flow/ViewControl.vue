<template>
  <div class="view-control">
    <el-button-group>
      <!-- 全螢幕按鈕 -->
      <el-button :icon="isFullscreen ? 'ArrowsMinimize' : 'ArrowsMaximize'" @click="toggle" :title="isFullscreen ? '退出全螢幕' : '全螢幕'">
      </el-button>
      
      <!-- 縮放控制 -->
      <el-button icon="ZoomOut" @click="decreaseZoom" title="縮小">
      </el-button>
      <el-button>{{ Math.round(zoom * 100) }}%</el-button>
      <el-button icon="ZoomIn" @click="increaseZoom" title="放大">
      </el-button>
      
      <!-- 重置縮放 -->
      <el-button icon="RefreshRight" @click="resetZoom" title="重置大小">
      </el-button>
    </el-button-group>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useFullscreen } from '@vueuse/core'

const { isFullscreen, toggle } = useFullscreen()

// 縮放控制
const zoom = ref(1)
const zoomStep = 0.1
const maxZoom = 3
const minZoom = 0.5

const increaseZoom = () => {
  if (zoom.value < maxZoom) {
    zoom.value += zoomStep
    applyZoom()
  }
}

const decreaseZoom = () => {
  if (zoom.value > minZoom) {
    zoom.value -= zoomStep
    applyZoom()
  }
}

const resetZoom = () => {
  zoom.value = 1
  applyZoom()
}

const applyZoom = () => {
  const content = document.querySelector('.app-main') // 根據您的主要內容區域的類名調整
  if (content) {
    content.style.transform = `scale(${zoom.value})`
    content.style.transformOrigin = 'center top'
  }
}
</script>

<style lang="scss" scoped>
.view-control {
  position: fixed;
  right: 20px;
  top: 80px;
  z-index: 1000;
  background: white;
  padding: 8px;
  border-radius: 4px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

:deep(.el-button-group) {
  .el-button {
    padding: 5px 12px;
  }
}
</style>