<template>
  <svg class="connection-line">
    <path
      :d="getPathData(source.x, source.y, target.x, target.y)"
      fill="none"
      stroke="#6c6c6c"
      stroke-width="2"
    />
  </svg>
</template>

<script setup>
const props = defineProps({
  source: { type: Object, required: true }, // e.g., { x: 100, y: 200 }
  target: { type: Object, required: true },
});

const getPathData = (sx, sy, tx, ty) => {
  const dx = Math.abs(tx - sx) / 2;
  return `M${sx},${sy} C${sx + dx},${sy} ${tx - dx},${ty} ${tx},${ty}`;
};
</script>

<style scoped>
.connection-line {
  position: absolute;
  width: 100%;
  height: 100%;
  pointer-events: none;
  overflow: visible;
}
</style>
