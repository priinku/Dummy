// FlowCanvas.vue
<template>
  <div class="flow-canvas" @mousemove="onMouseMove" @mouseup="onMouseUp">
    <Node
      v-for="node in nodes"
      :key="node.id"
      :id="node.id"
      :x="node.x"
      :y="node.y"
      :title="node.title"
      @update:position="updateNodePosition"
    />
    <Connection
      v-for="conn in connections"
      :key="conn.id"
      :source="getNodeById(conn.sourceId)"
      :target="getNodeById(conn.targetId)"
    />
    <SidePanel :nodes="nodes" />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import Node from './Node.vue'
import Connection from './Connection.vue'
import SidePanel from './SidePanel.vue'

const nodes = ref([
  { id: 'node-1', x: 100, y: 100, title: '開始節點' },
  { id: 'node-2', x: 300, y: 200, title: '處理節點' }
])

const connections = ref([
  { id: 'conn-1', sourceId: 'node-1', targetId: 'node-2' }
])

function updateNodePosition(id, newX, newY) {
  const node = nodes.value.find(n => n.id === id)
  if (node) {
    node.x = newX
    node.y = newY
  }
}

function getNodeById(id) {
  return nodes.value.find(n => n.id === id)
}

function onMouseMove(e) {}
function onMouseUp(e) {}
</script>

<style scoped>
.flow-canvas {
  width: 100%;
  height: 100vh;
  background-color: #f0f0f0;
  position: relative;
  overflow: hidden;
}
</style>