import useSettingsStore from "@/store/modules/settings";
import useUserStore from "@/store/modules/user";
import { getToken } from "@/utils/auth";
import { isReLogin } from "@/utils/request";
import { ElMessage } from "element-plus";
import NProgress from "nprogress";
import "nprogress/nprogress.css";
import router from "./router";

NProgress.configure({ showSpinner: false });

const whiteList = ["/login", "/ssoLoginSuccess"];

function hasPermission(userRoles, route) {
  if (!route.meta || !route.meta.roles) {
    return true;
  }

  return route.meta.roles.some((role) => userRoles.includes(role));
}

router.beforeEach((to, from, next) => {
  NProgress.start();
  if (getToken()) {
    to.meta.title && useSettingsStore().setTitle(to.meta.title);
    if (to.path === "/login") {
      next({ path: "/" });
      NProgress.done();
    } else if (whiteList.indexOf(to.path) !== -1) {
      next();
    } else {
      if (useUserStore().roles.length === 0) {
        isReLogin.show = true;
        useUserStore()
          .getInfo()
          .then((res) => {
            isReLogin.show = false;
            if (res.roles.length === 1 && res.roles[0] === "sso") {
              next({ path: "/chat" });
              NProgress.done();
              return;
            }

            if (hasPermission(useUserStore().roles, to)) {
              next({ ...to, replace: true });
            } else {
              next({ path: "/403" });
            }
          })
          .catch((err) => {
            console.error("ユーザー情報の取得に失敗しました:", err);
            console.error("錯誤エラーの詳細詳情:", {
              message: err?.message || err,
              response: err?.response,
              url: window.location.href,
            });
            isReLogin.show = false;
            useUserStore()
              .logOut()
              .then(() => {
                ElMessage.error(err?.message || "認証に失敗しました。再度ログインしてください。");
                if (to.path !== "/login") {
                  next({ path: `/login?redirect=${to.fullPath}` });
                } else {
                  next();
                }
                NProgress.done();
              })
              .catch((logoutErr) => {
                console.error("ログアウトに失敗しました:", logoutErr);
                next({ path: "/login" });
                NProgress.done();
              });
          });
      } else {
        if (hasPermission(useUserStore().roles, to)) {
          next();
        } else {
          next({ path: "/403" });
        }
      }
    }
  } else {
    if (whiteList.indexOf(to.path) !== -1) {
      next();
    } else {
      next(`/login?redirect=${to.fullPath}`);
      NProgress.done();
    }
  }
});

router.afterEach(() => {
  NProgress.done();
});
