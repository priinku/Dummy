import request from "@/utils/request";

export function listTask(query) {
  return request({
    url: "/api/gen-task/list",
    method: "get",
    params: query,
  });
}

export function listTaskOutput(query) {
  return request({
    url: "/api/gen-task-output/list",
    method: "get",
    params: query,
  });
}

export function updateTaskOutput(query) {
  const { taskOutputId, data } = query;
  return request({
    url: `/api/gen-task-output/${taskOutputId}`,
    method: "put",
    data: data,
  });
}

export function reNameTaskOutput(query) {
  const { taskId, data } = query;
  return request({
    url: `/api/gen-task-output/rename/${taskId}`,
    method: "put",
    data: data,
  });
}

export function deleteTaskOutput(query) {
  const { taskId } = query;
  console.log("deleteTaskOutput:", taskId);
  return request({
    url: `/api/gen-task-output/del/${taskId}`,
    method: "delete",
  });
}

export function stopTaskOutput(taskId, fieldSort ) {
  const a = request({
    url: `/api/gen-task-output/stop/${fieldSort}`,
    method: "put",
    params: {
      taskId: taskId,
      fieldSort: fieldSort
    }
  });
  return a;
}

export function getChatTitle(query) {
  return request({
    url: `/api/gen-task/getChatTitle`,
    method: "get",
    params: query,
  });
}

export function addTask(data) {
  return request({
    url: "/api/gen-task",
    method: "post",
    data: data,
  });
}

export function sendFeedbackToCache(data) {
  return request({
    url: "/api/gen-task/feedback",
    method: "post",
    data: data,
  });
}
