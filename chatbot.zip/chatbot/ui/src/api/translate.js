import request from "@/utils/request";

/**
 * 日英雙向翻譯 API
 * @param {Object} data - 翻譯請求數據
 * @param {string} data.sourceText - 源文本
 * @param {string} data.sourceLang - 源語言 ('ja' 或 'en')
 * @param {string} data.targetLang - 目標語言 ('ja' 或 'en')
 * @returns {Promise} 翻譯結果
 */
export function translateText(data) {
  return request({
    url: "/api/translate",
    method: "post",
    data: data,
  });
}

/**
 * 批量翻譯 API（可選）
 * @param {Object} data - 批量翻譯請求數據
 * @param {Array} data.texts - 文本數組
 * @param {string} data.sourceLang - 源語言
 * @param {string} data.targetLang - 目標語言
 * @returns {Promise} 批量翻譯結果
 */
export function batchTranslate(data) {
  return request({
    url: "/api/translate/batch",
    method: "post",
    data: data,
  });
}

/**
 * 獲取支援的語言列表（可選）
 * @returns {Promise} 支援的語言列表
 */
export function getSupportedLanguages() {
  return request({
    url: "/api/translate/languages",
    method: "get",
  });
}

/**
 * 獲取翻譯歷史（可選）
 * @param {Object} params - 查詢參數
 * @param {number} params.page - 頁碼
 * @param {number} params.size - 每頁大小
 * @returns {Promise} 翻譯歷史
 */
export function getTranslationHistory(params) {
  return request({
    url: "/api/translate/history",
    method: "get",
    params: params,
  });
}

