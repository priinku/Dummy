import request from "@/utils/request";

export function saveFlow(data) {
    return request({
        url: "/api/flows",
        method: "post",
        data: data,
    });
}

export function listFlow(query) {
    return request({
        url: "/api/flows",
        method: "get",
        params: query,
    });
}

export function queryFlow(query) {
    const { flowId } = query;
    return request({
        url: `/api/flows/${flowId}`,
        method: "get",
        params: query,
    });
}

export function deleteFlow(query) {
    const { flowId } = query;
    return request({
        url: `/api/flows/${flowId}`,
        method: "delete",
    });
}

export function executeFlow(data) {
    return request({
        url: "/api/flows/execute",
        method: "post",
        data: data,
    });
}