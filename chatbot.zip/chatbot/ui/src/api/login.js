import request from "@/utils/request";

export function login(userName, password, code, uuid) {
  const data = {
    userName,
    password,
    code,
    uuid,
  };
  return request({
    url: "/user/login",
    headers: {
      isToken: false,
      repeatSubmit: false,
    },
    method: "post",
    data: data,
  });
}

export function getInfo() {
  return request({
    url: "/user/getInfo",
    method: "get",
  });
}

export function logout() {
  return request({
    url: "/user/logout",
    method: "delete",
  });
}

export function exchange(auth_code) {
  return request({
    url: `/user/auth/exchange?auth_code=${auth_code}`,
    method: "get",
  });
}
