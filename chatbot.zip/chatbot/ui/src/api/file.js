import request from "@/utils/request";

export function listFile(query) {
  return request({
    url: "/api/files",
    method: "get",
    params: query,
  });
}

export function uploadFile(data,timeout = 10000) {
  return request({
    url: `/api/files/upload`,
    method: "post",
    data:data,
    headers: {
      "Content-Type": "multipart/form-data",
    },
    timeout: timeout,
  });
}

export function deleteFile(ids) {
  return request({
    url: `/api/files/delete`, 
    method: "delete",
    data: {
      ids: ids, 
    },
  });
}

export function updateFileInfo(data) {
  return request({
    url: `/api/files`,
    method: "put",
    data: data,
  });
}

export function addNewTag(data) {
  return request({
    url: `/api/files/addNewTag`,
    method: "post",
    data,
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });
}

export function editTag(data) {
  return request({
    url: `/api/files/editTag`,
    method: "put",
    data: data,
  });
}

export async function getRoles(data) {
  if (data.fileIds) {
    return request({
    url: `/roles/?fileIds=${data.fileIds}`,
    method: "get",
  });
  } else if (data.userIds) {
    return request({
      url: `/roles/?userIds=${data.userIds}`,
      method: "get",
    });
  } else {
    return request({
      url: `/roles/`,
      method: "get",
      pageNum: 1,
      pageSize: 1000,
    });
  }
}

export async function getRolesFile() {
  return request({
    url: `/roles/file/bind`,
    method: "post",
    // data: data
  });
}

export async function getRolesUserBind() {
  return request({
    url: `/roles/user/bind`,
    method: "post",
    // data: data
  });
}

export async function bindFileRole(data) {
  return request({
    url: `/roles/file/bind`,
    method: "post",
    data: data
  });
}

export async function bindUserRole(data) {
  return request({
    url: `/roles/user/bind`,
    method: "post",
    data: data
  });
}

export function deleteTag(data) {
  return request({
    url: `/api/files/` + data,
    method: "delete",
  });
}

export function listTag() {
  return request({
    url: "/api/files/tags",
    method: "get",
  });
}

export function previewFile(storage_key) {
  return request({
    url: `api/files/preview/${storage_key}`,
    method: 'get',
    responseType: 'blob', // バイナリデータとして取得
  });
}

export function downloadFile(storage_key) {
  return request({
    url: `api/files/download/${storage_key}`,
    method: 'get',
    responseType: 'blob', // バイナリデータとして取得
  });
}

export function extractTextFromFile(file) {
  const formData = new FormData();
  formData.append('file', file);
  
  return request({
    url: `/api/files/extract-text`,
    method: "post",
    data: formData,
    headers: {
      "Content-Type": "multipart/form-data",
    },
    timeout: 30000,
  });
}
