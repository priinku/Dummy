import request from "@/utils/request";

export function getUserList(query) {
  return request({
    url: "/user/list",
    method: "get",
    params: query,
  });
}

export function createUser(data) {
  return request({
    url: "/user/create",
    method: "post",
    data: data,
  });
}

export function updateUser(data) {
  return request({
    url: "/user/update",
    method: "put",
    data: data,
  });
}

export function getUserGroups(userId) {
  return request({
    url: `/user/${userId}/groups`,
    method: "get",
  });
}

export function changeUserStatus(userId, status) {
  const data = {
    userId,
    status,
  };
  return request({
    url: "/user/profile",
    method: "put",
    data: data,
  });
}

export function delUser(userId) {
  return request({
    url: "/user/" + userId,
    method: "delete",
  });
}

export function changeUserPassword(userId, password) {
  const data = {
    userId,
    password,
  };
  return request({
    url: "/user/password",
    method: "put",
    data: data,
  });
}
