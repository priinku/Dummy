import request from "@/utils/request";

export function getGroupList() {
  return request({
    url: "/group/list",
    method: "get",
  });
}

export function createGroup(data) {
  return request({
    url: "/group/create",
    method: "post",
    data: data,
  });
}

export function updateGroup(groupId, data) {
  return request({
    url: `/group/${groupId}`,
    method: "put",
    data: data,
  });
}

export function deleteGroup(groupId) {
  return request({
    url: `/group/${groupId}`,
    method: "delete",
  });
}
