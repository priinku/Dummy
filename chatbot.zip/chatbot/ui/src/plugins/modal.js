import {
  ElLoading,
  ElMessage,
  ElMessageBox,
  ElNotification,
} from "element-plus";

let loadingInstance;

export default {
  msg(content) {
    ElMessage.info(content);
  },
  msgError(content) {
    ElMessage.error(content);
  },
  msgSuccess(content) {
    ElMessage.success(content);
  },
  msgWarning(content) {
    ElMessage.warning(content);
  },
  alert(content) {
    ElMessageBox.alert(content, "システム案内");
  },
  alertError(content) {
    ElMessageBox.alert(content, "システム案内", { type: "error" });
  },
  alertSuccess(content) {
    ElMessageBox.alert(content, "システム案内", { type: "success" });
  },
  alertWarning(content) {
    ElMessageBox.alert(content, "システム案内", { type: "warning" });
  },
  notify(content) {
    ElNotification.info(content);
  },
  notifyError(content) {
    ElNotification.error(content);
  },
  notifySuccess(content) {
    ElNotification.success(content);
  },
  notifyWarning(content) {
    ElNotification.warning(content);
  },
  confirm(content) {
    return ElMessageBox.confirm(content, "システム案内", {
      confirmButtonText: "はい",
      cancelButtonText: "キャンセル",
      type: "warning",
    });
  },
  prompt(content) {
    return ElMessageBox.prompt(content, "システム案内", {
      confirmButtonText: "はい",
      cancelButtonText: "キャンセル",
      type: "warning",
    });
  },
  loading(content) {
    loadingInstance = ElLoading.service({
      lock: true,
      text: content,
      background: "rgba(0, 0, 0, 0.7)",
    });
  },
  closeLoading() {
    loadingInstance.close();
  },
};
