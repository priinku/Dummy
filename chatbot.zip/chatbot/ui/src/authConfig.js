export const msalConfig = {
  auth: {
    clientId: import.meta.env.VITE_APP_AZURE_AD_CLIENT_ID,
    authority: `https://login.microsoftonline.com/${import.meta.env.VITE_APP_AZURE_AD_TENANT_ID}`,
    redirectUri: import.meta.env.VITE_APP_AZURE_AD_REDIRECT_URI,
    navigateToLoginRequestUrl: true,
  },
  cache: {
    cacheLocation: "localStorage",
    storeAuthStateInCookie: true,
  },
  system: {
    allowRedirectInIframe: true,
    /*  loggerOptions: {
      loggerCallback: (level, message, containsPii) => {
        console.log("MSAL:", message);
      },
      piiLoggingEnabled: true,
      logLevel: 3, // verbose
    }, */
  },
};

export const loginRequest = {
  scopes: ["openid", "profile", "email"],
  responseMode: "query",
};
