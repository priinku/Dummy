/**
 * User Session Timeout Management Service
 * ユーザーセッションタイムアウト管理サービス
 * Provides automatic logout functionality
 * 自動ログアウト機能を提供
 */
import { 
  getConfig, 
  shouldEnableTimeout, 
  getTimeoutDuration, 
  getWarningDuration, 
  getFinalWarningDuration 
} from './timeoutConfig'

class TimeoutService {
  constructor() {
    this.config = getConfig()
    this.timeoutDuration = getTimeoutDuration()
    this.warningTime = getWarningDuration()
    this.finalWarningTime = getFinalWarningDuration()
    this.timeoutId = null;
    this.warningTimeoutId = null;
    this.finalWarningTimeoutId = null;
    this.isActive = false;
    this.lastActivity = Date.now();
    this.isPageVisible = true;
    this.resetDebounceTimer = null; // Debounce timer / デバウンスタイマー
    this.isWarningActive = false; // Track if warning is currently active / 警告が現在アクティブかどうかを追跡
    
    // Bind event listeners / イベントリスナーをバインド
    this.activityEvents = [
      'mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click'
    ];
    
    this.setupActivityListeners();
    this.initEventListeners();
    this.setupVisibilityListener();
  }

  /**
   * Setup activity listeners / アクティビティリスナーを設定
   */
  setupActivityListeners() {
    this.activityEvents.forEach(event => {
      document.addEventListener(event, this.resetTimeout.bind(this), true);
    });
  }

  /**
   * Remove activity listeners / アクティビティリスナーを削除
   */
  removeActivityListeners() {
    this.activityEvents.forEach(event => {
      document.removeEventListener(event, this.resetTimeout.bind(this), true);
    });
  }

  /**
   * Setup page visibility listener / ページ可視性リスナーを設定
   */
  setupVisibilityListener() {
    document.addEventListener('visibilitychange', () => {
      this.isPageVisible = !document.hidden;
      
      if (this.config.onlyWhenVisible) {
        if (this.isPageVisible && this.isActive) {
          this.resetTimeout();
        } else if (!this.isPageVisible) {
          this.clearTimeouts();
        }
      }
    });
  }

  /**
   * Check if user is logged in / ユーザーがログインしているかチェック
   */
  isUserLoggedIn() {
    // Check if token exists in cookies / Cookieにトークンが存在するかチェック
    const token = document.cookie.split(';').find(cookie => cookie.trim().startsWith('Admin-Token='));
    const isLoggedIn = !!token;
    
    return isLoggedIn;
  }

  /**
   * Reset timeout timer (with debounce) / タイムアウトタイマーをリセット（デバウンス付き）
   */
  resetTimeout() {
    if (!this.isActive) return;
    
    // If warning is active, ignore all user activity / 警告がアクティブな場合、すべてのユーザーアクティビティを無視
    if (this.isWarningActive) {
      return;
    }
    
    // Check if user is still logged in / ユーザーがまだログインしているかチェック
    if (!this.isUserLoggedIn()) {
      this.stop();
      return;
    }
    
    // If configured to only count when page is visible and page is not visible, don't reset
    // ページが可視の時のみカウントする設定で、ページが不可視の場合はリセットしない
    if (this.config.onlyWhenVisible && !this.isPageVisible) {
      return;
    }
    
    // Clear previous debounce timer / 前のデバウンスタイマーをクリア
    if (this.resetDebounceTimer) {
      clearTimeout(this.resetDebounceTimer);
    }
    
    // Set debounce timer to avoid frequent resets / 頻繁なリセットを避けるためデバウンスタイマーを設定
    this.resetDebounceTimer = setTimeout(() => {
      this.lastActivity = Date.now();
      this.clearTimeouts();
      this.startTimeout();
      this.resetDebounceTimer = null;
    }, 1000); // 1 second debounce / 1秒デバウンス
  }

  /**
   * Start timeout countdown / タイムアウトカウントダウンを開始
   */
  startTimeout() {
    if (!this.isActive) {
      return;
    }
    
    // If configured to only count when page is visible and page is not visible, don't start counting
    // ページが可視の時のみカウントする設定で、ページが不可視の場合はカウントを開始しない
    if (this.config.onlyWhenVisible && !this.isPageVisible) {
      return;
    }

    // Clear existing timers / 既存のタイマーをクリア
    this.clearTimeouts();

    // Calculate relative time (absolute time from now) / 相対時間を計算（現在からの絶対時間）
    const now = Date.now();
    const warningTime = this.warningTime; // Time until warning / 警告までの時間

    // Set warning timer / 警告タイマーを設定
    this.warningTimeoutId = setTimeout(() => {
      // Check if user is still logged in before showing warning / 警告を表示する前にログイン状態をチェック
      if (this.isUserLoggedIn()) {
        this.showWarning();
      } else {
        this.stop();
      }
    }, warningTime);

    // Set auto logout timer / 自動ログアウトタイマーを設定
    this.timeoutId = setTimeout(() => {
      // Check if user is still logged in before logout / ログアウト前にログイン状態をチェック
      if (this.isUserLoggedIn()) {
        this.forceLogout();
      } else {
        console.log('User already logged out / ユーザーは既にログアウトしています');
      }
    }, this.timeoutDuration);
  }

  /**
   * Clear all timers / すべてのタイマーをクリア
   */
  clearTimeouts() {
    if (this.warningTimeoutId) {
      clearTimeout(this.warningTimeoutId);
      this.warningTimeoutId = null;
    }
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
      this.timeoutId = null;
    }
  }

  /**
   * Show warning / 警告を表示
   */
  showWarning() {
    // Calculate actual remaining time / 実際の残り時間を計算
    const remainingTime = this.getRemainingTime();
    
    // Set warning as active / 警告をアクティブに設定
    this.isWarningActive = true;
    
    window.dispatchEvent(new CustomEvent('timeout-warning', {
      detail: {
        type: 'warning',
        remainingTime: Math.max(0, remainingTime),
        canExtend: true
      }
    }));
  }

  /**
   * Force logout / 強制ログアウト
   */
  forceLogout() {
    window.dispatchEvent(new CustomEvent('timeout-logout', {
      detail: {
        reason: 'timeout',
        message: 'セッションがタイムアウトしました。再度ログインしてください。'
      }
    }));
  }

  /**
   * Extend session time / セッション時間を延長
   */
  extendSession() {
    // Reset warning state / 警告状態をリセット
    this.isWarningActive = false;
    
    this.resetTimeout();
    window.dispatchEvent(new CustomEvent('timeout-extended', {
      detail: {
        message: 'セッションが30分延長されました'
      }
    }));
  }

  /**
   * Initialize event listeners / イベントリスナーを初期化
   */
  initEventListeners() {
    // Listen for extend session event / セッション延長イベントを監視
    window.addEventListener('extend-session', () => {
      this.extendSession();
    });
  }

  /**
   * Start timeout monitoring / タイムアウト監視を開始
   */
  start() {
    // Check if timeout should be enabled / タイムアウトを有効にするかチェック
    if (!shouldEnableTimeout()) {
      return;
    }
    
    // Check if user is logged in / ユーザーがログインしているかチェック
    if (!this.isUserLoggedIn()) {
      // Don't start timeout service if user is not logged in / ユーザーがログインしていない場合はタイムアウトサービスを開始しない
      return;
    }
    
    
    this.isActive = true;
    this.lastActivity = Date.now();
    this.startTimeout();
  }

  /**
   * Stop timeout monitoring / タイムアウト監視を停止
   */
  stop() {
    this.isActive = false;
    this.isWarningActive = false; // Reset warning state / 警告状態をリセット
    this.clearTimeouts();
    
    // Clear debounce timer / デバウンスタイマーをクリア
    if (this.resetDebounceTimer) {
      clearTimeout(this.resetDebounceTimer);
      this.resetDebounceTimer = null;
    }
  }

  /**
   * Get remaining time / 残り時間を取得
   */
  getRemainingTime() {
    if (!this.isActive) return 0;
    const elapsed = Date.now() - this.lastActivity;
    return Math.max(0, this.timeoutDuration - elapsed);
  }

  /**
   * Get formatted remaining time / フォーマットされた残り時間を取得
   */
  getFormattedRemainingTime() {
    const remaining = this.getRemainingTime();
    const minutes = Math.floor(remaining / 60000);
    const seconds = Math.floor((remaining % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }

  /**
   * Set custom timeout duration / カスタムタイムアウト時間を設定
   */
  setTimeoutDuration(minutes) {
    this.timeoutDuration = minutes * 60 * 1000;
    this.warningTime = Math.max(0, this.timeoutDuration - 5 * 60 * 1000);
    this.finalWarningTime = Math.max(0, this.timeoutDuration - 1 * 60 * 1000);
    
    if (this.isActive) {
      this.resetTimeout();
    }
  }

  /**
   * Destroy service / サービスを破棄
   */
  destroy() {
    this.stop();
    this.removeActivityListeners();
  }
}

// Create singleton instance / シングルトンインスタンスを作成
const timeoutService = new TimeoutService();

export default timeoutService;
