/**
 * Timeout Configuration Management
 * タイムアウト設定管理
 * Provides timeout-related configuration options and default values
 * タイムアウト関連の設定オプションとデフォルト値を提供
 */

// Default configuration / デフォルト設定
const defaultConfig = {
  // Timeout duration (minutes) / タイムアウト時間（分）
  timeoutMinutes: 15, // 15 minute = 900 seconds / 15分 = 900秒
  
  // Warning time (minutes) - how much time before warning / 警告時間（分）- 警告の何分前
  warningMinutes: 13, // 13 minutes before warning = 780 seconds warning / 13分前警告 = 780秒警告
  
  // Final warning time (minutes) - how much time before final warning / 最終警告時間（分）- 最終警告の何分前
  finalWarningMinutes: 0, // 0 minutes - no final warning / 0分 - 最終警告なし
  
  // Whether to enable timeout functionality / タイムアウト機能を有効にするか
  enabled: true,
  
  // Whether to allow session extension / セッション延長を許可するか
  allowExtend: true,
  
  // Extended session time (minutes) / 延長セッション時間（分）
  extendMinutes: 15, // 15 minute = 900 seconds / 15分 = 900秒
  
  // Whether to count only when page is visible / ページが可視の時のみカウントするか
  onlyWhenVisible: true,
  
  // Whether to enable in development environment / 開発環境で有効にするか
  enableInDevelopment: true // Enable in development for testing / テストのため開発環境で有効
}

// Load configuration from localStorage / localStorageから設定を読み込み
function loadConfig() {
  try {
    const savedConfig = localStorage.getItem('timeout-config')
    if (savedConfig) {
      return { ...defaultConfig, ...JSON.parse(savedConfig) }
    }
  } catch (error) {
    console.warn('Unable to read timeout configuration / タイムアウト設定を読み取れません:', error)
  }
  return defaultConfig
}

// Save configuration to localStorage / localStorageに設定を保存
function saveConfig(config) {
  try {
    localStorage.setItem('timeout-config', JSON.stringify(config))
    return true
  } catch (error) {
    console.warn('Unable to save timeout configuration / タイムアウト設定を保存できません:', error)
    return false
  }
}

// Reset configuration to default values / 設定をデフォルト値にリセット
function resetConfig() {
  localStorage.removeItem('timeout-config')
  return { ...defaultConfig }
}

// Get current configuration / 現在の設定を取得
function getConfig() {
  return loadConfig()
}

// Update configuration / 設定を更新
function updateConfig(newConfig) {
  const currentConfig = loadConfig()
  const updatedConfig = { ...currentConfig, ...newConfig }
  saveConfig(updatedConfig)
  return updatedConfig
}

// Check if timeout should be enabled / タイムアウトを有効にするかチェック
function shouldEnableTimeout() {
  const config = getConfig()
  
  // Check if enabled / 有効かチェック
  if (!config.enabled) {
    return false
  }
  
  // Check development environment / 開発環境をチェック
  if (process.env.NODE_ENV === 'development' && !config.enableInDevelopment) {
    return false
  }
  
  return true
}

// Get timeout duration (milliseconds) / タイムアウト時間を取得（ミリ秒）
function getTimeoutDuration() {
  const config = getConfig()
  return config.timeoutMinutes * 60 * 1000
}

// Get warning duration (milliseconds) / 警告時間を取得（ミリ秒）
function getWarningDuration() {
  const config = getConfig()
  return config.warningMinutes * 60 * 1000
}

// Get final warning duration (milliseconds) / 最終警告時間を取得（ミリ秒）
function getFinalWarningDuration() {
  const config = getConfig()
  return config.finalWarningMinutes * 60 * 1000
}

// Get extended session duration (milliseconds) / 延長セッション時間を取得（ミリ秒）
function getExtendDuration() {
  const config = getConfig()
  return config.extendMinutes * 60 * 1000
}

// Default timeout configuration options / デフォルトタイムアウト設定オプション
const timeoutOptions = [
  { label: '30秒', value: 0.5 },
  { label: '1分', value: 1 },
  { label: '2分', value: 2 },
  { label: '5分', value: 5 },
  { label: '10分', value: 10 },
  { label: '30分', value: 30 }
]

// Default warning time options / デフォルト警告時間オプション
const warningOptions = [
  { label: '10秒前', value: 0.17 },
  { label: '30秒前', value: 0.5 },
  { label: '1分前', value: 1 },
  { label: '2分前', value: 2 }
]

export {
  defaultConfig,
  loadConfig,
  saveConfig,
  resetConfig,
  getConfig,
  updateConfig,
  shouldEnableTimeout,
  getTimeoutDuration,
  getWarningDuration,
  getFinalWarningDuration,
  getExtendDuration,
  timeoutOptions,
  warningOptions
}

