import cache from "@/plugins/cache";
import useUserStore from "@/store/modules/user";
import { getToken } from "@/utils/auth";
import { tansParams } from "@/utils/best";
import axios from "axios";
import { ElMessage, ElMessageBox, ElNotification } from "element-plus";
import { el } from "element-plus/es/locale/index.mjs";

export let isReLogin = { show: false };

//axios.defaults.headers["Content-Type"] = "application/json;charset=utf-8";
const service = axios.create({
  baseURL: import.meta.env.VITE_APP_BASE_API,
  timeout: 10000,
});

service.interceptors.request.use(
  (config) => {
    if (config.data && !(config.data instanceof FormData)) {
      config.headers["Content-Type"] = "application/json;charset=utf-8";
    }

    const isToken = (config.headers || {}).isToken === false;
    const isRepeatSubmit = (config.headers || {}).repeatSubmit === false;
    if (getToken() && !isToken) {
      config.headers["Authorization"] = "Bearer " + getToken();
    }
    if (config.method === "get" && config.params) {
      let url = config.url + "?" + tansParams(config.params);
      url = url.slice(0, -1);
      config.params = {};
      config.url = url;
    }
    if (
      !isRepeatSubmit &&
      (config.method === "post" || config.method === "put")
    ) {
      const requestObj = {
        url: config.url,
        data:
          typeof config.data === "object"
            ? JSON.stringify(config.data)
            : config.data,
        time: new Date().getTime(),
      };
      const requestSize = Object.keys(JSON.stringify(requestObj)).length;
      const limitSize = 5 * 1024 * 1024;
      if (requestSize >= limitSize) {
        console.warn(
          `[${config.url}]: ` +
          "データのサイズが許可されている5MBの制限を上回っています。重複送信のチェックが可能です。"
        );
        return config;
      }
      const sessionObj = cache.session.getJSON("sessionObj");
      if (
        sessionObj === undefined ||
        sessionObj === null ||
        sessionObj === ""
      ) {
        cache.session.setJSON("sessionObj", requestObj);
      } else {
        const s_url = sessionObj.url;
        const s_data = sessionObj.data;
        const s_time = sessionObj.time;
        const interval = 1000;
        if (
          s_data === requestObj.data &&
          requestObj.time - s_time < interval &&
          s_url === requestObj.url
        ) {
          const message =
            "データを処理中ですので、再度アップロードしないでください。";
          console.warn(`[${s_url}]: ` + message);
          return Promise.reject(new Error(message));
        } else {
          cache.session.setJSON("sessionObj", requestObj);
        }
      }
    }
    return config;
  },
  (error) => {
    console.log(error);
    Promise.reject(error);
  }
);

service.interceptors.response.use(
  (res) => {
    return Promise.resolve(res.data);
  },
  (error) => {
    if (error.response) {
      // 通常のレスポンスエラー
      const { data } = error.response;
      const code = data.code;
      const msg = data.message;
      if (code === "401") {
        if (!isReLogin.show) {
          isReLogin.show = true;
          ElMessageBox.confirm(
            "ログイン期限切れです。機能を使用する場合は再度ログインしてください。",
            "システム案内",
            {
              confirmButtonText: "再ログインする",
              cancelButtonText: "キャンセル",
              type: "warning",
            }
          )
            .then(() => {
              isReLogin.show = false;
              useUserStore()
                .logOut()
                .then(() => {
                  location.href = "/";
                })
                .catch(() => {
                  console.log("location start");
                  location.href = "/";
                });
            })
            .catch(() => {
              isReLogin.show = false;
            });
        }
        return Promise.reject(
          "無効なセッション、またはセッションは期限切れのため、再度ログインしてください。"
        );
      } else if (code === 500) {
        ElMessage({ message: msg, type: "error" });
        return Promise.reject(new Error(msg));
      } else if (code === 601) {
        ElMessage({ message: msg, type: "warning" });
        return Promise.reject(new Error(msg));
      }
      ElNotification.error({ title: msg });
      return Promise.resolve(data);
    } else {
      // レスポンスがない場合やネットワークエラーの場合
      if(error.message === "Network Error") {
        ElMessage({
          message: "ネットワークエラー、接続を確認してください。",
          type: "error",
        });
        return Promise.reject(new Error("ネットワークエラー"));
      }
      else if (error.message.includes("timeout")) {
        ElMessage({
          message: "リクエストがタイムアウトしました。",
          type: "error",
        });
        return Promise.reject(new Error("リクエストがタイムアウトしました"));
      }
      else{
        ElMessage({
          message: "予期しないエラーが発生しました。",
          type: "error",
        });
        return Promise.reject(new Error("予期しないエラー"));
      }
    }
  }
);

export default service;
