import { createHead } from "@vueuse/head";
import ElementPlus from "element-plus";
import "element-plus/dist/index.css";
import locale from "element-plus/es/locale/lang/ja";
import { createApp } from "vue";
import { addDateRange, parseTime } from "./utils/best";

import "@/assets/styles/global.scss";
import "@/assets/styles/index.scss";

import App from "./App";
import router from "./router";
import store from "./store";

import FileUpload from "@/components/FileUpload";
import Pagination from "@/components/Pagination";
import SvgIcon from "@/components/SvgIcon";
import elementIcons from "@/components/SvgIcon/svgicon";
import "virtual:svg-icons-register";
import plugins from "./plugins";

import "./permission";

import { PublicClientApplication } from "@azure/msal-browser";
import { msalConfig } from "./authConfig";

// crypto の利用可能性を確認
function isCryptoAvailable() {
  return typeof window !== 'undefined' &&
    (window.crypto || window.msCrypto) &&
    (window.crypto?.subtle || window.msCrypto?.subtle);
}

// Initialize MSAL instance with error handling
let msalInstance = null;

try {
  // crypto の利用可能性を確認
  if (isCryptoAvailable()) {
    msalInstance = new PublicClientApplication(msalConfig);
    await msalInstance.initialize();

    await msalInstance
      .handleRedirectPromise()
      .then((resp) => {
        if (resp) {
          msalInstance.setActiveAccount(resp.account);
        } else {
          const accounts = msalInstance.getAllAccounts();
          if (accounts.length > 0) {
            msalInstance.setActiveAccount(accounts[0]);
          }
        }
      })
      .catch((err) => {
        console.warn("⚠️ MSAL リダイレクト処理エラー（非クリティカル）:", err);
      });
  } else {
    console.warn("⚠️ Web Crypto API が利用できないため、MSAL は使用できません。HTTPS を使用するか、ブラウザが Web Crypto API をサポートしていることを確認してください。");
  }
} catch (error) {
  console.warn("⚠️ MSAL 初期化失敗（非クリティカル）:", error.message);
  console.warn("⚠️ SSO 機能は利用できない可能性がありますが、その他の機能は正常に動作するはずです。");
}

const head = createHead();
const app = createApp(App);

app.config.globalProperties.parseTime = parseTime;
app.config.globalProperties.addDateRange = addDateRange;

app.component("Pagination", Pagination);
app.component("FileUpload", FileUpload);
app.component("svg-icon", SvgIcon);

app.use(router);
app.use(store);
app.use(plugins);
app.use(elementIcons);
app.use(ElementPlus, { locale: locale, size: "default" });
app.config.warnHandler = () => { };
app.use(head);

// MSAL が正常に初期化された場合のみ提供
if (msalInstance) {
  app.provide("msal", msalInstance);
}
app.mount("#app");

const urlParams = new URLSearchParams(window.location.search);
const isSSO = urlParams.get("sso") === "true";

if (isSSO) {
  const token = localStorage.getItem("app_jwt_sso");

  if (!token) {
    // MSAL の利用可能性を確認し、利用不可の場合は直接リダイレクト方式を使用
    if (msalInstance) {
      // MSAL を使用したサインイン（利用可能な場合）
      // 直接リダイレクトへのフォールバック
      const tenantId = import.meta.env.VITE_APP_AZURE_AD_TENANT_ID;
      const clientId = import.meta.env.VITE_APP_AZURE_AD_CLIENT_ID;
      const redirectUri = encodeURIComponent(import.meta.env.VITE_APP_AZURE_AD_REDIRECT_URI);

      window.location.href =
        `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/authorize` +
        `?client_id=${clientId}` +
        `&response_type=code` +
        `&redirect_uri=${redirectUri}` +
        `&scope=openid profile email offline_access` +
        `&response_mode=query` +
        `&state=12345`;
    } else {
      // MSAL 利用不可のため直接リダイレクトを使用
      const tenantId = import.meta.env.VITE_APP_AZURE_AD_TENANT_ID;
      const clientId = import.meta.env.VITE_APP_AZURE_AD_CLIENT_ID;
      const redirectUri = encodeURIComponent(import.meta.env.VITE_APP_AZURE_AD_REDIRECT_URI);

      window.location.href =
        `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/authorize` +
        `?client_id=${clientId}` +
        `&response_type=code` +
        `&redirect_uri=${redirectUri}` +
        `&scope=openid profile email offline_access` +
        `&response_mode=query` +
        `&state=12345`;
    }
  }
}
