import Layout from "@/layout";
import { createRouter, createWebHistory } from "vue-router";

export const constantRoutes = [
  {
    path: "/redirect",
    component: Layout,
    hidden: true,
    children: [
      {
        path: "/redirect/:path(.*)",
        component: () => import("@/views/redirect/index.vue"),
      },
    ],
  },
  {
    path: "/login",
    component: () => import("@/views/login"),
    hidden: true,
  },
  {
    path: "/ssoLoginSuccess",
    component: () => import("@/views/ssoLoginSuccess"),
    hidden: true,
  },
  {
    path: "/:pathMatch(.*)*",
    component: () => import("@/views/error/404"),
    hidden: true,
  },
  {
    path: "/401",
    component: () => import("@/views/error/401"),
    hidden: true,
  },
  {
    path: "/403",
    component: () => import("@/views/error/403"),
    hidden: true,
  },
  {
    path: "", component: Layout, redirect: "/home", children: [{ path: "/home", component: () => import("@/views/home"), name: "home", meta: { title: "", icon: "home", affix: true }, },],
  },
  {
    path: "",
    component: Layout,
    redirect: "/chat",
    children: [
      {
        path: "/chat",
        component: () => import("@/views/chat"),
        name: "chat",
        meta: { title: "チャット", icon: "brand-hipchat", affix: true },
      },
    ],
  },
  {
    path: "",
    component: Layout,
    redirect: "/file",
    children: [
      {
        path: "/file",
        component: () => import("@/views/file"),
        name: "file",
        meta: { title: "ファイル管理", icon: "file", affix: true, roles: ["admin"] },
      },
    ],
  },
  {
    path: "",
    component: Layout,
    redirect: "/flow",
    children: [
      {
        path: "/flow",
        component: () => import("@/views/flow/index.vue"),
        name: "flow",
        meta: { title: "フロー作成", icon: "flow", affix: true },
      },
    ],
  },
  {
    path: "",
    component: Layout,
    redirect: "/settings",
    children: [
      {
        path: "/settings",
        component: () => import("@/views/Settings/index"),
        name: "settings",
        meta: { title: "設定", icon: "settings", affix: true, roles: ["admin"] },
      },
    ],
  },
  {
    path: "",
    component: Layout,
    redirect: "/summary",
    children: [
      {
        path: "/summary",
        component: () => import("@/views/summary"),
        name: "summary",
        meta: { title: "要約", icon: "document", affix: true },
      },
    ],
  },
  {
    path: "",
    component: Layout,
    redirect: "/translate",
    children: [
      {
        path: "/translate",
        component: () => import("@/views/translate"),
        name: "translate",
        meta: { title: "翻訳", icon: "document", affix: true },
      },
    ],
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes: constantRoutes,
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition;
    } else {
      return { top: 0 };
    }
  },
});

export default router;
