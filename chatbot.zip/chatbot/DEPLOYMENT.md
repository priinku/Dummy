# HR Policy Digital Twin - Deployment Guide

## Table of Contents
- [Overview](#overview)
- [Architecture](#architecture)
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Configuration](#configuration)
- [User Management](#user-management)
- [Services Reference](#services-reference)
- [Troubleshooting](#troubleshooting)
- [Production Deployment](#production-deployment)

---

## Overview

HR Policy Digital Twin is a bilingual (English/Japanese) HR policy Q&A chatbot powered by RAG (Retrieval-Augmented Generation) and local LLM (Ollama).

### Key Features
- 🌐 **Dual-language support** - Query in English, retrieve Japanese documents, respond in both languages
- 🤖 **Local LLM** - Uses Ollama with llama3.2 model (no external API keys needed)
- 📄 **RAG Pipeline** - Document retrieval using Solr
- 💬 **ChatGPT-style UI** - Modern React interface with real-time responses

---

## Architecture

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   UI (7001) │────▶│  API (9090) │────▶│ Ollama(11434)│
└─────────────┘     └─────────────┘     └─────────────┘
                           │
              ┌────────────┼────────────┐
              ▼            ▼            ▼
        ┌─────────┐  ┌─────────┐  ┌─────────┐
        │  MySQL  │  │  Redis  │  │  Solr   │
        │ (3306)  │  │ (6379)  │  │ (8983)  │
        └─────────┘  └─────────┘  └─────────┘
```

---

## Prerequisites

### System Requirements
| Component | Minimum | Recommended |
|-----------|---------|-------------|
| CPU | 4 cores | 8+ cores |
| RAM | 8 GB | 16+ GB |
| Storage | 20 GB | 50+ GB |
| OS | macOS / Linux | macOS / Linux |

### Required Software
```bash
# Node.js (v18 or higher)
node --version  # Should be >= 18.0.0

# pnpm (package manager)
npm install -g pnpm

# Docker & Docker Compose
docker --version
docker-compose --version

# Ollama (for local LLM)
# macOS
brew install ollama

# Linux
curl -fsSL https://ollama.com/install.sh | sh
```

---

## Quick Start

### Step 1: Clone Repository
```bash
git clone <repository-url>
cd dtij
```

### Step 2: Start Docker Services
```bash
# Start MySQL, Redis, and Solr
docker-compose up -d

# Wait for services to be ready (especially MySQL)
sleep 30

# Verify services are running
docker-compose ps
```

### Step 3: Setup Ollama
```bash
# Start Ollama service (in background)
ollama serve &

# Pull the required model
ollama pull llama3.2

# Verify Ollama is running
curl http://localhost:11434/api/tags
```

### Step 4: Install Dependencies
```bash
# API dependencies
cd api
pnpm install

# UI dependencies
cd ../ui-2
pnpm install
```

### Step 5: Create First User
```bash
# Generate password hash for "12345"
# Hash: $2a$10$LlA/zWdpR0IfuDVqMu1wt.rAlYgHvIiunQ4rVW8lD194/vy4Wk76K

docker exec -it dtij-mysql-1 mysql -u aviaryAdmin -pav1aRy@adm1n aviary-db -e "
INSERT INTO user (user_name, password, status) 
VALUES ('admin', '\$2a\$10\$LlA/zWdpR0IfuDVqMu1wt.rAlYgHvIiunQ4rVW8lD194/vy4Wk76K', '1');
"
```

### Step 6: Start Application
```bash
# Terminal 1 - Start API Server
cd api
pnpm run dev

# Terminal 2 - Start UI
cd ui-2
pnpm run dev
```

### Step 7: Access Application
- **UI**: http://localhost:7001
- **API**: http://localhost:9090
- **Bull Board** (Job Queue): http://localhost:9999

**Default Login:**
- Username: `admin`
- Password: `12345`

---

## Configuration

### Main Configuration File
**Location:** `/config/default.yml`

```yaml
# Backend Server Configuration
Backend:
  host: localhost
  port: 9090
  jwtSecret: "change-this-secret-in-production"
  logTime: ja-JP

# MySQL Database
MySQL:
  host: localhost
  port: 3306
  database: aviary-db
  username: aviaryAdmin
  password: av1aRy@adm1n

# Redis Cache & Queue
Redis:
  host: localhost
  port: 6379
  password: abcd1234

# Ollama LLM Configuration
Ollama:
  - host: http://localhost:11434
    weight: 1

# Model Configuration
Models:
  chatModel:
    name: llama3.2
    temperature: 0.7
  chatTitleGenModel:
    name: llama3.2
    temperature: 0.8
    repeat_penalty: 1.5

# RAG Configuration
RAG:
  mode:
    - splitByPage
  useFaqCache: false
  Uploads:
    filesDir: ./uploads
    maxFileSize: 52428800  # 50MB
    keepExtensions: true
```

### Docker Compose Configuration
**Location:** `/docker-compose.yml`

```yaml
version: '3.8'
services:
  mysql:
    image: mysql:8.0
    environment:
      MYSQL_ROOT_PASSWORD: root
      MYSQL_DATABASE: aviary-db
      MYSQL_USER: aviaryAdmin
      MYSQL_PASSWORD: av1aRy@adm1n
    ports:
      - "3306:3306"
    volumes:
      - mysql_data:/var/lib/mysql

  redis:
    image: redis:latest
    command: redis-server --requirepass abcd1234
    ports:
      - "6379:6379"

  solr:
    image: solr:9.8.1
    ports:
      - "8983:8983"
    volumes:
      - solr_data:/var/solr

volumes:
  mysql_data:
  solr_data:
```

### UI Proxy Configuration
**Location:** `/ui-2/vite.config.ts`

```typescript
export default defineConfig({
  server: {
    port: 7001,
    proxy: {
      '/dev-api': {
        target: 'http://localhost:9090',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/dev-api/, ''),
      },
    },
  },
});
```

---

## User Management

### Create New User

#### Method 1: Command Line
```bash
# Step 1: Generate password hash
node -e "const bcrypt = require('bcryptjs'); console.log(bcrypt.hashSync('YOUR_PASSWORD', 10));"

# Step 2: Insert into database
docker exec -it dtij-mysql-1 mysql -u aviaryAdmin -pav1aRy@adm1n aviary-db -e "
INSERT INTO user (user_name, password, status) 
VALUES ('newuser', 'PASTE_HASH_HERE', '1');
"
```

#### Method 2: Script
Create file `/api/scripts/createUser.js`:
```javascript
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');

async function createUser(username, password) {
  const connection = await mysql.createConnection({
    host: 'localhost',
    user: 'aviaryAdmin',
    password: 'av1aRy@adm1n',
    database: 'aviary-db'
  });

  const hash = bcrypt.hashSync(password, 10);
  await connection.execute(
    'INSERT INTO user (user_name, password, status) VALUES (?, ?, ?)',
    [username, hash, '1']
  );
  
  console.log(`User "${username}" created successfully!`);
  await connection.end();
}

// Usage: node createUser.js <username> <password>
const [,, username, password] = process.argv;
if (username && password) {
  createUser(username, password);
} else {
  console.log('Usage: node createUser.js <username> <password>');
}
```

Run:
```bash
cd api
node scripts/createUser.js myuser mypassword123
```

### List Users
```bash
docker exec -it dtij-mysql-1 mysql -u aviaryAdmin -pav1aRy@adm1n aviary-db -e "
SELECT user_id, user_name, status, created_at FROM user;
"
```

### Delete User
```bash
docker exec -it dtij-mysql-1 mysql -u aviaryAdmin -pav1aRy@adm1n aviary-db -e "
DELETE FROM user WHERE user_name = 'username_to_delete';
"
```

### Reset Password
```bash
# Generate new hash
NEW_HASH=$(node -e "const bcrypt = require('bcryptjs'); console.log(bcrypt.hashSync('newpassword', 10));")

docker exec -it dtij-mysql-1 mysql -u aviaryAdmin -pav1aRy@adm1n aviary-db -e "
UPDATE user SET password = '$NEW_HASH' WHERE user_name = 'username';
"
```

---

## Services Reference

| Service | Port | URL | Credentials |
|---------|------|-----|-------------|
| **UI (React)** | 7001 | http://localhost:7001 | User login required |
| **API (Node.js)** | 9090 | http://localhost:9090 | JWT Bearer token |
| **MySQL** | 3306 | localhost:3306 | aviaryAdmin / av1aRy@adm1n |
| **Redis** | 6379 | localhost:6379 | Password: abcd1234 |
| **Solr** | 8983 | http://localhost:8983/solr | No authentication |
| **Ollama** | 11434 | http://localhost:11434 | No authentication |
| **Bull Board** | 9999 | http://localhost:9999 | No authentication |

### API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/user/login` | POST | User authentication |
| `/user/logout` | DELETE | Logout |
| `/api/gen-task` | POST | Create chat task |
| `/api/gen-task/list` | GET | List chat history |
| `/api/gen-task-output/list` | GET | Get chat messages |
| `/api/gen-task/feedback` | POST | Submit feedback |

---

## Troubleshooting

### Common Issues

#### 1. "Connection refused" to API
```bash
# Check if API is running
lsof -i :9090

# Restart API
cd api && pnpm run dev
```

#### 2. MySQL connection failed
```bash
# Check MySQL container
docker-compose ps

# View MySQL logs
docker-compose logs mysql

# Restart MySQL
docker-compose restart mysql
```

#### 3. Ollama not responding
```bash
# Check Ollama status
curl http://localhost:11434/api/tags

# Restart Ollama
pkill ollama
ollama serve &

# Re-pull model if needed
ollama pull llama3.2
```

#### 4. Jobs stuck in queue
```bash
# Clear job queue
docker exec dtij-redis-1 redis-cli -a abcd1234 -n 6 FLUSHDB

# Restart API
pkill -f "ts-node-dev"
cd api && pnpm run dev
```

#### 5. Port already in use
```bash
# Find process using port
lsof -i :9090

# Kill process
kill -9 <PID>
```

### View Logs

```bash
# API logs (in terminal running pnpm run dev)

# Docker service logs
docker-compose logs -f mysql
docker-compose logs -f redis
docker-compose logs -f solr

# Ollama logs
# Check terminal where "ollama serve" is running
```

---

## Production Deployment

### Security Checklist

- [ ] **Change JWT Secret**
  ```yaml
  # In config/default.yml
  Backend:
    jwtSecret: "generate-a-long-random-string-here"
  ```

- [ ] **Change Database Passwords**
  ```yaml
  MySQL:
    password: "new-secure-password"
  ```

- [ ] **Change Redis Password**
  ```yaml
  Redis:
    password: "new-secure-password"
  ```

- [ ] **Enable HTTPS**
  - Use reverse proxy (nginx/traefik)
  - Configure SSL certificates

- [ ] **Set NODE_ENV**
  ```bash
  export NODE_ENV=production
  ```

- [ ] **Configure Firewall**
  - Only expose necessary ports (7001, 9090)
  - Block direct access to MySQL, Redis, Solr

### Production Start Script

Create `/start-production.sh`:
```bash
#!/bin/bash

# Set environment
export NODE_ENV=production

# Start Docker services
docker-compose up -d

# Wait for services
sleep 30

# Start Ollama
ollama serve &
sleep 5

# Start API (use PM2 for production)
cd /path/to/dtij/api
pm2 start "pnpm run start" --name "dtij-api"

# Start UI (build first for production)
cd /path/to/dtij/ui-2
pnpm run build
pm2 start "pnpm run preview" --name "dtij-ui"

echo "All services started!"
```

### Using PM2 (Process Manager)
```bash
# Install PM2
npm install -g pm2

# Start with PM2
pm2 start ecosystem.config.js

# View status
pm2 status

# View logs
pm2 logs
```

---

## Backup & Restore

### Backup Database
```bash
docker exec dtij-mysql-1 mysqldump -u aviaryAdmin -pav1aRy@adm1n aviary-db > backup_$(date +%Y%m%d).sql
```

### Restore Database
```bash
docker exec -i dtij-mysql-1 mysql -u aviaryAdmin -pav1aRy@adm1n aviary-db < backup_20241209.sql
```

### Backup Uploads
```bash
tar -czvf uploads_backup_$(date +%Y%m%d).tar.gz ./api/uploads/
```

---

## Support

For issues or questions:
1. Check the [Troubleshooting](#troubleshooting) section
2. Review API logs for error messages
3. Check Bull Board (http://localhost:9999) for job queue status

---

*Last Updated: December 2024*
