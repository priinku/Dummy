import { useState, useRef, useEffect, useCallback } from 'react';
import { 
  Send, Bot, User, FileText, Globe, Languages, Copy, ThumbsUp, ThumbsDown, 
  RefreshCw, MoreHorizontal, Check, Share2, Plus, Trash2, StopCircle,
  MessageSquare, X, Sparkles, AlertCircle
} from 'lucide-react';
import { Message } from '../types';
import { listTask, listTaskOutput, addTask, deleteTaskOutput, sendFeedbackToCache } from '../api/task';

interface ChatInterfaceProps {
  onSaveToHistory: (query: string, answer: string, source: any) => void;
}

interface ChatTask {
  id: string;
  title: string;
  createdAt: string;
}

interface TaskOutput {
  id: number;
  metadata: string;
  content: string;
  status: string;
  feedback?: { emoji?: string };
  sort: number;
}

// Toast notification component
function Toast({ message, type, onClose }: { message: string; type: 'success' | 'error' | 'info'; onClose: () => void }) {
  useEffect(() => {
    const timer = setTimeout(onClose, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);

  const colors = {
    success: 'bg-green-500/20 border-green-500/50 text-green-300',
    error: 'bg-red-500/20 border-red-500/50 text-red-300',
    info: 'bg-blue-500/20 border-blue-500/50 text-blue-300',
  };

  return (
    <div className={`fixed top-4 right-4 px-4 py-3 rounded-lg border ${colors[type]} flex items-center gap-2 animate-slideIn z-50`}>
      {type === 'success' && <Check className="w-4 h-4" />}
      {type === 'error' && <AlertCircle className="w-4 h-4" />}
      {type === 'info' && <Sparkles className="w-4 h-4" />}
      <span className="text-sm">{message}</span>
      <button onClick={onClose} className="ml-2 hover:opacity-70">
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}

// Dual language output interface
interface DualLanguageContent {
  isDualLanguage: boolean;
  japanese?: string;
  translated?: string;
  targetLanguage?: string;
  rawContent: string;
}

// Parse dual-language output from backend
function parseDualLanguageContent(content: string): DualLanguageContent {
  const dualLangMatch = content.match(/<!--DUAL_LANG_START-->(.+?)<!--DUAL_LANG_END-->/s);
  
  if (dualLangMatch) {
    try {
      const parsed = JSON.parse(dualLangMatch[1]);
      return {
        isDualLanguage: true,
        japanese: parsed.japanese,
        translated: parsed.translated,
        targetLanguage: parsed.targetLanguage,
        rawContent: content,
      };
    } catch {
      return { isDualLanguage: false, rawContent: content };
    }
  }
  
  return { isDualLanguage: false, rawContent: content };
}

// Action buttons component for bot messages (ChatGPT style)
interface MessageActionsProps {
  content: string;
  messageId: string;
  onFeedback?: (messageId: string, feedback: 'like' | 'dislike') => void;
  onRegenerate?: () => void;
}

function MessageActions({ content, messageId, onFeedback, onRegenerate }: MessageActionsProps) {
  const [copied, setCopied] = useState(false);
  const [feedback, setFeedback] = useState<'like' | 'dislike' | null>(null);
  const [showMore, setShowMore] = useState(false);

  const handleCopy = async () => {
    // Extract plain text from dual-language content if present
    let textToCopy = content;
    const dualMatch = content.match(/<!--DUAL_LANG_START-->(.+?)<!--DUAL_LANG_END-->/s);
    if (dualMatch) {
      try {
        const parsed = JSON.parse(dualMatch[1]);
        textToCopy = `${parsed.translated}\n\n---\n\n${parsed.japanese}`;
      } catch {
        // Use original content
      }
    }
    
    await navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFeedback = (type: 'like' | 'dislike') => {
    setFeedback(type);
    onFeedback?.(messageId, type);
  };

  const handleShare = async () => {
    let textToShare = content;
    const dualMatch = content.match(/<!--DUAL_LANG_START-->(.+?)<!--DUAL_LANG_END-->/s);
    if (dualMatch) {
      try {
        const parsed = JSON.parse(dualMatch[1]);
        textToShare = parsed.translated || parsed.japanese;
      } catch {
        // Use original
      }
    }
    
    if (navigator.share) {
      await navigator.share({ text: textToShare });
    } else {
      await navigator.clipboard.writeText(textToShare);
      alert('Content copied to clipboard!');
    }
  };

  return (
    <div className="flex items-center gap-1 mt-2 pt-2 border-t border-white/10">
      {/* Copy */}
      <button
        onClick={handleCopy}
        className="p-1.5 rounded-md text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        title="Copy"
      >
        {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
      </button>

      {/* Like */}
      <button
        onClick={() => handleFeedback('like')}
        className={`p-1.5 rounded-md transition-colors ${
          feedback === 'like' 
            ? 'text-green-400 bg-green-400/20' 
            : 'text-slate-400 hover:text-white hover:bg-white/10'
        }`}
        title="Good response"
      >
        <ThumbsUp className="w-4 h-4" />
      </button>

      {/* Dislike */}
      <button
        onClick={() => handleFeedback('dislike')}
        className={`p-1.5 rounded-md transition-colors ${
          feedback === 'dislike' 
            ? 'text-red-400 bg-red-400/20' 
            : 'text-slate-400 hover:text-white hover:bg-white/10'
        }`}
        title="Bad response"
      >
        <ThumbsDown className="w-4 h-4" />
      </button>

      {/* Share */}
      <button
        onClick={handleShare}
        className="p-1.5 rounded-md text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        title="Share"
      >
        <Share2 className="w-4 h-4" />
      </button>

      {/* Regenerate */}
      <button
        onClick={onRegenerate}
        className="p-1.5 rounded-md text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
        title="Regenerate response"
      >
        <RefreshCw className="w-4 h-4" />
      </button>

      {/* More options */}
      <div className="relative">
        <button
          onClick={() => setShowMore(!showMore)}
          className="p-1.5 rounded-md text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          title="More options"
        >
          <MoreHorizontal className="w-4 h-4" />
        </button>
        
        {showMore && (
          <div className="absolute bottom-full left-0 mb-1 py-1 bg-slate-800 border border-white/20 rounded-lg shadow-xl min-w-[140px] z-10">
            <button 
              onClick={() => { handleCopy(); setShowMore(false); }}
              className="w-full px-3 py-1.5 text-left text-xs text-slate-300 hover:bg-white/10 flex items-center gap-2"
            >
              <Copy className="w-3.5 h-3.5" /> Copy text
            </button>
            <button 
              onClick={() => { handleShare(); setShowMore(false); }}
              className="w-full px-3 py-1.5 text-left text-xs text-slate-300 hover:bg-white/10 flex items-center gap-2"
            >
              <Share2 className="w-3.5 h-3.5" /> Share
            </button>
            <button 
              onClick={() => setShowMore(false)}
              className="w-full px-3 py-1.5 text-left text-xs text-slate-300 hover:bg-white/10 flex items-center gap-2"
            >
              <FileText className="w-3.5 h-3.5" /> View source
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// Component for displaying dual-language content side by side
function DualLanguageMessage({ content }: { content: DualLanguageContent }) {
  const [activeTab, setActiveTab] = useState<'translated' | 'japanese' | 'both'>('both');
  
  const languageNames: Record<string, string> = {
    en: 'English',
    ja: '日本語',
    ko: '한국어',
    zh: '中文',
  };

  const targetLangName = content.targetLanguage 
    ? languageNames[content.targetLanguage] || content.targetLanguage 
    : 'Translated';

  return (
    <div className="w-full">
      {/* Language tabs */}
      <div className="flex gap-1 mb-3 p-1 bg-white/5 rounded-lg w-fit">
        <button
          onClick={() => setActiveTab('both')}
          className={`px-3 py-1 text-xs rounded-md transition-colors ${
            activeTab === 'both' 
              ? 'bg-blue-600 text-white' 
              : 'text-slate-400 hover:text-white hover:bg-white/10'
          }`}
        >
          <Languages className="w-3 h-3 inline mr-1" />
          Both
        </button>
        <button
          onClick={() => setActiveTab('translated')}
          className={`px-3 py-1 text-xs rounded-md transition-colors ${
            activeTab === 'translated' 
              ? 'bg-blue-600 text-white' 
              : 'text-slate-400 hover:text-white hover:bg-white/10'
          }`}
        >
          {targetLangName}
        </button>
        <button
          onClick={() => setActiveTab('japanese')}
          className={`px-3 py-1 text-xs rounded-md transition-colors ${
            activeTab === 'japanese' 
              ? 'bg-blue-600 text-white' 
              : 'text-slate-400 hover:text-white hover:bg-white/10'
          }`}
        >
          日本語
        </button>
      </div>

      {/* Side by side display */}
      {activeTab === 'both' ? (
        <div className="grid grid-cols-2 gap-4">
          {/* Translated (User's language) */}
          <div className="p-3 rounded-lg bg-blue-900/20 border border-blue-500/30">
            <div className="flex items-center gap-2 mb-2 pb-2 border-b border-blue-500/20">
              <Globe className="w-4 h-4 text-blue-400" />
              <span className="text-xs font-medium text-blue-400">{targetLangName}</span>
            </div>
            <p className="text-sm leading-relaxed whitespace-pre-wrap text-white">
              {content.translated}
            </p>
          </div>
          
          {/* Japanese (Original) */}
          <div className="p-3 rounded-lg bg-emerald-900/20 border border-emerald-500/30">
            <div className="flex items-center gap-2 mb-2 pb-2 border-b border-emerald-500/20">
              <span className="text-xs font-medium text-emerald-400">🇯🇵 日本語 (Original)</span>
            </div>
            <p className="text-sm leading-relaxed whitespace-pre-wrap text-white">
              {content.japanese}
            </p>
          </div>
        </div>
      ) : activeTab === 'translated' ? (
        <p className="text-sm leading-relaxed whitespace-pre-wrap">
          {content.translated}
        </p>
      ) : (
        <p className="text-sm leading-relaxed whitespace-pre-wrap">
          {content.japanese}
        </p>
      )}
    </div>
  );
}

export default function ChatInterface({ onSaveToHistory }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: 'Hello! I\'m your HR Policy Assistant. I can help you with questions about company policies, benefits, leave, remote work, and more. You can ask in English or Japanese (日本語でも質問できます).',
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [chatList, setChatList] = useState<ChatTask[]>([]);
  const [currentChatId, setCurrentChatId] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [fieldSort, setFieldSort] = useState(0);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const pollingRef = useRef<NodeJS.Timeout | null>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Show toast notification
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type });
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Load chat list on mount
  useEffect(() => {
    loadChatList();
    return () => {
      if (pollingRef.current) {
        clearInterval(pollingRef.current);
      }
    };
  }, []);

  const loadChatList = async () => {
    try {
      const response = await listTask({ pageNum: 1, pageSize: 100 });
      if (response.code === 200 && response.result?.rows) {
        const chats = response.result.rows.map((task: any) => ({
          id: task.id,
          title: task.formData || task.form_data || 'New Chat',
          createdAt: task.createdAt,
        }));
        setChatList(chats);
      }
    } catch (error) {
      console.error('Failed to load chat list:', error);
    }
  };

  const loadChatMessages = async (taskId: string) => {
    try {
      const response = await listTaskOutput({ pageNum: 1, pageSize: 1000, taskId });
      if (response.code === 200 && response.result?.rows) {
        const loadedMessages: Message[] = [];
        let maxSort = 0;
        
        response.result.rows.forEach((output: TaskOutput) => {
          const metadata = JSON.parse(output.metadata || '{}');
          
          // User message
          if (metadata.prompt) {
            loadedMessages.push({
              id: `user-${output.id}`,
              type: 'user',
              content: metadata.prompt,
              timestamp: new Date(),
            });
          }
          
          // Bot message
          if (output.content) {
            loadedMessages.push({
              id: `bot-${output.id}`,
              type: 'bot',
              content: output.content,
              timestamp: new Date(),
              taskOutputId: output.id,
              status: output.status,
              feedback: output.feedback,
            });
          }
          
          if (output.sort > maxSort) {
            maxSort = output.sort;
          }
        });
        
        setMessages(loadedMessages.length > 0 ? loadedMessages : [{
          id: '1',
          type: 'bot',
          content: 'Hello! I\'m your HR Policy Assistant. How can I help you today?',
          timestamp: new Date(),
        }]);
        setFieldSort(maxSort);
      }
    } catch (error) {
      console.error('Failed to load messages:', error);
    }
  };

  const selectChat = (chatId: string) => {
    setCurrentChatId(chatId);
    loadChatMessages(chatId);
    setShowHistory(false);
  };

  const startNewChat = () => {
    setCurrentChatId(null);
    setMessages([{
      id: '1',
      type: 'bot',
      content: 'Hello! I\'m your HR Policy Assistant. How can I help you today?',
      timestamp: new Date(),
    }]);
    setFieldSort(0);
    setShowHistory(false);
  };

  const deleteChat = async (chatId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await deleteTaskOutput(chatId);
      setChatList(prev => prev.filter(chat => chat.id !== chatId));
      if (currentChatId === chatId) {
        startNewChat();
      }
    } catch (error) {
      console.error('Failed to delete chat:', error);
    }
  };

  const pollForResponse = useCallback((taskId: string, newFieldSort: number) => {
    let attempts = 0;
    const maxAttempts = 60;
    
    pollingRef.current = setInterval(async () => {
      attempts++;
      
      try {
        const response = await listTaskOutput({ pageNum: 1, pageSize: 1000, taskId });
        if (response.code === 200 && response.result?.rows) {
          const latestOutput = response.result.rows.find(
            (o: TaskOutput) => o.sort === newFieldSort || o.sort === newFieldSort + 1
          );
          
          if (latestOutput && latestOutput.content) {
            setMessages(prev => {
              const updated = [...prev];
              const lastIndex = updated.length - 1;
              if (updated[lastIndex]?.type === 'bot') {
                updated[lastIndex] = {
                  ...updated[lastIndex],
                  content: latestOutput.content,
                  status: latestOutput.status,
                  taskOutputId: latestOutput.id,
                };
              }
              return updated;
            });
            
            if (latestOutput.status === 'FINISHED' || latestOutput.status === 'FAILED') {
              setIsTyping(false);
              if (pollingRef.current) {
                clearInterval(pollingRef.current);
              }
              onSaveToHistory(input, latestOutput.content, { document: 'HR Policy', page: 1 });
            }
          }
        }
      } catch (error) {
        console.error('Polling error:', error);
      }
      
      if (attempts >= maxAttempts) {
        setIsTyping(false);
        if (pollingRef.current) {
          clearInterval(pollingRef.current);
        }
      }
    }, 1000);
  }, [input, onSaveToHistory]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: input,
      timestamp: new Date(),
    };

    const botPlaceholder: Message = {
      id: (Date.now() + 1).toString(),
      type: 'bot',
      content: '',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage, botPlaceholder]);
    const currentInput = input;
    setInput('');
    setIsTyping(true);

    try {
      let taskId = currentChatId;
      
      // Step 1: For new chats, first create an empty chat to get taskId
      if (!taskId) {
        const createResponse = await addTask({
          type: 'CHAT',
          formData: {}, // Empty formData creates new chat
        });
        
        if (createResponse.code === 200 && createResponse.result?.taskId) {
          taskId = createResponse.result.taskId;
          setCurrentChatId(taskId);
          setFieldSort(0);
        } else {
          throw new Error('Failed to create chat');
        }
      }

      const newFieldSort = fieldSort + 1;
      setFieldSort(newFieldSort);

      // Step 2: Send the actual message with taskId
      const response = await addTask({
        type: 'CHAT',
        formData: {
          prompt: currentInput,
          fieldSort: newFieldSort,
          fileId: [],
          allFileSearch: true,
          useMcp: false,
          taskId: taskId,
        },
      });

      if (response.code === 200 && response.result?.taskId) {
        const taskId = response.result.taskId;
        if (!currentChatId) {
          setCurrentChatId(taskId);
          loadChatList();
        }
        pollForResponse(taskId, newFieldSort);
      } else {
        setIsTyping(false);
        setMessages(prev => {
          const updated = [...prev];
          updated[updated.length - 1].content = 'Sorry, there was an error processing your request.';
          return updated;
        });
      }
    } catch (error) {
      console.error('Send error:', error);
      setIsTyping(false);
      setMessages(prev => {
        const updated = [...prev];
        updated[updated.length - 1].content = 'Sorry, there was an error connecting to the server.';
        return updated;
      });
    }
  };

  const handleFeedback = async (messageId: string, emoji: string, taskOutputId?: number) => {
    if (!taskOutputId) return;
    
    const message = messages.find(m => m.id === messageId);
    if (!message) return;

    try {
      await sendFeedbackToCache({
        taskOutputId,
        emoji,
        outputContent: message.content,
        question: '', // Could be improved to find the user question
      });
      
      setMessages(prev => prev.map(m => 
        m.id === messageId ? { ...m, feedback: { emoji } } : m
      ));
    } catch (error) {
      console.error('Feedback error:', error);
    }
  };

  // Stop generation
  const stopGeneration = () => {
    if (pollingRef.current) {
      clearInterval(pollingRef.current);
      pollingRef.current = null;
    }
    setIsTyping(false);
    setMessages(prev => {
      const updated = [...prev];
      const lastMsg = updated[updated.length - 1];
      if (lastMsg?.type === 'bot' && !lastMsg.content) {
        updated[updated.length - 1] = {
          ...lastMsg,
          content: '⏹️ Generation stopped by user.',
        };
      }
      return updated;
    });
    showToast('Generation stopped', 'info');
  };

  // Clear current chat
  const clearChat = () => {
    setMessages([{
      id: '1',
      type: 'bot',
      content: 'Chat cleared. How can I help you today?',
      timestamp: new Date(),
    }]);
    setCurrentChatId(null);
    setFieldSort(0);
    showToast('Chat cleared', 'success');
  };

  // Handle keyboard shortcuts
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    // Enter to send (without shift)
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
    // Escape to stop generation
    if (e.key === 'Escape' && isTyping) {
      stopGeneration();
    }
  };

  // Auto-resize textarea
  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    // Auto-resize
    e.target.style.height = 'auto';
    e.target.style.height = Math.min(e.target.scrollHeight, 150) + 'px';
  };

  return (
    <div className="flex h-full">
      {/* Toast notification */}
      {toast && (
        <Toast 
          message={toast.message} 
          type={toast.type} 
          onClose={() => setToast(null)} 
        />
      )}

      {/* Chat History Sidebar */}
      <div className={`${showHistory ? 'w-64' : 'w-0'} transition-all duration-300 overflow-hidden border-r border-white/10 bg-black/30`}>
        <div className="p-4 h-full flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-white">Chat History</h3>
            <button
              onClick={startNewChat}
              className="p-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors"
              title="New Chat"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto space-y-2">
            {chatList.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-4">No chat history</p>
            ) : (
              chatList.map((chat) => (
                <div
                  key={chat.id}
                  onClick={() => selectChat(chat.id)}
                  className={`p-3 rounded-lg cursor-pointer group transition-colors ${
                    currentChatId === chat.id
                      ? 'bg-blue-600/30 border border-blue-500/50'
                      : 'bg-white/5 hover:bg-white/10 border border-transparent'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                      <MessageSquare className="w-4 h-4 text-slate-400 flex-shrink-0" />
                      <span className="text-sm text-white truncate">{chat.title}</span>
                    </div>
                    <button
                      onClick={(e) => deleteChat(chat.id, e)}
                      className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-red-500/20 text-slate-400 hover:text-red-400 transition-all"
                      title="Delete chat"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex gap-3 ${
              message.type === 'user' ? 'flex-row-reverse' : 'flex-row'
            } animate-fadeIn`}
          >
            <div
              className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${
                message.type === 'user'
                  ? 'bg-gradient-to-br from-blue-500 to-purple-600'
                  : 'bg-gradient-to-br from-green-500 to-emerald-600'
              }`}
            >
              {message.type === 'user' ? (
                <User className="w-5 h-5 text-white" />
              ) : (
                <Bot className="w-5 h-5 text-white" />
              )}
            </div>

            <div
              className={`flex-1 max-w-[80%] ${
                message.type === 'user' ? 'items-end' : 'items-start'
              } flex flex-col gap-2`}
            >
              <div
                className={`px-4 py-3 rounded-2xl ${
                  message.type === 'user'
                    ? 'bg-blue-600 text-white'
                    : 'bg-white/10 text-white border border-white/20'
                }`}
              >
                {message.type === 'bot' && message.content ? (
                  (() => {
                    const parsed = parseDualLanguageContent(message.content);
                    if (parsed.isDualLanguage) {
                      return (
                        <>
                          <DualLanguageMessage content={parsed} />
                          <MessageActions 
                            content={message.content} 
                            messageId={message.id}
                            onFeedback={(id, fb) => {
                              const emoji = fb === 'like' ? '👍' : '👎';
                              handleFeedback(id, emoji, message.taskOutputId);
                              showToast(fb === 'like' ? 'Thanks for your feedback!' : 'We\'ll improve!', 'success');
                            }}
                            onRegenerate={() => {
                              showToast('Regenerate feature coming soon', 'info');
                            }}
                          />
                        </>
                      );
                    }
                    return (
                      <>
                        <p className="text-sm leading-relaxed whitespace-pre-wrap">
                          {message.content}
                        </p>
                        <MessageActions 
                          content={message.content} 
                          messageId={message.id}
                          onFeedback={(id, fb) => {
                            const emoji = fb === 'like' ? '👍' : '👎';
                            handleFeedback(id, emoji, message.taskOutputId);
                            showToast(fb === 'like' ? 'Thanks for your feedback!' : 'We\'ll improve!', 'success');
                          }}
                          onRegenerate={() => {
                            showToast('Regenerate feature coming soon', 'info');
                          }}
                        />
                      </>
                    );
                  })()
                ) : (
                  <p className="text-sm leading-relaxed whitespace-pre-wrap">
                    {message.content}
                  </p>
                )}
              </div>

              {message.source && (
                <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 rounded-lg text-xs text-slate-300 border border-white/10">
                  <FileText className="w-3.5 h-3.5" />
                  <span>
                    {message.source.document} • Page {message.source.page}
                  </span>
                  <Globe className="w-3.5 h-3.5 ml-1" />
                  <span>{message.source.language}</span>
                </div>
              )}

              <span className="text-xs text-slate-400 px-2">
                {message.timestamp.toLocaleTimeString()}
              </span>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex gap-3 animate-fadeIn">
            <div className="flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center bg-gradient-to-br from-green-500 to-emerald-600">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div className="px-4 py-3 rounded-2xl bg-white/10 border border-white/20">
              <div className="flex gap-1">
                <div
                  className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"
                  style={{ animationDelay: '0ms' }}
                />
                <div
                  className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"
                  style={{ animationDelay: '150ms' }}
                />
                <div
                  className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"
                  style={{ animationDelay: '300ms' }}
                />
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 border-t border-white/10 bg-black/20">
        {/* Action buttons */}
        <div className="flex items-center gap-2 mb-3">
          <button
            onClick={() => setShowHistory(!showHistory)}
            className={`p-2 rounded-lg transition-colors ${
              showHistory ? 'bg-blue-600 text-white' : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'
            }`}
            title="Toggle chat history"
          >
            <MessageSquare className="w-4 h-4" />
          </button>
          <button
            onClick={startNewChat}
            className="p-2 rounded-lg bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white transition-colors"
            title="New chat"
          >
            <Plus className="w-4 h-4" />
          </button>
          <button
            onClick={clearChat}
            className="p-2 rounded-lg bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white transition-colors"
            title="Clear chat"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          {isTyping && (
            <button
              onClick={stopGeneration}
              className="p-2 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors flex items-center gap-1"
              title="Stop generation (Esc)"
            >
              <StopCircle className="w-4 h-4" />
              <span className="text-xs">Stop</span>
            </button>
          )}
          <div className="flex-1" />
          <span className="text-xs text-slate-500">
            {input.length > 0 && `${input.length} chars`}
          </span>
        </div>

        {/* Input field */}
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <textarea
              ref={inputRef}
              value={input}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder="Ask about HR policies in English or Japanese... (Enter to send, Shift+Enter for new line)"
              rows={1}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              style={{ minHeight: '48px', maxHeight: '150px' }}
            />
          </div>
          <button
            onClick={handleSend}
            disabled={!input.trim() || isTyping}
            className="px-6 py-3 h-fit bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 disabled:cursor-not-allowed text-white rounded-xl transition-colors flex items-center gap-2 self-end"
          >
            <Send className="w-5 h-5" />
            <span className="hidden sm:inline">Send</span>
          </button>
        </div>

        {/* Keyboard hints */}
        <div className="flex items-center gap-4 mt-2 text-xs text-slate-500">
          <span><kbd className="px-1 py-0.5 bg-white/10 rounded text-[10px]">Enter</kbd> to send</span>
          <span><kbd className="px-1 py-0.5 bg-white/10 rounded text-[10px]">Shift+Enter</kbd> new line</span>
          {isTyping && <span><kbd className="px-1 py-0.5 bg-white/10 rounded text-[10px]">Esc</kbd> stop</span>}
        </div>
      </div>
      </div>

      <style>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateX(20px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
        .animate-fadeIn {
          animation: fadeIn 0.3s ease-out;
        }
        .animate-slideIn {
          animation: slideIn 0.3s ease-out;
        }
      `}</style>
    </div>
  );
}
