import { getMCPManager } from '@/core/mcpManager';
import File from '@/mysql/model/file.model';
import KrdGenTask from '@/mysql/model/gen_task.model';
import KrdGenTaskOutput from '@/mysql/model/gen_task_output.model';
import { IGenTaskOutputSer } from '@/types/genTaskOutput';
import { IGenTaskSer } from '@/types/genTask';
import { extractToolCallsFromText } from '@/utils/text';
import { config } from '@config/index'
import dns from 'node:dns';
import OpenAI from 'openai';
import { Op } from 'sequelize';
import { execute } from '../service/task.dispatch';
import { put, queryList } from '../utils/mapper';
import { getNextApiUrl } from '../utils/redis';
import { loadRagProcessor } from '@/service/loadRagProcessor';
import { loadCacheProcessor } from '@/service/loadCacheProcessor';
import {
  detectLanguage,
  translateQueryToJapanese,
  createDualLanguageResponse,
  formatDualLanguageOutput,
  LanguageCode,
} from '@/utils/translation';

dns.setDefaultResultOrder('ipv4first');

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || '',
});

const callLLM = async (messages: any[], temperature = 0.5, outputId?: number): Promise<string> => {
  if (outputId) {
    const url = await getNextApiUrl('ollama');
    const response = await fetch(`${url}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stream: true, model: config.Models.chatModel.name, messages, options: { temperature, repeat_penalty: 1.5 } }),
    });
    const reader = response.body!.getReader();
    const decoder = new TextDecoder();
    let content = '';
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      let [curOutput] = await queryList(KrdGenTaskOutput, { id: { [Op.eq]: outputId } });
      if (!curOutput) {
        console.error(`Output with ID ${outputId} not found.`);
        break;
      }
      if (curOutput.status === 'CANCEL') {
        await reader.cancel().catch(() => { });
        await put<IGenTaskOutputSer>(
          KrdGenTaskOutput,
          { id: outputId },
          {
            // content: '',
            status: 'CANCEL',
            update_by: 'JOB',
          },
        );
        break;
      }

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop()!;

      for (const line of lines) {
        [curOutput] = await queryList(KrdGenTaskOutput, { id: { [Op.eq]: outputId } });
        if (curOutput.status === 'CANCEL') {
          await reader.cancel().catch(() => { });
          content = '';
          await put<IGenTaskOutputSer>(
            KrdGenTaskOutput,
            { id: outputId },
            { content, status: 'CANCEL', update_by: 'JOB' },
          );
          break; // forループを抜ける
        }
        if (!line.trim()) continue;
        try {
          const pkg = JSON.parse(line);
          const chunkText = pkg.message?.content || '';
          content += chunkText;

          await put<IGenTaskOutputSer>(
            KrdGenTaskOutput,
            {
              id: outputId,
              status: { [Op.ne]: 'CANCEL' },
            },
            {
              content,
              status: 'PROCESSING',
              update_by: 'JOB',
            },
          );
        } catch (e) {
          console.error('LLM ストリーム解析エラー:', e);
        }
      }
      if (curOutput.status === 'CANCEL') break;
    }
    if (buffer.trim()) {
      try {
        const pkg = JSON.parse(buffer);
        const chunkText = pkg.message?.content || '';
        content += chunkText;
      } catch (e) {
        console.error('LLM ストリーム解析エラー:', e);
      }
    }

    return content || '';
  } else {
    const url = await getNextApiUrl('ollama');
    const response = await fetch(`${url}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stream: false, model: config.Models.chatModel.name, messages, options: { temperature } }),
    });
    const res = await response.json();
    return res.message?.content || '';
  }
};

export async function generateWithMCPWithoutToolcalling(prompt: string): Promise<string> {
  const mcpManager = getMCPManager();
  await mcpManager.connectAll();
  const client = mcpManager.getClient();

  const tools = await Promise.all(
    client.getActiveSessions().map(async name => {
      const toolList = await client.listTools(name);
      return toolList.map(tool => ({
        name: `${name}__${tool.name}`,
        description: `[${name}] ${tool.description}`,
        parameters: tool.inputSchema,
      }));
    })
  );
  const flatTools = tools.flat();

  const toolListString = flatTools
    .map(t => `- ${t.name}: ${t.description}`)
    .join('\n');

  const messages = [
    {
      role: 'system',
      content:
        'あなたはツール選定専門家です。ユーザーの質問に対して、適切なツールを以下のリストから選び、次のフォーマットで出力してください：\n\nTOOL: tool_name(arg1=..., arg2=...)\n\n使用可能ツール：\n' +
        toolListString,
    },
    { role: 'user', content: prompt },
  ];

  const response = await callLLM(
    messages, 0.3
  );

  const text = response ?? '';
  const toolCalls = extractToolCallsFromText(text);

  const results: string[] = [];
  for (const call of toolCalls) {
    const [server, tool] = call.name.split('__');
    const result = await client.callTool(server, tool, call.args);
    results.push(`[${call.name}]: ${JSON.stringify(result.content)}`);
  }

  const summaryMessages = [
    {
      role: 'system',
      content: 'あなたはAIアシスタントです。以下の質問とツール結果に基づき、簡潔な日本語で回答してください。',
    },
    { role: 'user', content: `質問: ${prompt}` },
    results.length > 0 ? { role: 'assistant', content: `TOOL実行結果:\n${results.join('\n')}` } : undefined,
  ];

  const summary = await callLLM(
    summaryMessages,
    0.3,
  );

  return summary ?? '[回答失敗]';
}

export async function generateWithMCP(prompt: string): Promise<string> {
  const mcpManager = getMCPManager();
  await mcpManager.connectAll();
  const client = mcpManager.getClient();

  const tools = await Promise.all(
    client.getActiveSessions().map(async name => {
      const t = await client.listTools(name);
      return t.map(tool => ({
        type: "function" as const,
        function: {
          name: `${name}__${tool.name}`,
          description: `[${name}] ${tool.description}`,
          parameters: tool.inputSchema
        }
      }));
    })
  );

  const flatTools = tools.flat();

  const messages = [
    {
      role: 'system',
      content: 'あなたはAIアシスタントです。以下の質問とツール結果を元に、正確で簡潔な日本語の回答を作成してください。',
    },
    { role: "user", content: prompt }
  ];


  const model = process.env.LLM_MODEL || 'gpt-4-turbo';

  let response = await openai.chat.completions.create({
    model,
    messages: messages as OpenAI.ChatCompletionMessageParam[],
    tools: flatTools,
    tool_choice: "auto"
  });

  const msg = response.choices?.[0]?.message;
  const responses: string[] = [];

  if (msg?.tool_calls) {
    for (const call of msg.tool_calls) {
      const [server, tool] = call.function.name.split("__");
      const args = JSON.parse(call.function.arguments);
      const result = await client.callTool(server, tool, args);
      responses.push(result.content);
    }
  } else if (msg?.content) {
    responses.push(msg.content);
  }

  return responses.join('\n');

}



export async function createChatTitle(prompt: string, content: string): Promise<string> {
  try {
    const message = `
Please summarize the following conversation (question and answer) into a Japanese chat title of about 15 characters.
Output only the title—no explanation or extra text.

Conversation:
Q: 【${prompt}】
A: 【${content}】
`;

    const url = await getNextApiUrl('ollama');
    const response = await fetch(`${url}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        stream: false,
        model: config.Models.chatTitleGenModel.name,
        prompt: message,
        options: {
          temperature: config.Models.chatTitleGenModel.temperature ?? 0.8,
          repeat_penalty: config.Models.chatTitleGenModel.repeat_penalty ?? 1.5
        }
      }),
    });
    const data = await response.json();

    return data.response;
  } catch (error) {
    console.error(error);
    return "空のチャットタイトル";
  }
}

const generateWithLLM = async (messages: any[], outputId: number) => {
  try {
    return await callLLM(messages, 0.1, outputId);
  } catch (error) {
    console.error('LLM 呼び出し失敗:', error);
    return 'error happen';
  }
};

const chatGenProcess = async (job) => {
  const { taskId } = job.data;
  const type = 'CHAT';
  // const mode: string = (config.RAG.mode || ['splitByPage'])[0];
  const mode: string = (config.RAG.mode || ['splitByPage'])[0];
  const useFaqCache: boolean = config.RAG.useFaqCache || false;
  const ragProcessor = await loadRagProcessor(mode);
  const cacheProcessor = await loadCacheProcessor(useFaqCache);

  const callAviary = async (outputId: number, metadata: string) => {
    let [curOutput] = await queryList(KrdGenTaskOutput, { id: { [Op.eq]: outputId } });
    if (curOutput.status === 'CANCEL') return { outputId, isOk: false, content: '' };

    const outputs = await queryList(KrdGenTaskOutput, {
      task_id: { [Op.eq]: taskId },
      status: { [Op.ne]: 'IN_PROCESS' },
    });

    const messages = outputs.flatMap((op) => [
      { role: 'user', content: op.metadata },
      ...(op.content ? [{ role: 'assistant', content: op.content }] : []),
    ]);

    const data = JSON.parse(metadata);

    let storage_keyArray = [];
    let fileNames = [];
    if (data.fileId !== 0) {
      for (const id of data.fileId) {
        const [file] = await queryList(File, { id: { [Op.eq]: id } });
        storage_keyArray.push(file.storage_key);
      }
    }

    [curOutput] = await queryList(KrdGenTaskOutput, { id: { [Op.eq]: outputId } });
    if (curOutput.status === 'CANCEL') return { outputId, isOk: false, content: '' };

    let prompt = data.prompt;
    
    // Step 1: Detect user's language and translate query to Japanese if needed
    const userLanguage = detectLanguage(data.prompt);
    let japaneseQuery = data.prompt;
    
    if (userLanguage !== 'ja') {
      try {
        const translation = await translateQueryToJapanese(data.prompt);
        japaneseQuery = translation.translatedQuery;
        console.log(`[Translation] User language: ${userLanguage}, translated query to JP`);
      } catch (e) {
        console.error('Query translation failed:', e);
        // Continue with original query if translation fails
      }
    }

    let content = '',
      isOk = true;
    let japaneseAnswer = ''; // Store Japanese answer for dual-output
    
    if (data.useMcp === true) {
      try {
        japaneseAnswer = await generateWithMCPWithoutToolcalling(japaneseQuery);
        content = japaneseAnswer;
      } catch (e) {
        console.error('MCP呼び出し失敗:', e);
        content = 'error happen';
        isOk = false;
      }
    } else {
      if (data.allFileSearch === true) {
        try {
          [curOutput] = await queryList(KrdGenTaskOutput, { id: { [Op.eq]: outputId } });
          if (curOutput.status === 'CANCEL') return { outputId, isOk: false, content: '' };

          // Step 2: RAG search with Japanese query
          if (useFaqCache) {
            try {
              prompt = await cacheProcessor.search(japaneseQuery);
            } catch (e) {
              console.error("cache error :", e)
              prompt = "faq_cache_error";
            }
          }
          if (!useFaqCache || ["faq_cache_miss", "faq_cache_error"].includes(prompt)) {
            prompt = await ragProcessor.search(japaneseQuery);
          }

          [curOutput] = await queryList(KrdGenTaskOutput, { id: { [Op.eq]: outputId } });
          if (curOutput.status === 'CANCEL') return { outputId, isOk: false, content: '' };
        } catch (e) {
          console.error('全ファイル検索呼び出し失敗:', e);
          content = 'error happen';
        }
      }
      if (content !== "error happen") {
        messages.push({ role: 'user', content: prompt });

        [curOutput] = await queryList(KrdGenTaskOutput, { id: { [Op.eq]: outputId } });
        if (curOutput.status === 'CANCEL') return { outputId, isOk: false, content: '' };

        // Step 3: Generate answer in Japanese
        japaneseAnswer = await generateWithLLM(messages, outputId);
        content = japaneseAnswer;

        if (outputs.length === 0) {
          const chatTitle = await createChatTitle(prompt, japaneseAnswer);

          await put<IGenTaskSer>(KrdGenTask, { id: taskId }, {
            form_data: chatTitle,
            update_by: 'JOB',
          });
        }
      }
      isOk = content !== 'error happen';

      if (config.APP_MODE === 'rag-evaluation') {
        content = prompt + "\n\n## LLM からの回答\n\n" + content;
      }
    }
    
    // Step 4: Create dual-language output if user language is not Japanese
    if (isOk && userLanguage !== 'ja' && japaneseAnswer) {
      try {
        const dualResponse = await createDualLanguageResponse(japaneseAnswer, userLanguage);
        content = formatDualLanguageOutput(
          dualResponse.japanese,
          dualResponse.translated,
          userLanguage
        );
        console.log(`[Translation] Created dual-language response for ${userLanguage}`);
      } catch (e) {
        console.error('Dual-language output creation failed:', e);
        // Keep original Japanese content if translation fails
      }
    }

    [curOutput] = await queryList(KrdGenTaskOutput, { id: { [Op.eq]: outputId } });
    if (curOutput.status === 'CANCEL') return { outputId, isOk: false, content: '' };

    await put<IGenTaskOutputSer>(
      KrdGenTaskOutput,
      { id: outputId },
      {
        content,
        status: isOk ? 'FINISHED' : 'FAILED',
        update_by: 'JOB',
      },
    );

    return { outputId, isOk, content };
  };

  await execute(type, taskId, callAviary);
};

export default chatGenProcess;
