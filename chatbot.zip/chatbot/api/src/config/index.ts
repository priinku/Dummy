import fs from "node:fs";
import path from "node:path";
import YAML from "yaml";
import { AppConfigSchema, type AppConfig } from "./schema";

const projectRootDir = path.resolve(__dirname, "../../../");
const configFilePath = path.join(projectRootDir, "config/default.yml");

function readYamlIfExists(filePath: string) {
  if (!fs.existsSync(filePath)) return {};
  const content = fs.readFileSync(filePath, "utf8");
  return YAML.parse(content) ?? {};
}

function validateConfig(config: any): config is AppConfig {
  return AppConfigSchema.safeParse(config).success;
}

function fillProjectRootDirTags(config: AppConfig): AppConfig {
    const jsonStr = JSON.stringify(config);
    const replacedStr = jsonStr.replace(/<PROJECT_ROOT_DIR>/g, projectRootDir.replace(/\\/g, "/"));
    return JSON.parse(replacedStr);
}

function checkUploadDirs(config: AppConfig): void {
  const { rootDir, filesDir } = config.RAG.Uploads;
  if (!fs.existsSync(rootDir)) {
    fs.mkdirSync(rootDir, { recursive: true });
  }
  if (!fs.existsSync(filesDir)) {
    fs.mkdirSync(filesDir, { recursive: true });
  }
}

function loadConfig(): AppConfig {
  const config = readYamlIfExists(configFilePath);
  if (!validateConfig(config)) {
    throw new Error("Invalid config, please check the configuration file.");
  }
  return fillProjectRootDirTags(config);
}

const parsedConfig = loadConfig();
checkUploadDirs(parsedConfig);

export const config: Readonly<AppConfig> = Object.freeze(parsedConfig);
