import { put, queryPage } from '@/utils/mapper';

import KrdGenTask from '@/mysql/model/gen_task.model';
import KrdGenTaskOutput from '@/mysql/model/gen_task_output.model';
import { userType } from '@/types';
import { IGenTask, IGenTaskQuerySerType, IGenTaskQueryType, IGenTaskSer } from '@/types/genTask';
import { IGenTaskOutputQuerySerType, IGenTaskOutputQueryType, IGenTaskOutputReNameSer, IGenTaskOutputSer } from '@/types/genTaskOutput';
import { Context } from 'koa';
import { Op } from 'sequelize';

import { queryConditionsData } from '@/service';
import { handleAddGenTask } from '@/service/genTaskService';

export const getAddMid = async (ctx: Context, next: () => Promise<void>) => {
  try {
    const { userName } = ctx.state.user as userType;
    const addContent = ctx.request.body as IGenTask;

    const result = await handleAddGenTask(addContent, userName);

    ctx.state.formatData = {
      taskId: result.taskId,
      task: result.task,
    };

    await next();
  } catch (error) {
    console.error(error);
    return ctx.app.emit(
      'error',
      {
        code: '400',
        message: 'アップロードパラメータを確認してください',
      },
      ctx,
    );
  }
};

export const getListMid = async (ctx: Context, next: () => Promise<void>) => {
  try {
    const { userName } = ctx.state.user as userType;
    const { pageNum, pageSize, ...params } = ctx.query as unknown as IGenTaskQueryType;
    const newParams = { pageNum, pageSize } as IGenTaskQuerySerType;

    if (userName) newParams.create_By = userName;
    if (params.type) newParams.type = params.type;
    if (params.status) newParams.status = params.status;

    const res = await queryPage<IGenTaskQuerySerType>(KrdGenTask, newParams);

    ctx.state.formatData = res;
    await next();
  } catch (error) {
    console.error(error);
    return ctx.app.emit(
      'error',
      {
        code: '500',
        message: 'リストの取得に失敗しました',
      },
      ctx,
    );
  }
};

export const getOutputListMid = async (ctx: Context, next: () => Promise<void>) => {
  try {
    const { pageNum, pageSize, ...params } = ctx.query as unknown as IGenTaskOutputQueryType;
    const newParams = { pageNum, pageSize } as IGenTaskOutputQuerySerType;
    if (params.taskId) newParams.task_id = params.taskId;
    if (params.status) newParams.status = params.status;
    if (params.sort) newParams.sort = params.sort;

    const res = await queryPage<IGenTaskOutputQuerySerType>(KrdGenTaskOutput, newParams);

    ctx.state.formatData = res;
    await next();
  } catch (error) {
    console.error(error);
    return ctx.app.emit(
      'error',
      {
        code: '500',
        message: 'リストの取得に失敗しました',
      },
      ctx,
    );
  }
};

export const updateTaskOutputMid = async (ctx: Context, next: () => Promise<void>) => {
  const { userName } = ctx.state.user as userType;
  const { taskOutputId } = ctx.params;
  const { status, metadata, feedback, content } = ctx.request.body;

  await put<IGenTaskOutputSer>(KrdGenTaskOutput, { id: taskOutputId }, {
    status,
    metadata,
    feedback,
    content,
    update_by: userName,
  } as IGenTaskOutputSer);

  await next();
};

export const reNameTaskOutputMid = async (ctx: Context, next: () => Promise<void>) => {
  const { userName } = ctx.state.user as userType;
  const { taskId } = ctx.params;
  const { newName } = ctx.request.body;

  await put<IGenTaskOutputReNameSer>(KrdGenTask, { id: taskId }, {
    form_data: newName,
    update_by: userName,
  } as IGenTaskOutputReNameSer);

  await next();
};

export const deleteTaskOutputMid = async (ctx: Context, next: () => Promise<void>) => {
  const { taskId } = ctx.params;

  await KrdGenTask.destroy({
    where: { id: taskId },
  });

  await KrdGenTaskOutput.destroy({
    where: { task_id: taskId },
  });

  await next();
};

export const stopTaskOutputMid = async (ctx: Context, next: () => Promise<void>) => {
  try {
    const { taskId, fieldSort } = ctx.query;
    const { userName } = ctx.state.user as userType;


    const outputData = await queryConditionsData(KrdGenTaskOutput, {
      task_id: taskId,
      sort: fieldSort,
      status: { [Op.in]: ['IN_PROCESS', 'PROCESSING', 'WAIT'] },
    });

    if (outputData && outputData.length > 0) {
      await put<IGenTaskOutputSer>(
        KrdGenTaskOutput,
        {
          task_id: taskId,
          sort: fieldSort,
          status: { [Op.in]: ['IN_PROCESS', 'PROCESSING', 'WAIT'] },
        },
        {
          // content: 'CANCEL',
          status: 'CANCEL',
          update_by: userName,
        },
      );

      const outputs = await queryConditionsData(KrdGenTaskOutput, {
        task_id: outputData[0].task_id,
        status: { [Op.in]: ['IN_PROCESS', 'PROCESSING', 'WAIT'] },
      });

      if (!outputs || outputs.length === 0) {
        await put<IGenTaskSer>(KrdGenTask, { id: outputData[0].task_id }, { status: 'FINISHED', update_by: userName });
      }
    }
  } catch (error) {
    console.error('Error in stopTaskOutputMid:', error);
  }

  await next();
};

export const getChatTitleMid = async (ctx: Context, next: () => Promise<void>) => {
  const { userName } = ctx.state.user as userType;
  const { chatId } = ctx.query;
  const newParams = { id: chatId, pageNum: 1, pageSize: 1, create_By: userName } as IGenTaskQuerySerType;

  try {
    const res = await queryPage<IGenTaskQuerySerType>(KrdGenTask, newParams);
    ctx.state.formatData = res;
    await next();
  } catch (error) {
    console.error(error);
    return ctx.app.emit(
      'error',
      {
        code: '500',
        message: 'リストの取得に失敗しました',
      },
      ctx,
    );
  }
}

export const sendFeedbackToCache = async (ctx: Context, next: () => Promise<void>) => {
  try {
    const { userName } = ctx.state.user as userType;
    const { taskOutputId: rawTaskOutputId, cache_signal, query, answer } = ctx.request.body as {
      taskOutputId: number;
      cache_signal: number;
      query: string;
      answer: string;
    };

    // Convert taskOutputId to string if it's a number
    const taskOutputId = String(rawTaskOutputId);

    console.log(`[FEEDBACK] User ${userName} sending feedback: signal=${cache_signal}, taskOutputId=${taskOutputId}`);
    console.log(`[FEEDBACK] Query: ${query?.substring(0, 50)}...`);
    console.log(`[FEEDBACK] Answer: ${answer?.substring(0, 50)}...`);

    // Validate input
    if (cache_signal !== 0 && cache_signal !== 1) {
      return ctx.app.emit('error', {
        code: '400',
        message: 'cache_signal must be 0 or 1',
      }, ctx);
    }

    if (!query || !answer) {
      return ctx.app.emit('error', {
        code: '400',
        message: 'query and answer are required',
      }, ctx);
    }

    // Prepare feedback data for FAQ cache service
    const feedbackData = {
      cache_signal: cache_signal,
      query: query,
      answer: answer,
    };

    // Send to FAQ cache service (port 8001)
    const faqCacheUrl = process.env.FAQ_CACHE_URL || 'http://localhost:8001';
    const response = await fetch(`${faqCacheUrl}/feedback`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(feedbackData),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`[FEEDBACK] FAQ cache service error: ${response.status} - ${errorText}`);
      return ctx.app.emit('error', {
        code: '500',
        message: `FAQ cache service error: ${response.status}`,
      }, ctx);
    }

    const result = await response.json();

    console.log(`[FEEDBACK] FAQ cache response:`, result);

    // Return success response
    ctx.state.formatData = {
      success: true,
      message: result.message || 'Feedback sent successfully',
      action_taken: result.action_taken,
      cache_signal: cache_signal,
      taskOutputId: taskOutputId,
      faq_cache_response: result,
    };

    await next();
  } catch (error) {
    console.error('[FEEDBACK] Error sending feedback to cache:', error);
    return ctx.app.emit('error', {
      code: '500',
      message: `Failed to send feedback: ${error.message}`,
    }, ctx);
  }
};
