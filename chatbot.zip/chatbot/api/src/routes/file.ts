import IndexCon from '@/controller';
import { deleteFile, listFiles, uploadFile, updateFileInfo, addNewTag, editTag, deleteTag, listTags, previewFile, downloadFile, extractTextFromFile} from '@/controller/file';
import Router from 'koa-router';

const router = new Router({ prefix: '/api/files' });

router.post('/upload', uploadFile, IndexCon());

router.get('/', listFiles, IndexCon());

router.delete('/delete', deleteFile, IndexCon());

router.put('/', updateFileInfo, IndexCon());

router.post('/addNewTag', addNewTag, IndexCon());

router.put('/editTag', editTag, IndexCon());

router.delete('/:id', deleteTag, IndexCon());

router.get('/tags', listTags, IndexCon());

router.post('/extract-text', extractTextFromFile, IndexCon());

router.get('/preview/:storage_key', previewFile);

router.get('/download/:storage_key', downloadFile);

export default router;
