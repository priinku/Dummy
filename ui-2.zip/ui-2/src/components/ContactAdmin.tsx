import { useState } from 'react';
import { X, Send, MessageCircle, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { createSupportTicket, getMyTickets } from '../api/support';

interface ContactAdminProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Ticket {
  id: number;
  subject: string;
  message: string;
  status: string;
  admin_reply?: string;
  created_at: string;
  replied_at?: string;
}

export default function ContactAdmin({ isOpen, onClose }: ContactAdminProps) {
  const [activeTab, setActiveTab] = useState<'new' | 'history'>('new');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const loadTickets = async () => {
    setLoading(true);
    try {
      const response = await getMyTickets({ pageNum: 1, pageSize: 50 });
      if (response.code === 200 && response.result?.rows) {
        setTickets(response.result.rows);
      }
    } catch (err) {
      console.error('Failed to load tickets:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !message.trim()) {
      setError('Please fill in both subject and message');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      const response = await createSupportTicket({ subject, message });
      if (response.code === 200) {
        setSubmitSuccess(true);
        setSubject('');
        setMessage('');
        setTimeout(() => setSubmitSuccess(false), 3000);
        loadTickets(); // Refresh tickets
      } else {
        setError(response.message || 'Failed to submit');
      }
    } catch (err) {
      setError('Failed to submit. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleTabChange = (tab: 'new' | 'history') => {
    setActiveTab(tab);
    if (tab === 'history') {
      loadTickets();
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'open':
        return <Clock className="w-4 h-4 text-yellow-400" />;
      case 'in_progress':
        return <AlertCircle className="w-4 h-4 text-blue-400" />;
      case 'resolved':
        return <CheckCircle className="w-4 h-4 text-green-400" />;
      default:
        return <Clock className="w-4 h-4 text-slate-400" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'open':
        return 'Pending';
      case 'in_progress':
        return 'In Progress';
      case 'resolved':
        return 'Resolved';
      case 'closed':
        return 'Closed';
      default:
        return status;
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-slate-800 rounded-xl w-full max-w-lg mx-4 border border-white/20 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-white/10">
          <div className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-semibold text-white">Contact Admin</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-white/10">
          <button
            onClick={() => handleTabChange('new')}
            className={`flex-1 py-3 text-sm font-medium transition-colors ${
              activeTab === 'new'
                ? 'text-blue-400 border-b-2 border-blue-400'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            New Query
          </button>
          <button
            onClick={() => handleTabChange('history')}
            className={`flex-1 py-3 text-sm font-medium transition-colors ${
              activeTab === 'history'
                ? 'text-blue-400 border-b-2 border-blue-400'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            My Queries
          </button>
        </div>

        {/* Content */}
        <div className="p-4">
          {activeTab === 'new' ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              {submitSuccess && (
                <div className="p-3 rounded-lg bg-green-500/20 border border-green-500/50 text-green-300 text-sm flex items-center gap-2">
                  <CheckCircle className="w-4 h-4" />
                  Your query has been submitted. Admin will respond soon.
                </div>
              )}
              
              {error && (
                <div className="p-3 rounded-lg bg-red-500/20 border border-red-500/50 text-red-300 text-sm">
                  {error}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Subject
                </label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Brief description of your query"
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Message
                </label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Describe your issue or question in detail..."
                  rows={4}
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-600/50 disabled:cursor-not-allowed text-white rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    Submit Query
                  </>
                )}
              </button>
            </form>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {loading ? (
                <div className="text-center py-8 text-slate-400">
                  <div className="w-6 h-6 border-2 border-blue-400/30 border-t-blue-400 rounded-full animate-spin mx-auto mb-2" />
                  Loading...
                </div>
              ) : tickets.length === 0 ? (
                <div className="text-center py-8 text-slate-400">
                  No queries yet
                </div>
              ) : (
                tickets.map((ticket) => (
                  <div
                    key={ticket.id}
                    className="p-3 rounded-lg bg-white/5 border border-white/10"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-medium text-white text-sm">{ticket.subject}</h4>
                      <div className="flex items-center gap-1 text-xs">
                        {getStatusIcon(ticket.status)}
                        <span className="text-slate-400">{getStatusText(ticket.status)}</span>
                      </div>
                    </div>
                    <p className="text-sm text-slate-300 mb-2">{ticket.message}</p>
                    
                    {ticket.admin_reply && (
                      <div className="mt-2 p-2 rounded bg-blue-500/10 border border-blue-500/30">
                        <p className="text-xs text-blue-400 mb-1">Admin Reply:</p>
                        <p className="text-sm text-white">{ticket.admin_reply}</p>
                      </div>
                    )}
                    
                    <p className="text-xs text-slate-500 mt-2">
                      {new Date(ticket.created_at).toLocaleDateString()}
                    </p>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
