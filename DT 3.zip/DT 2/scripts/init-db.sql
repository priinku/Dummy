-- Initialize Chatbot Database
-- PostgreSQL with pgvector extension

-- Create pgvector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Create web_pages table for scraped content
CREATE TABLE IF NOT EXISTS web_pages (
    id SERIAL PRIMARY KEY,
    url VARCHAR(2048) UNIQUE NOT NULL,
    title VARCHAR(512),
    content TEXT NOT NULL,
    scraped_at TIMESTAMP DEFAULT NOW(),
    extra_data JSONB DEFAULT '{}'
);

-- Create documents table with vector support for chunks
CREATE TABLE IF NOT EXISTS documents (
    id SERIAL PRIMARY KEY,
    source_url VARCHAR(2048) NOT NULL,
    title VARCHAR(512),
    content TEXT NOT NULL,
    chunk_index INTEGER DEFAULT 0,
    embedding vector(768),  -- nomic-embed-text dimension
    created_at TIMESTAMP DEFAULT NOW(),
    extra_data JSONB DEFAULT '{}'
);

-- Create index for vector similarity search (cosine distance)
CREATE INDEX IF NOT EXISTS idx_documents_embedding 
ON documents USING ivfflat (embedding vector_cosine_ops) 
WITH (lists = 100);

-- Create index on source_url for lookups
CREATE INDEX IF NOT EXISTS idx_documents_source_url 
ON documents (source_url);

-- Create chat_history table
CREATE TABLE IF NOT EXISTS chat_history (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(64) NOT NULL,
    query TEXT NOT NULL,
    response TEXT NOT NULL,
    sources JSONB DEFAULT '[]',
    confidence FLOAT DEFAULT 0.0,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Create index on session_id for history lookups
CREATE INDEX IF NOT EXISTS idx_chat_history_session 
ON chat_history (session_id);

-- Create index on created_at for time-based queries
CREATE INDEX IF NOT EXISTS idx_chat_history_created 
ON chat_history (created_at DESC);
