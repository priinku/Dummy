# Chatbot

A RAG-based chatbot that scrapes web pages, stores content in PostgreSQL with pgvector, and answers questions using Ollama LLMs.

## Features

- **Web Scraping**: Scrape web pages and extract text content
- **Vector Search**: Store embeddings in pgvector for semantic search
- **RAG Pipeline**: Retrieve relevant context and generate responses with LLM
- **Simple API**: Clean REST API for chat and scraping operations

## Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Sample Pages  │───▶│  Web Scraper    │───▶│   PostgreSQL    │
│   (Content)     │    │  (Extract Text) │    │   + pgvector    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                                      │
                                                      ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   User Query    │───▶│  Chatbot API    │───▶│     Ollama      │
│                 │    │  (RAG Service)  │    │   (LLM + Embed) │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## Quick Start (One-Click)

### Prerequisites

1. **Docker** - For PostgreSQL with pgvector
2. **Python 3.10+** - For the API
3. **Ollama** - For LLM and embeddings

### Step 1: Install and Start Ollama

```bash
# Install Ollama (macOS)
brew install ollama

# Start Ollama service
ollama serve

# Pull required models (in another terminal)
ollama pull llama3.2
ollama pull nomic-embed-text
```

### Step 2: Run the Application

```bash
# Single command to start everything
./start.sh
```

This script will:
1. ✅ Verify Ollama is running
2. ✅ Start PostgreSQL with pgvector (Docker)
3. ✅ Start the Sample Pages server
4. ✅ Install Python dependencies
5. ✅ Start the Chatbot API
6. ✅ Scrape sample pages and generate embeddings

### Step 3: Test the Chatbot

```bash
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"query": "What are the health insurance options?"}'
```

### Stop the Application

```bash
./stop.sh
```

---

## Manual Setup (Step-by-Step)

### 1. Start Ollama and pull models

```bash
ollama serve  # In one terminal
ollama pull llama3.2
ollama pull nomic-embed-text
```

### 2. Start PostgreSQL with pgvector

```bash
docker-compose up -d postgres
```

### 3. Install dependencies

```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 4. Start the API

```bash
cd backend
source venv/bin/activate
uvicorn app.main:app --reload --port 8000
```

### 5. Serve sample pages

```bash
python3 sample_pages/server.py
```

### 6. Scrape sample pages

```bash
curl -X POST http://localhost:8000/api/v1/scrape \
  -H "Content-Type: application/json" \
  -d '{
    "urls": [
      "http://localhost:8001/page1_company.html",
      "http://localhost:8001/page2_products.html",
      "http://localhost:8001/page3_policies.html",
      "http://localhost:8001/page4_benefits.html",
      "http://localhost:8001/page5_support.html"
    ]
  }'
```

### 7. Chat with the bot

```bash
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"query": "What are the health insurance options?"}'
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/chat` | Send a query to the chatbot |
| POST | `/api/v1/scrape` | Scrape URLs and store in database |
| GET | `/api/v1/documents` | List all scraped documents |
| GET | `/api/v1/history/{session_id}` | Get chat history |
| GET | `/api/v1/health` | Health check |

## Configuration

Environment variables (`.env`):

| Variable | Description | Default |
|----------|-------------|---------|
| DATABASE_URL | PostgreSQL connection | postgresql://chatbot:chatbot@localhost:5432/chatbot |
| OLLAMA_HOST | Ollama host | localhost |
| OLLAMA_PORT | Ollama port | 11434 |
| PRIMARY_MODEL | LLM for responses | llama3.2 |
| EMBEDDING_MODEL | Model for embeddings | nomic-embed-text |

## Project Structure

```
├── backend/
│   ├── app/
│   │   ├── api/           # API endpoints
│   │   ├── core/          # Config and database
│   │   ├── models/        # SQLAlchemy models
│   │   ├── services/      # Business logic
│   │   └── main.py        # FastAPI app
│   ├── requirements.txt
│   └── Dockerfile
├── sample_pages/          # 5 sample HTML pages
├── scripts/
│   └── init-db.sql        # Database schema
├── docker-compose.yml
└── README.md
```

## Sample Pages Content

The 5 sample pages contain information about a fictional company:

1. **Company Overview** - About TechCorp, values, leadership, locations
2. **Products & Services** - CloudSync, DataVault, SecureShield products
3. **Employee Policies** - Work hours, PTO, parental leave, professional development
4. **Benefits** - Health insurance, 401k, wellness programs
5. **Customer Support** - Contact info, support tiers, FAQ

## License

MIT
