#!/bin/bash

# Chatbot Application Startup Script
# This script starts all required services in the correct order

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "=========================================="
echo "   Chatbot Application Startup Script"
echo "=========================================="

# Function to check if a port is in use
check_port() {
    lsof -i :$1 >/dev/null 2>&1
    return $?
}

# Function to wait for a service
wait_for_service() {
    local host=$1
    local port=$2
    local name=$3
    local max_attempts=30
    local attempt=1
    
    echo -n "Waiting for $name..."
    while ! nc -z $host $port 2>/dev/null; do
        if [ $attempt -ge $max_attempts ]; then
            echo -e " ${RED}FAILED${NC}"
            return 1
        fi
        echo -n "."
        sleep 1
        ((attempt++))
    done
    echo -e " ${GREEN}OK${NC}"
    return 0
}

# Step 1: Check Ollama
echo ""
echo -e "${YELLOW}Step 1: Checking Ollama...${NC}"
if check_port 11434; then
    echo -e "Ollama: ${GREEN}Running${NC}"
else
    echo -e "Ollama: ${RED}Not running${NC}"
    echo "Please start Ollama first: ollama serve"
    echo "Then pull required models:"
    echo "  ollama pull llama3.2"
    echo "  ollama pull nomic-embed-text"
    exit 1
fi

# Check if required models are available
echo "Checking Ollama models..."
if ! ollama list 2>/dev/null | grep -q "llama3"; then
    echo -e "${YELLOW}Warning: llama3.2 model not found. Pull it with: ollama pull llama3.2${NC}"
fi
if ! ollama list 2>/dev/null | grep -q "nomic-embed"; then
    echo -e "${YELLOW}Warning: nomic-embed-text model not found. Pull it with: ollama pull nomic-embed-text${NC}"
fi

# Step 2: Start PostgreSQL
echo ""
echo -e "${YELLOW}Step 2: Starting PostgreSQL with pgvector...${NC}"
if check_port 5434; then
    echo -e "PostgreSQL: ${GREEN}Already running on port 5434${NC}"
else
    docker-compose up -d postgres
    wait_for_service localhost 5434 "PostgreSQL"
fi

# Verify database tables exist
echo "Verifying database tables..."
docker exec chatbot-db psql -U chatbot -c "\dt" >/dev/null 2>&1
echo -e "Database tables: ${GREEN}OK${NC}"

# Step 3: Start Sample Pages Server
echo ""
echo -e "${YELLOW}Step 3: Starting Sample Pages Server...${NC}"
if check_port 8001; then
    echo -e "Sample Pages Server: ${GREEN}Already running on port 8001${NC}"
else
    cd sample_pages
    python3 server.py &
    SAMPLE_PID=$!
    cd "$SCRIPT_DIR"
    sleep 2
    if check_port 8001; then
        echo -e "Sample Pages Server: ${GREEN}Started (PID: $SAMPLE_PID)${NC}"
    else
        echo -e "Sample Pages Server: ${RED}Failed to start${NC}"
    fi
fi

# Step 4: Setup Python environment and start API
echo ""
echo -e "${YELLOW}Step 4: Starting Chatbot API...${NC}"
cd backend

# Create venv if it doesn't exist
if [ ! -d "venv" ]; then
    echo "Creating Python virtual environment..."
    python3 -m venv venv
fi

# Activate and install dependencies
source venv/bin/activate
pip install -q -r requirements.txt

# Start the API
if check_port 8000; then
    echo -e "Chatbot API: ${GREEN}Already running on port 8000${NC}"
else
    echo "Starting Chatbot API..."
    uvicorn app.main:app --host 0.0.0.0 --port 8000 &
    API_PID=$!
    wait_for_service localhost 8000 "Chatbot API"
fi

cd "$SCRIPT_DIR"

# Step 5: Health Check
echo ""
echo -e "${YELLOW}Step 5: Running Health Check...${NC}"
sleep 2
HEALTH=$(curl -s http://localhost:8000/api/v1/health)
echo "Health Status: $HEALTH"

# Step 6: Check if data needs to be scraped
echo ""
echo -e "${YELLOW}Step 6: Checking indexed documents...${NC}"
DOC_COUNT=$(docker exec chatbot-db psql -U chatbot -t -c "SELECT COUNT(*) FROM documents;" | tr -d ' ')

if [ "$DOC_COUNT" -eq "0" ]; then
    echo "No documents indexed. Scraping sample pages..."
    curl -s -X POST http://localhost:8000/api/v1/scrape \
      -H "Content-Type: application/json" \
      -d '{
        "urls": [
          "http://localhost:8001/page1_company.html",
          "http://localhost:8001/page2_products.html",
          "http://localhost:8001/page3_policies.html",
          "http://localhost:8001/page4_benefits.html",
          "http://localhost:8001/page5_support.html"
        ]
      }' | python3 -m json.tool
else
    echo -e "Documents already indexed: ${GREEN}$DOC_COUNT chunks${NC}"
fi

# Summary
echo ""
echo "=========================================="
echo -e "${GREEN}   Application Started Successfully!${NC}"
echo "=========================================="
echo ""
echo "Services:"
echo "  - PostgreSQL:    http://localhost:5434"
echo "  - Sample Pages:  http://localhost:8001"
echo "  - Chatbot API:   http://localhost:8000"
echo "  - API Docs:      http://localhost:8000/docs"
echo ""
echo "Test the chatbot:"
echo '  curl -X POST http://localhost:8000/api/v1/chat \'
echo '    -H "Content-Type: application/json" \'
echo '    -d '"'"'{"query": "What are the health insurance options?"}'"'"
echo ""
echo "To stop all services, run: ./stop.sh"
echo ""
