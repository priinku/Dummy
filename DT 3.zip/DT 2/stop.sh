#!/bin/bash

# Chatbot Application Stop Script
# This script stops all running services

echo "=========================================="
echo "   Stopping Chatbot Application"
echo "=========================================="

# Stop Chatbot API (uvicorn)
echo "Stopping Chatbot API..."
pkill -f "uvicorn app.main:app" 2>/dev/null && echo "  Chatbot API stopped" || echo "  Chatbot API not running"

# Stop Sample Pages Server
echo "Stopping Sample Pages Server..."
pkill -f "sample_pages/server.py" 2>/dev/null && echo "  Sample Pages Server stopped" || echo "  Sample Pages Server not running"
pkill -f "python3 server.py" 2>/dev/null

# Stop PostgreSQL container
echo "Stopping PostgreSQL..."
docker-compose down 2>/dev/null && echo "  PostgreSQL stopped" || echo "  PostgreSQL not running"

echo ""
echo "All services stopped."
echo ""
