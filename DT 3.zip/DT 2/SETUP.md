# Chatbot Setup Guide

## Complete Setup Instructions

This guide explains how to set up and run the Chatbot application from scratch.

---

## Prerequisites

### 1. Docker
Required for running PostgreSQL with pgvector extension.

```bash
# Verify Docker is installed
docker --version

# Verify Docker Compose is available
docker-compose --version
```

### 2. Python 3.10+
Required for the FastAPI backend.

```bash
# Verify Python version
python3 --version
```

### 3. Ollama
Required for LLM inference and embeddings.

**Install on macOS:**
```bash
brew install ollama
```

**Install on Linux:**
```bash
curl -fsSL https://ollama.com/install.sh | sh
```

**Start Ollama service:**
```bash
ollama serve
```

**Pull required models:**
```bash
ollama pull llama3.2          # Primary LLM for responses
ollama pull nomic-embed-text  # Embedding model for vector search
```

---

## Running the Application

### Option 1: One-Click Start (Recommended)

```bash
# Make sure Ollama is running first
ollama serve

# In another terminal, start everything
./start.sh
```

The script automatically:
1. Checks Ollama is running
2. Starts PostgreSQL with pgvector
3. Starts the sample pages server
4. Installs Python dependencies
5. Starts the Chatbot API
6. Scrapes sample pages if not already done

### Option 2: Manual Start

**Terminal 1 - Ollama:**
```bash
ollama serve
```

**Terminal 2 - PostgreSQL:**
```bash
docker-compose up -d postgres
```

**Terminal 3 - Sample Pages:**
```bash
python3 sample_pages/server.py
```

**Terminal 4 - Chatbot API:**
```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

---

## Testing the Application

### 1. Check Health
```bash
curl http://localhost:8000/api/v1/health
```

Expected response:
```json
{"status": "healthy", "database": true, "ollama": true}
```

### 2. Scrape Sample Pages
```bash
curl -X POST http://localhost:8000/api/v1/scrape \
  -H "Content-Type: application/json" \
  -d '{
    "urls": [
      "http://localhost:8001/page1_company.html",
      "http://localhost:8001/page2_products.html",
      "http://localhost:8001/page3_policies.html",
      "http://localhost:8001/page4_benefits.html",
      "http://localhost:8001/page5_support.html"
    ]
  }'
```

### 3. List Indexed Documents
```bash
curl http://localhost:8000/api/v1/documents
```

### 4. Chat with the Bot
```bash
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"query": "What are the health insurance options?"}'
```

### 5. Example Queries to Try
```bash
# Company information
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"query": "Who is the CEO of TechCorp?"}'

# Products
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"query": "What is CloudSync and how much does it cost?"}'

# Policies
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"query": "How many vacation days do employees get?"}'

# Benefits
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"query": "What is the 401k matching policy?"}'

# Support
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"query": "How do I reset my password?"}'
```

---

## Stopping the Application

```bash
./stop.sh
```

Or manually:
```bash
# Stop API
pkill -f "uvicorn app.main:app"

# Stop sample pages server
pkill -f "server.py"

# Stop PostgreSQL
docker-compose down
```

---

## Service Ports

| Service | Port | URL |
|---------|------|-----|
| Chatbot API | 8000 | http://localhost:8000 |
| API Documentation | 8000 | http://localhost:8000/docs |
| Sample Pages | 8001 | http://localhost:8001 |
| PostgreSQL | 5434 | localhost:5434 |
| Ollama | 11434 | http://localhost:11434 |

---

## Troubleshooting

### Ollama not running
```
Error: Ollama not running
Solution: Start Ollama with 'ollama serve'
```

### Port already in use
```
Error: Port 5434 already in use
Solution: Stop existing PostgreSQL or change port in docker-compose.yml
```

### No documents indexed
```
Issue: Chat returns empty results
Solution: Run the scrape endpoint to index sample pages
```

### Models not found
```
Error: Model not found
Solution: Pull models with 'ollama pull llama3.2' and 'ollama pull nomic-embed-text'
```

---

## Database Access

Connect to PostgreSQL directly:
```bash
docker exec -it chatbot-db psql -U chatbot

# View tables
\dt

# Check scraped pages
SELECT id, url, title FROM web_pages;

# Check document chunks
SELECT id, source_url, chunk_index, LEFT(content, 50) FROM documents;

# Exit
\q
```

---

## Resetting Data

To clear all data and start fresh:
```bash
# Stop services
./stop.sh

# Remove database volume
docker volume rm dt_postgres_data

# Start fresh
./start.sh
```
