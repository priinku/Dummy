"""
Chatbot Database Models
SQLAlchemy models for PostgreSQL + pgvector
"""

from sqlalchemy import Column, Integer, String, Text, DateTime, Float
from sqlalchemy.dialects.postgresql import JSONB
from pgvector.sqlalchemy import Vector
from app.core.db import Base
import datetime


class WebPage(Base):
    """Scraped web page content"""
    __tablename__ = "web_pages"
    
    id = Column(Integer, primary_key=True, index=True)
    url = Column(String(2048), unique=True, nullable=False, index=True)
    title = Column(String(512), nullable=True)
    content = Column(Text, nullable=False)
    scraped_at = Column(DateTime, default=datetime.datetime.utcnow)
    extra_data = Column(JSONB, default={})


class Document(Base):
    """Document chunks with embeddings for vector search"""
    __tablename__ = "documents"
    
    id = Column(Integer, primary_key=True, index=True)
    source_url = Column(String(2048), nullable=False, index=True)
    title = Column(String(512), nullable=True)
    content = Column(Text, nullable=False)
    chunk_index = Column(Integer, default=0)
    embedding = Column(Vector(768), nullable=True)  # nomic-embed-text dimension
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    extra_data = Column(JSONB, default={})


class ChatHistory(Base):
    """Chat conversation history"""
    __tablename__ = "chat_history"
    
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String(64), nullable=False, index=True)
    query = Column(Text, nullable=False)
    response = Column(Text, nullable=False)
    sources = Column(JSONB, default=[])
    confidence = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
