"""
Ollama Client Service
Handles communication with Ollama for LLM inference and embeddings
"""

import requests
import logging
from typing import List, Optional
from app.core.config import settings

logger = logging.getLogger(__name__)


class OllamaClient:
    """Client for Ollama API"""
    
    def __init__(self):
        self.base_url = f"http://{settings.OLLAMA_HOST}:{settings.OLLAMA_PORT}"
        self.timeout = 120
    
    def generate(
        self,
        prompt: str,
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None
    ) -> str:
        """
        Generate text using Ollama
        
        Args:
            prompt: Input prompt
            model: Model name (defaults to PRIMARY_MODEL)
            temperature: Generation temperature
            max_tokens: Maximum tokens to generate
            
        Returns:
            Generated text
        """
        model = model or settings.PRIMARY_MODEL
        temperature = temperature if temperature is not None else settings.PRIMARY_TEMPERATURE
        
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": temperature,
            }
        }
        
        if max_tokens:
            payload["options"]["num_predict"] = max_tokens
        
        try:
            response = requests.post(
                f"{self.base_url}/api/generate",
                json=payload,
                timeout=self.timeout
            )
            response.raise_for_status()
            result = response.json()
            return result.get("response", "")
        except requests.exceptions.RequestException as e:
            logger.error(f"Ollama generate error: {e}")
            raise
    
    def embed(self, texts: List[str], model: Optional[str] = None) -> List[List[float]]:
        """
        Generate embeddings for texts
        
        Args:
            texts: List of texts to embed
            model: Embedding model (defaults to EMBEDDING_MODEL)
            
        Returns:
            List of embedding vectors
        """
        model = model or settings.EMBEDDING_MODEL
        embeddings = []
        
        for text in texts:
            try:
                response = requests.post(
                    f"{self.base_url}/api/embeddings",
                    json={"model": model, "prompt": text},
                    timeout=self.timeout
                )
                response.raise_for_status()
                result = response.json()
                embeddings.append(result.get("embedding", []))
            except requests.exceptions.RequestException as e:
                logger.error(f"Ollama embedding error: {e}")
                raise
        
        return embeddings
    
    def health_check(self) -> bool:
        """Check if Ollama is available"""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            return response.status_code == 200
        except:
            return False


# Singleton instance
_client = None

def get_ollama_client() -> OllamaClient:
    """Get Ollama client singleton"""
    global _client
    if _client is None:
        _client = OllamaClient()
    return _client
