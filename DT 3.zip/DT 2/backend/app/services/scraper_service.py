"""
Web Scraper Service
Scrapes web pages and stores content in PostgreSQL with embeddings in pgvector
"""

import logging
import re
from typing import List, Dict, Optional
from bs4 import BeautifulSoup
import requests
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.document import WebPage, Document
from app.services.ollama_client import get_ollama_client

logger = logging.getLogger(__name__)


class ScraperService:
    """Service for scraping web pages and storing in database"""
    
    def __init__(self, db: Session):
        self.db = db
        self.ollama = get_ollama_client()
        self.headers = {
            "User-Agent": settings.SCRAPER_USER_AGENT
        }
    
    def scrape_url(self, url: str) -> Optional[WebPage]:
        """
        Scrape a single URL and store in database
        
        Args:
            url: URL to scrape
            
        Returns:
            WebPage object or None if failed
        """
        try:
            # Check if already scraped
            existing = self.db.query(WebPage).filter(WebPage.url == url).first()
            if existing:
                logger.info(f"URL already scraped: {url}")
                return existing
            
            # Fetch the page
            response = requests.get(
                url, 
                headers=self.headers, 
                timeout=settings.SCRAPER_TIMEOUT
            )
            response.raise_for_status()
            
            # Parse HTML
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract title
            title = soup.title.string if soup.title else url
            
            # Extract text content
            # Remove script and style elements
            for script in soup(["script", "style", "nav", "footer", "header"]):
                script.decompose()
            
            # Get text
            text = soup.get_text(separator='\n', strip=True)
            
            # Clean up whitespace
            text = re.sub(r'\n\s*\n', '\n\n', text)
            text = text.strip()
            
            # Store in database
            web_page = WebPage(
                url=url,
                title=title[:512] if title else None,
                content=text,
                extra_data={"content_length": len(text)}
            )
            
            self.db.add(web_page)
            self.db.commit()
            self.db.refresh(web_page)
            
            logger.info(f"Scraped: {url} ({len(text)} chars)")
            return web_page
            
        except Exception as e:
            logger.error(f"Failed to scrape {url}: {e}")
            self.db.rollback()
            return None
    
    def chunk_text(self, text: str, chunk_size: int = 500, overlap: int = 50) -> List[str]:
        """
        Split text into overlapping chunks
        
        Args:
            text: Text to chunk
            chunk_size: Target chunk size in characters
            overlap: Overlap between chunks
            
        Returns:
            List of text chunks
        """
        if len(text) <= chunk_size:
            return [text]
        
        chunks = []
        start = 0
        
        while start < len(text):
            end = start + chunk_size
            
            # Try to break at sentence boundary
            if end < len(text):
                # Look for sentence end within the chunk
                for sep in ['. ', '.\n', '!\n', '?\n', '\n\n']:
                    last_sep = text[start:end].rfind(sep)
                    if last_sep > chunk_size // 2:
                        end = start + last_sep + len(sep)
                        break
            
            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)
            
            start = end - overlap
        
        return chunks
    
    def process_and_embed(self, web_page: WebPage) -> int:
        """
        Process a scraped page into chunks and generate embeddings
        
        Args:
            web_page: WebPage to process
            
        Returns:
            Number of chunks created
        """
        try:
            # Check if already processed
            existing = self.db.query(Document).filter(
                Document.source_url == web_page.url
            ).first()
            
            if existing:
                logger.info(f"Already processed: {web_page.url}")
                return 0
            
            # Chunk the content
            chunks = self.chunk_text(web_page.content)
            
            # Generate embeddings
            embeddings = self.ollama.embed(chunks)
            
            # Store chunks with embeddings
            for i, (chunk, embedding) in enumerate(zip(chunks, embeddings)):
                doc = Document(
                    source_url=web_page.url,
                    title=web_page.title,
                    content=chunk,
                    chunk_index=i,
                    embedding=embedding,
                    extra_data={"chunk_size": len(chunk)}
                )
                self.db.add(doc)
            
            self.db.commit()
            logger.info(f"Created {len(chunks)} chunks for {web_page.url}")
            return len(chunks)
            
        except Exception as e:
            logger.error(f"Failed to process {web_page.url}: {e}")
            self.db.rollback()
            return 0
    
    def scrape_and_process(self, urls: List[str]) -> Dict[str, int]:
        """
        Scrape multiple URLs and process them
        
        Args:
            urls: List of URLs to scrape
            
        Returns:
            Dictionary mapping URLs to chunk counts
        """
        results = {}
        
        for url in urls:
            web_page = self.scrape_url(url)
            if web_page:
                chunks = self.process_and_embed(web_page)
                results[url] = chunks
            else:
                results[url] = 0
        
        return results


def get_scraper_service(db: Session) -> ScraperService:
    """Factory function to create scraper service"""
    return ScraperService(db)
