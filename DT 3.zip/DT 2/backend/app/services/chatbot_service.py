"""
Chatbot Service
Retrieval-augmented generation using pgvector and Ollama
"""

import logging
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from sqlalchemy.orm import Session
from sqlalchemy import text

from app.core.config import settings
from app.models.document import Document, ChatHistory
from app.services.ollama_client import get_ollama_client

logger = logging.getLogger(__name__)


@dataclass
class Source:
    """Retrieved source document"""
    url: str
    title: str
    content: str
    score: float
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "url": self.url,
            "title": self.title,
            "content": self.content[:200] + "..." if len(self.content) > 200 else self.content,
            "score": round(self.score, 3)
        }


@dataclass
class ChatResponse:
    """Chatbot response"""
    response: str
    sources: List[Source]
    confidence: float
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "response": self.response,
            "sources": [s.to_dict() for s in self.sources],
            "confidence": round(self.confidence, 2)
        }


class ChatbotService:
    """RAG-based chatbot service"""
    
    def __init__(self, db: Session):
        self.db = db
        self.ollama = get_ollama_client()
    
    def search_documents(
        self, 
        query: str, 
        top_k: int = None,
        min_score: float = None
    ) -> List[Source]:
        """
        Search for relevant documents using vector similarity
        
        Args:
            query: User query
            top_k: Number of results to return
            min_score: Minimum similarity score
            
        Returns:
            List of relevant sources
        """
        top_k = top_k or settings.SEARCH_TOP_K
        min_score = min_score or settings.SEARCH_MIN_SCORE
        
        try:
            # Generate query embedding
            query_embedding = self.ollama.embed([query])[0]
            
            # Vector similarity search using pgvector
            sql = text("""
                SELECT 
                    source_url,
                    title,
                    content,
                    1 - (embedding <=> :embedding::vector) as score
                FROM documents
                WHERE embedding IS NOT NULL
                ORDER BY embedding <=> :embedding::vector
                LIMIT :limit
            """)
            
            result = self.db.execute(sql, {
                "embedding": str(query_embedding),
                "limit": top_k
            })
            
            sources = []
            for row in result:
                score = float(row.score)
                if score >= min_score:
                    sources.append(Source(
                        url=row.source_url,
                        title=row.title or "Untitled",
                        content=row.content,
                        score=score
                    ))
            
            logger.info(f"Found {len(sources)} relevant documents for query")
            return sources
            
        except Exception as e:
            logger.error(f"Search error: {e}")
            return []
    
    def generate_response(
        self, 
        query: str, 
        sources: List[Source]
    ) -> str:
        """
        Generate response using LLM with retrieved context
        
        Args:
            query: User query
            sources: Retrieved source documents
            
        Returns:
            Generated response
        """
        if not sources:
            return "I couldn't find any relevant information to answer your question. Please try rephrasing or ask about a different topic."
        
        # Build context from sources
        context_parts = []
        for i, source in enumerate(sources, 1):
            context_parts.append(
                f"[Source {i}: {source.title}]\n{source.content}"
            )
        
        context = "\n\n".join(context_parts)
        
        # Create prompt
        prompt = f"""You are a helpful assistant that answers questions based on the provided context.
Use ONLY the information from the context below to answer the question.
If the context doesn't contain enough information to answer, say so clearly.
Be concise and direct in your response.

CONTEXT:
{context}

USER QUESTION: {query}

ANSWER:"""
        
        try:
            response = self.ollama.generate(
                prompt=prompt,
                temperature=settings.PRIMARY_TEMPERATURE,
                max_tokens=settings.RESPONSE_MAX_TOKENS
            )
            return response.strip()
        except Exception as e:
            logger.error(f"Generation error: {e}")
            return "Sorry, I encountered an error generating a response. Please try again."
    
    def chat(
        self, 
        query: str, 
        session_id: Optional[str] = None
    ) -> ChatResponse:
        """
        Process a chat query
        
        Args:
            query: User query
            session_id: Optional session ID for history
            
        Returns:
            ChatResponse with answer and sources
        """
        # Validate query
        if len(query) > settings.MAX_QUERY_LENGTH:
            return ChatResponse(
                response=f"Query too long. Maximum {settings.MAX_QUERY_LENGTH} characters allowed.",
                sources=[],
                confidence=0.0
            )
        
        # Search for relevant documents
        sources = self.search_documents(query)
        
        # Calculate confidence based on source scores
        if sources:
            confidence = sum(s.score for s in sources) / len(sources)
        else:
            confidence = 0.0
        
        # Generate response
        response = self.generate_response(query, sources)
        
        # Store in history if session provided
        if session_id:
            self._store_history(session_id, query, response, sources, confidence)
        
        return ChatResponse(
            response=response,
            sources=sources[:3],  # Return top 3 sources
            confidence=confidence
        )
    
    def _store_history(
        self, 
        session_id: str, 
        query: str, 
        response: str, 
        sources: List[Source],
        confidence: float
    ):
        """Store chat interaction in history"""
        try:
            history = ChatHistory(
                session_id=session_id,
                query=query,
                response=response,
                sources=[s.to_dict() for s in sources],
                confidence=confidence
            )
            self.db.add(history)
            self.db.commit()
        except Exception as e:
            logger.error(f"Failed to store history: {e}")
            self.db.rollback()
    
    def get_history(self, session_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Get chat history for a session"""
        history = self.db.query(ChatHistory).filter(
            ChatHistory.session_id == session_id
        ).order_by(ChatHistory.created_at.desc()).limit(limit).all()
        
        return [
            {
                "query": h.query,
                "response": h.response,
                "sources": h.sources,
                "confidence": h.confidence,
                "created_at": h.created_at.isoformat()
            }
            for h in reversed(history)
        ]


def get_chatbot_service(db: Session) -> ChatbotService:
    """Factory function to create chatbot service"""
    return ChatbotService(db)
