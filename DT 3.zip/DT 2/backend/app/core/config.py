"""
Chatbot Configuration
Clean, optimized settings for the chatbot system
"""

from pydantic_settings import BaseSettings
from typing import Optional, List


class Settings(BaseSettings):
    """Chatbot application settings"""
    
    # Application
    APP_NAME: str = "Chatbot API"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    
    # Database (PostgreSQL + pgvector)
    DATABASE_URL: str = "postgresql://chatbot:chatbot@localhost:5432/chatbot"
    DATABASE_POOL_SIZE: int = 10
    
    # Ollama LLM Configuration
    OLLAMA_HOST: str = "localhost"
    OLLAMA_PORT: int = 11434
    
    # Primary Model (for response generation)
    PRIMARY_MODEL: str = "llama3.2"
    PRIMARY_TEMPERATURE: float = 0.1
    PRIMARY_MAX_TOKENS: int = 2048
    
    # Support Model (for embeddings/routing)
    SUPPORT_MODEL: str = "nomic-embed-text"
    
    # Embedding Configuration
    EMBEDDING_MODEL: str = "nomic-embed-text"
    EMBEDDING_DIMENSION: int = 768
    
    # Search Configuration
    SEARCH_TOP_K: int = 5
    SEARCH_MIN_SCORE: float = 0.3
    
    # Chatbot Settings
    MAX_QUERY_LENGTH: int = 1000
    RESPONSE_MAX_TOKENS: int = 1024
    
    # Web Scraper Settings
    SCRAPER_TIMEOUT: int = 30
    SCRAPER_USER_AGENT: str = "ChatbotScraper/1.0"
    
    # Sample Pages Server
    SAMPLE_PAGES_PORT: int = 8001
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True


settings = Settings()

__all__ = ["settings", "Settings"]
