"""
Chatbot API Endpoints
REST API for chatbot queries and web scraping
"""

import logging
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.services.chatbot_service import get_chatbot_service
from app.services.scraper_service import get_scraper_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1", tags=["Chatbot"])


# Request/Response Models
class ChatRequest(BaseModel):
    """Chat query request"""
    query: str = Field(..., min_length=1, max_length=1000, description="User query")
    session_id: Optional[str] = Field(None, description="Session ID for history tracking")


class SourceResponse(BaseModel):
    """Source document in response"""
    url: str
    title: str
    content: str
    score: float


class ChatResponse(BaseModel):
    """Chat response"""
    response: str
    sources: List[SourceResponse]
    confidence: float


class ScrapeRequest(BaseModel):
    """Web scrape request"""
    urls: List[str] = Field(..., min_items=1, max_items=10, description="URLs to scrape")


class ScrapeResponse(BaseModel):
    """Scrape operation response"""
    results: dict
    total_chunks: int
    message: str


class HealthResponse(BaseModel):
    """Health check response"""
    status: str
    database: bool
    ollama: bool


# API Endpoints
@router.post("/chat", response_model=ChatResponse)
def chat(request: ChatRequest, db: Session = Depends(get_db)):
    """
    Send a query to the chatbot
    
    The chatbot will:
    1. Search for relevant documents using vector similarity
    2. Generate a response using the LLM with retrieved context
    3. Return the response with source citations
    """
    try:
        chatbot = get_chatbot_service(db)
        result = chatbot.chat(
            query=request.query,
            session_id=request.session_id
        )
        
        return ChatResponse(
            response=result.response,
            sources=[
                SourceResponse(
                    url=s.url,
                    title=s.title,
                    content=s.content[:200] + "..." if len(s.content) > 200 else s.content,
                    score=s.score
                )
                for s in result.sources
            ],
            confidence=result.confidence
        )
    except Exception as e:
        logger.error(f"Chat error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/scrape", response_model=ScrapeResponse)
def scrape_urls(request: ScrapeRequest, db: Session = Depends(get_db)):
    """
    Scrape web pages and store in the database
    
    This endpoint will:
    1. Fetch content from each URL
    2. Extract text and clean HTML
    3. Chunk content into searchable segments
    4. Generate embeddings and store in pgvector
    """
    try:
        scraper = get_scraper_service(db)
        results = scraper.scrape_and_process(request.urls)
        
        total_chunks = sum(results.values())
        
        return ScrapeResponse(
            results=results,
            total_chunks=total_chunks,
            message=f"Processed {len(results)} URLs, created {total_chunks} chunks"
        )
    except Exception as e:
        logger.error(f"Scrape error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/documents")
def list_documents(db: Session = Depends(get_db)):
    """List all indexed documents"""
    from app.models.document import WebPage
    
    pages = db.query(WebPage).all()
    return {
        "total": len(pages),
        "documents": [
            {
                "id": p.id,
                "url": p.url,
                "title": p.title,
                "content_length": len(p.content) if p.content else 0,
                "scraped_at": p.scraped_at.isoformat() if p.scraped_at else None
            }
            for p in pages
        ]
    }


@router.get("/history/{session_id}")
def get_history(session_id: str, limit: int = 10, db: Session = Depends(get_db)):
    """Get chat history for a session"""
    chatbot = get_chatbot_service(db)
    history = chatbot.get_history(session_id, limit)
    return {"session_id": session_id, "history": history}


@router.get("/health", response_model=HealthResponse)
def health_check(db: Session = Depends(get_db)):
    """Check service health"""
    from app.core.db import check_db_connection
    from app.services.ollama_client import get_ollama_client
    
    db_healthy = check_db_connection()
    ollama_healthy = get_ollama_client().health_check()
    
    overall = "healthy" if db_healthy and ollama_healthy else "unhealthy"
    
    return HealthResponse(
        status=overall,
        database=db_healthy,
        ollama=ollama_healthy
    )
