import { Context, Next } from 'koa';

// Rate limiting store (in production, use Redis)
const rateLimitStore = new Map<string, { count: number; resetTime: number }>();

// Rate limiter middleware
export const rateLimiter = (maxRequests = 100, windowMs = 60000) => {
  return async (ctx: Context, next: Next) => {
    const ip = ctx.ip || ctx.request.ip || 'unknown';
    const now = Date.now();
    
    let record = rateLimitStore.get(ip);
    
    if (!record || now > record.resetTime) {
      record = { count: 1, resetTime: now + windowMs };
      rateLimitStore.set(ip, record);
    } else {
      record.count++;
    }
    
    ctx.set('X-RateLimit-Limit', String(maxRequests));
    ctx.set('X-RateLimit-Remaining', String(Math.max(0, maxRequests - record.count)));
    ctx.set('X-RateLimit-Reset', String(Math.ceil(record.resetTime / 1000)));
    
    if (record.count > maxRequests) {
      ctx.status = 429;
      ctx.body = { code: 429, message: 'Too many requests. Please try again later.' };
      return;
    }
    
    await next();
  };
};

// Security headers middleware
export const securityHeaders = async (ctx: Context, next: Next) => {
  await next();
  
  // Prevent clickjacking
  ctx.set('X-Frame-Options', 'DENY');
  
  // Prevent MIME type sniffing
  ctx.set('X-Content-Type-Options', 'nosniff');
  
  // Enable XSS filter
  ctx.set('X-XSS-Protection', '1; mode=block');
  
  // Referrer policy
  ctx.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  
  // Content Security Policy (adjust as needed)
  ctx.set('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self' ws: wss:;");
};

// Request sanitizer middleware
export const sanitizeRequest = async (ctx: Context, next: Next) => {
  // Sanitize query parameters
  if (ctx.query) {
    for (const key in ctx.query) {
      const value = ctx.query[key];
      if (typeof value === 'string') {
        // Remove potential XSS characters
        ctx.query[key] = value.replace(/<[^>]*>/g, '').trim();
      }
    }
  }
  
  await next();
};

// Request logging middleware (production-grade)
export const requestLogger = async (ctx: Context, next: Next) => {
  const start = Date.now();
  const requestId = Math.random().toString(36).substring(7);
  
  ctx.set('X-Request-ID', requestId);
  
  try {
    await next();
  } finally {
    const duration = Date.now() - start;
    const logLevel = ctx.status >= 500 ? 'error' : ctx.status >= 400 ? 'warn' : 'info';
    
    const logData = {
      requestId,
      method: ctx.method,
      path: ctx.path,
      status: ctx.status,
      duration: `${duration}ms`,
      ip: ctx.ip,
      userAgent: ctx.get('user-agent'),
    };
    
    if (logLevel === 'error') {
      console.error('[REQUEST]', JSON.stringify(logData));
    } else if (logLevel === 'warn') {
      console.warn('[REQUEST]', JSON.stringify(logData));
    } else if (process.env.NODE_ENV !== 'production' || duration > 1000) {
      console.log('[REQUEST]', JSON.stringify(logData));
    }
  }
};

// Error handler middleware
export const errorHandler = async (ctx: Context, next: Next) => {
  try {
    await next();
  } catch (err: any) {
    const status = err.status || err.statusCode || 500;
    const message = err.expose ? err.message : 'Internal Server Error';
    
    ctx.status = status;
    ctx.body = {
      code: status,
      message,
      ...(process.env.NODE_ENV !== 'production' && { stack: err.stack }),
    };
    
    // Log error
    console.error('[ERROR]', {
      status,
      message: err.message,
      stack: err.stack,
      path: ctx.path,
      method: ctx.method,
    });
    
    ctx.app.emit('error', err, ctx);
  }
};

// Input validation helpers
export const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

export const validatePassword = (password: string): { valid: boolean; message?: string } => {
  if (password.length < 8) {
    return { valid: false, message: 'Password must be at least 8 characters' };
  }
  if (!/[A-Z]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one uppercase letter' };
  }
  if (!/[a-z]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one lowercase letter' };
  }
  if (!/[0-9]/.test(password)) {
    return { valid: false, message: 'Password must contain at least one number' };
  }
  return { valid: true };
};

export const sanitizeInput = (input: string): string => {
  return input
    .replace(/[<>]/g, '') // Remove angle brackets
    .replace(/javascript:/gi, '') // Remove javascript: protocol
    .replace(/on\w+=/gi, '') // Remove event handlers
    .trim();
};
