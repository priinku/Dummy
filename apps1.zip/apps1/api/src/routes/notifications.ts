import Router from 'koa-router';
import { Context } from 'koa';
import { notificationRepository } from '../supabase/repositories/notificationRepository';

const router = new Router({ prefix: '/api/notifications' });

const getCurrentUser = (ctx: Context) => {
  return ctx.state.user || { userId: 1, userName: 'test_user', role: 'user' };
};

// GET /api/notifications - Get notifications for current user
router.get('/', async (ctx: Context) => {
  try {
    const user = getCurrentUser(ctx);
    const isAdmin = user.userName === 'admin' || user.role === 'admin';
    
    const notifications = await notificationRepository.getForUser(
      user.userId?.toString() || user.id,
      user.userName,
      isAdmin
    );
    
    ctx.body = { code: 200, result: { notifications } };
  } catch (err) {
    console.error('[Notifications] Error:', err);
    ctx.body = { code: 500, message: 'Failed to fetch notifications' };
  }
});

// GET /api/notifications/unread-count
router.get('/unread-count', async (ctx: Context) => {
  try {
    const user = getCurrentUser(ctx);
    const isAdmin = user.userName === 'admin' || user.role === 'admin';
    
    const count = await notificationRepository.getUnreadCount(
      user.userId?.toString() || user.id,
      user.userName,
      isAdmin
    );
    
    ctx.body = { code: 200, result: { count } };
  } catch (err) {
    ctx.body = { code: 200, result: { count: 0 } };
  }
});

// POST /api/notifications/send - Send direct message
router.post('/send', async (ctx: Context) => {
  try {
    const user = getCurrentUser(ctx);
    const { subject, content, recipient_username } = ctx.request.body as any;
    
    if (!subject || !content) {
      ctx.body = { code: 400, message: 'Subject and content required' };
      return;
    }
    
    // Check for @username in content
    const mentionMatch = content.match(/@(\w+)/);
    const targetUsername = recipient_username || (mentionMatch ? mentionMatch[1] : null);
    
    let notification;
    if (targetUsername) {
      notification = await notificationRepository.createTargeted(
        user.userId?.toString() || user.id,
        targetUsername,
        subject,
        content
      );
    } else {
      notification = await notificationRepository.create({
        sender_id: user.userId?.toString() || user.id,
        notification_type: 'direct',
        subject,
        content,
      });
    }
    
    ctx.body = { code: 200, result: { notification }, message: 'Message sent' };
  } catch (err) {
    console.error('[Notifications] Send error:', err);
    ctx.body = { code: 500, message: 'Failed to send message' };
  }
});

// POST /api/notifications/broadcast - Admin broadcast
router.post('/broadcast', async (ctx: Context) => {
  try {
    const user = getCurrentUser(ctx);
    
    if (user.userName !== 'admin' && user.role !== 'admin') {
      ctx.body = { code: 403, message: 'Admin only' };
      return;
    }
    
    const { subject, content } = ctx.request.body as any;
    
    if (!subject || !content) {
      ctx.body = { code: 400, message: 'Subject and content required' };
      return;
    }
    
    const notification = await notificationRepository.createBroadcast(
      user.userId?.toString() || user.id,
      subject,
      content
    );
    
    ctx.body = { code: 200, result: { notification }, message: 'Broadcast sent' };
  } catch (err) {
    console.error('[Notifications] Broadcast error:', err);
    ctx.body = { code: 500, message: 'Failed to broadcast' };
  }
});

// PUT /api/notifications/mark-read/:id
router.put('/mark-read/:id', async (ctx: Context) => {
  try {
    const user = getCurrentUser(ctx);
    const { id } = ctx.params;
    
    await notificationRepository.markAsRead(id, user.userId?.toString() || user.id);
    
    ctx.body = { code: 200, message: 'Marked as read' };
  } catch (err) {
    ctx.body = { code: 500, message: 'Failed to mark as read' };
  }
});

// PUT /api/notifications/mark-all-read
router.put('/mark-all-read', async (ctx: Context) => {
  try {
    const user = getCurrentUser(ctx);
    const isAdmin = user.userName === 'admin' || user.role === 'admin';
    
    await notificationRepository.markAllAsRead(
      user.userId?.toString() || user.id,
      user.userName,
      isAdmin
    );
    
    ctx.body = { code: 200, message: 'All marked as read' };
  } catch (err) {
    ctx.body = { code: 500, message: 'Failed to mark all as read' };
  }
});

// POST /api/notifications/reply/:id
router.post('/reply/:id', async (ctx: Context) => {
  try {
    const user = getCurrentUser(ctx);
    const { id } = ctx.params;
    const { content } = ctx.request.body as any;
    
    if (!content) {
      ctx.body = { code: 400, message: 'Content required' };
      return;
    }
    
    const notification = await notificationRepository.reply(
      id,
      user.userId?.toString() || user.id,
      content
    );
    
    ctx.body = { code: 200, result: { notification }, message: 'Reply sent' };
  } catch (err) {
    console.error('[Notifications] Reply error:', err);
    ctx.body = { code: 500, message: 'Failed to send reply' };
  }
});

export default router;
