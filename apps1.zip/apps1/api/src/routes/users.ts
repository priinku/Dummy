import Router from 'koa-router';
import { Context } from 'koa';
import { userRepository } from '../supabase/repositories/userRepository';

const router = new Router({ prefix: '/api/users' });

const getCurrentUser = (ctx: Context) => {
  return ctx.state.user || { userId: 1, userName: 'test_user', role: 'user' };
};

const isAdmin = (ctx: Context) => {
  const user = getCurrentUser(ctx);
  return user.userName === 'admin' || user.role === 'admin';
};

// GET /api/users - List all users (admin only)
router.get('/', async (ctx: Context) => {
  try {
    if (!isAdmin(ctx)) {
      ctx.body = { code: 403, message: 'Admin only' };
      return;
    }
    
    const { role, department, is_active } = ctx.query;
    const users = await userRepository.findAll({
      role: role as string,
      department: department as string,
      is_active: is_active === 'true' ? true : is_active === 'false' ? false : undefined,
    });
    
    ctx.body = { code: 200, result: { users } };
  } catch (err) {
    console.error('[Users] List error:', err);
    ctx.body = { code: 500, message: 'Failed to fetch users' };
  }
});

// GET /api/users/departments - Get all departments
router.get('/departments', async (ctx: Context) => {
  try {
    const departments = await userRepository.getDepartments();
    ctx.body = { code: 200, result: { departments } };
  } catch (err) {
    ctx.body = { code: 500, message: 'Failed to fetch departments' };
  }
});

// GET /api/users/:id - Get user by ID
router.get('/:id', async (ctx: Context) => {
  try {
    const { id } = ctx.params;
    const user = await userRepository.findById(id);
    
    if (!user) {
      ctx.body = { code: 404, message: 'User not found' };
      return;
    }
    
    // Remove password hash from response
    const { password_hash, ...safeUser } = user;
    ctx.body = { code: 200, result: { user: safeUser } };
  } catch (err) {
    ctx.body = { code: 500, message: 'Failed to fetch user' };
  }
});

// POST /api/users - Create new user (admin only)
router.post('/', async (ctx: Context) => {
  try {
    if (!isAdmin(ctx)) {
      ctx.body = { code: 403, message: 'Admin only' };
      return;
    }
    
    const currentUser = getCurrentUser(ctx);
    const { user_name, email, password, role, department, display_name } = ctx.request.body as any;
    
    if (!user_name || !email || !password) {
      ctx.body = { code: 400, message: 'Username, email, and password are required' };
      return;
    }
    
    // Check if user already exists
    const existingUser = await userRepository.findByUsername(user_name);
    if (existingUser) {
      ctx.body = { code: 400, message: 'Username already exists' };
      return;
    }
    
    const existingEmail = await userRepository.findByEmail(email);
    if (existingEmail) {
      ctx.body = { code: 400, message: 'Email already exists' };
      return;
    }
    
    const user = await userRepository.create(
      { user_name, email, password, role, department, display_name },
      currentUser.userId?.toString() || currentUser.id
    );
    
    const { password_hash, ...safeUser } = user;
    ctx.body = { code: 200, result: { user: safeUser }, message: 'User created successfully' };
  } catch (err) {
    console.error('[Users] Create error:', err);
    ctx.body = { code: 500, message: 'Failed to create user' };
  }
});

// PUT /api/users/:id - Update user (admin or self)
router.put('/:id', async (ctx: Context) => {
  try {
    const currentUser = getCurrentUser(ctx);
    const { id } = ctx.params;
    
    // Allow self-update or admin update
    const isSelf = currentUser.userId?.toString() === id || currentUser.id === id;
    if (!isSelf && !isAdmin(ctx)) {
      ctx.body = { code: 403, message: 'Not authorized' };
      return;
    }
    
    const { email, role, department, display_name, is_active, password } = ctx.request.body as any;
    
    const updates: any = {};
    if (email) updates.email = email;
    if (department) updates.department = department;
    if (display_name) updates.display_name = display_name;
    if (password) updates.password_hash = password;
    
    // Only admin can change role and active status
    if (isAdmin(ctx)) {
      if (role) updates.role = role;
      if (is_active !== undefined) updates.is_active = is_active;
    }
    
    const user = await userRepository.update(id, updates);
    const { password_hash, ...safeUser } = user;
    
    ctx.body = { code: 200, result: { user: safeUser }, message: 'User updated successfully' };
  } catch (err) {
    console.error('[Users] Update error:', err);
    ctx.body = { code: 500, message: 'Failed to update user' };
  }
});

// DELETE /api/users/:id - Soft delete user (admin only)
router.delete('/:id', async (ctx: Context) => {
  try {
    if (!isAdmin(ctx)) {
      ctx.body = { code: 403, message: 'Admin only' };
      return;
    }
    
    const { id } = ctx.params;
    await userRepository.softDelete(id);
    
    ctx.body = { code: 200, message: 'User deleted successfully' };
  } catch (err) {
    console.error('[Users] Delete error:', err);
    ctx.body = { code: 500, message: 'Failed to delete user' };
  }
});

export default router;
