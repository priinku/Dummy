import Router from 'koa-router';
import { Context } from 'koa';
import { recommendationRepository } from '../supabase/repositories/recommendationRepository';
import { fileRepository } from '../supabase/repositories/fileRepository';

const router = new Router({ prefix: '/api/recommendations' });

// GET /api/recommendations - Get recommendations based on input
router.get('/', async (ctx: Context) => {
  try {
    const { q, category, lang = 'en' } = ctx.query;
    const language = (lang as string) === 'ja' ? 'ja' : 'en';
    
    let recommendations;
    
    if (q && typeof q === 'string' && q.trim()) {
      // Get recommendations based on input keywords
      recommendations = await recommendationRepository.getByKeywords(q, language, 5);
    } else if (category && typeof category === 'string') {
      // Get recommendations for a specific category
      recommendations = await recommendationRepository.getByCategory(
        category as any,
        language,
        5
      );
    } else {
      // Get popular recommendations
      recommendations = await recommendationRepository.getPopular(5);
    }
    
    // Format for display
    const formatted = recommendations.map(rec => ({
      id: rec.id,
      text: language === 'ja' ? rec.question_template_ja : rec.question_template,
      text_alt: language === 'ja' ? rec.question_template : rec.question_template_ja,
      category: rec.category,
      priority: rec.priority,
    }));
    
    ctx.body = { code: 200, result: { recommendations: formatted } };
  } catch (err) {
    console.error('[Recommendations] Error:', err);
    ctx.body = { code: 200, result: { recommendations: [] } };
  }
});

// POST /api/recommendations/track - Track recommendation usage
router.post('/track/:id', async (ctx: Context) => {
  try {
    const { id } = ctx.params;
    await recommendationRepository.incrementUsage(id);
    ctx.body = { code: 200, message: 'Tracked' };
  } catch (err) {
    ctx.body = { code: 200, message: 'OK' };
  }
});

// GET /api/recommendations/classify - Classify a question
router.get('/classify', async (ctx: Context) => {
  try {
    const { q } = ctx.query;
    
    if (!q || typeof q !== 'string') {
      ctx.body = { code: 400, message: 'Query required' };
      return;
    }
    
    const category = await fileRepository.classifyQuestion(q);
    
    ctx.body = { code: 200, result: { category } };
  } catch (err) {
    ctx.body = { code: 200, result: { category: 'others' } };
  }
});

export default router;
