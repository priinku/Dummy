-- Supabase PostgreSQL Production Schema
-- All tables with proper relations, indexes, timestamps, and soft-delete support

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Roles enum
CREATE TYPE user_role AS ENUM ('admin', 'user', 'manager');
-- File categories enum
CREATE TYPE file_category AS ENUM ('general_affairs', 'hr', 'accounting', 'others');
-- Notification types enum
CREATE TYPE notification_type AS ENUM ('broadcast', 'direct', 'system', 'reply');
-- Ticket status enum
CREATE TYPE ticket_status AS ENUM ('open', 'in_progress', 'resolved', 'closed');

-- ============================================
-- USERS TABLE
-- ============================================
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_name VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role user_role DEFAULT 'user',
    department VARCHAR(100),
    display_name VARCHAR(200),
    avatar_url TEXT,
    is_active BOOLEAN DEFAULT true,
    last_login_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    deleted_at TIMESTAMPTZ,
    created_by UUID REFERENCES users(id),
    CONSTRAINT users_email_check CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
);

CREATE INDEX idx_users_email ON users(email) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_role ON users(role) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_department ON users(department) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_active ON users(is_active) WHERE deleted_at IS NULL;

-- ============================================
-- FILE CATEGORIES TABLE
-- ============================================
CREATE TABLE file_categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    name_ja VARCHAR(100) NOT NULL,
    slug VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    description_ja TEXT,
    keywords TEXT[], -- Array of keywords for auto-classification
    keywords_ja TEXT[],
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insert default categories
INSERT INTO file_categories (name, name_ja, slug, keywords, keywords_ja) VALUES
('General Affairs', '総務', 'general_affairs', 
 ARRAY['general', 'office', 'facilities', 'equipment', 'supplies', 'maintenance', 'building', 'security', 'parking', 'cafeteria'],
 ARRAY['総務', '事務', '設備', '備品', 'メンテナンス', '建物', 'セキュリティ', '駐車場', '食堂']),
('Human Resources', '人事', 'hr',
 ARRAY['hr', 'human resources', 'leave', 'vacation', 'salary', 'benefits', 'training', 'promotion', 'employee', 'attendance', 'payroll', 'hiring', 'recruitment', 'performance', 'appraisal'],
 ARRAY['人事', '休暇', '有給', '給与', '福利厚生', '研修', '昇進', '従業員', '出勤', '給与計算', '採用', '評価']),
('Accounting', '経理', 'accounting',
 ARRAY['accounting', 'finance', 'invoice', 'expense', 'budget', 'reimbursement', 'tax', 'payment', 'receipt', 'audit', 'financial'],
 ARRAY['経理', '財務', '請求書', '経費', '予算', '精算', '税金', '支払い', '領収書', '監査']),
('Others', 'その他', 'others',
 ARRAY['other', 'misc', 'general'],
 ARRAY['その他', '一般']);

-- ============================================
-- FILES TABLE
-- ============================================
CREATE TABLE files (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    filename VARCHAR(255) NOT NULL,
    original_filename VARCHAR(255) NOT NULL,
    storage_key VARCHAR(500) NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    size_bytes BIGINT NOT NULL,
    category_id UUID REFERENCES file_categories(id),
    category file_category DEFAULT 'others',
    uploaded_by UUID REFERENCES users(id),
    tags TEXT[],
    metadata JSONB DEFAULT '{}',
    is_indexed BOOLEAN DEFAULT false,
    indexed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

CREATE INDEX idx_files_category ON files(category_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_files_category_enum ON files(category) WHERE deleted_at IS NULL;
CREATE INDEX idx_files_uploaded_by ON files(uploaded_by) WHERE deleted_at IS NULL;
CREATE INDEX idx_files_storage_key ON files(storage_key);
CREATE INDEX idx_files_tags ON files USING GIN(tags) WHERE deleted_at IS NULL;

-- ============================================
-- CHAT HISTORY TABLE
-- ============================================
CREATE TABLE chat_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    task_id VARCHAR(50) NOT NULL,
    user_id UUID REFERENCES users(id),
    title VARCHAR(500),
    messages JSONB DEFAULT '[]',
    file_ids UUID[],
    category file_category,
    metadata JSONB DEFAULT '{}',
    is_archived BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

CREATE INDEX idx_chat_history_user ON chat_history(user_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_chat_history_task ON chat_history(task_id);
CREATE INDEX idx_chat_history_category ON chat_history(category) WHERE deleted_at IS NULL;
CREATE INDEX idx_chat_history_created ON chat_history(created_at DESC) WHERE deleted_at IS NULL;

-- ============================================
-- NOTIFICATIONS TABLE
-- ============================================
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sender_id UUID REFERENCES users(id),
    recipient_id UUID REFERENCES users(id),
    recipient_username VARCHAR(100), -- For @username targeting
    notification_type notification_type DEFAULT 'direct',
    subject VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    is_broadcast BOOLEAN DEFAULT false,
    is_read BOOLEAN DEFAULT false,
    read_at TIMESTAMPTZ,
    parent_id UUID REFERENCES notifications(id),
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

CREATE INDEX idx_notifications_recipient ON notifications(recipient_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_notifications_sender ON notifications(sender_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_notifications_username ON notifications(recipient_username) WHERE deleted_at IS NULL;
CREATE INDEX idx_notifications_unread ON notifications(recipient_id, is_read) WHERE deleted_at IS NULL AND is_read = false;
CREATE INDEX idx_notifications_broadcast ON notifications(is_broadcast) WHERE deleted_at IS NULL AND is_broadcast = true;
CREATE INDEX idx_notifications_type ON notifications(notification_type) WHERE deleted_at IS NULL;

-- ============================================
-- MESSAGE THREADS TABLE
-- ============================================
CREATE TABLE message_threads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    subject VARCHAR(255) NOT NULL,
    participants UUID[] NOT NULL,
    last_message_at TIMESTAMPTZ DEFAULT NOW(),
    message_count INT DEFAULT 0,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

CREATE INDEX idx_threads_participants ON message_threads USING GIN(participants) WHERE deleted_at IS NULL;
CREATE INDEX idx_threads_last_message ON message_threads(last_message_at DESC) WHERE deleted_at IS NULL;

-- ============================================
-- THREAD MESSAGES TABLE
-- ============================================
CREATE TABLE thread_messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    thread_id UUID REFERENCES message_threads(id) ON DELETE CASCADE,
    sender_id UUID REFERENCES users(id),
    content TEXT NOT NULL,
    attachments JSONB DEFAULT '[]',
    is_read_by UUID[] DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_thread_messages_thread ON thread_messages(thread_id);
CREATE INDEX idx_thread_messages_sender ON thread_messages(sender_id);

-- ============================================
-- SUPPORT TICKETS TABLE
-- ============================================
CREATE TABLE support_tickets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    subject VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    status ticket_status DEFAULT 'open',
    priority INT DEFAULT 1,
    assigned_to UUID REFERENCES users(id),
    resolved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

CREATE INDEX idx_tickets_user ON support_tickets(user_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_tickets_status ON support_tickets(status) WHERE deleted_at IS NULL;
CREATE INDEX idx_tickets_assigned ON support_tickets(assigned_to) WHERE deleted_at IS NULL;

-- ============================================
-- FEEDBACK TABLE
-- ============================================
CREATE TABLE feedback (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    chat_id UUID REFERENCES chat_history(id),
    output_id VARCHAR(50),
    rating INT CHECK (rating >= 1 AND rating <= 5),
    feedback_type VARCHAR(50), -- 'positive', 'negative', 'suggestion'
    comment TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_feedback_user ON feedback(user_id);
CREATE INDEX idx_feedback_chat ON feedback(chat_id);
CREATE INDEX idx_feedback_rating ON feedback(rating);

-- ============================================
-- ANALYTICS TABLE
-- ============================================
CREATE TABLE analytics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_type VARCHAR(100) NOT NULL,
    user_id UUID REFERENCES users(id),
    session_id VARCHAR(100),
    page_path VARCHAR(500),
    action VARCHAR(100),
    label VARCHAR(255),
    value NUMERIC,
    metadata JSONB DEFAULT '{}',
    user_agent TEXT,
    ip_address INET,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_analytics_event ON analytics(event_type);
CREATE INDEX idx_analytics_user ON analytics(user_id);
CREATE INDEX idx_analytics_created ON analytics(created_at DESC);
CREATE INDEX idx_analytics_session ON analytics(session_id);

-- ============================================
-- RECOMMENDATIONS TABLE (for ChatGPT-style suggestions)
-- ============================================
CREATE TABLE recommendations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    category file_category,
    keywords TEXT[] NOT NULL,
    keywords_ja TEXT[],
    question_template VARCHAR(500) NOT NULL,
    question_template_ja VARCHAR(500) NOT NULL,
    priority INT DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    usage_count INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_recommendations_category ON recommendations(category) WHERE is_active = true;
CREATE INDEX idx_recommendations_keywords ON recommendations USING GIN(keywords) WHERE is_active = true;
CREATE INDEX idx_recommendations_priority ON recommendations(priority DESC) WHERE is_active = true;

-- Insert default recommendations
INSERT INTO recommendations (category, keywords, keywords_ja, question_template, question_template_ja, priority) VALUES
('hr', ARRAY['leave', 'vacation', 'holiday'], ARRAY['休暇', '有給'], 'How many vacation days do I have left?', '残りの有給休暇は何日ですか？', 10),
('hr', ARRAY['salary', 'pay', 'wage'], ARRAY['給与', '給料'], 'When is the next payday?', '次の給料日はいつですか？', 9),
('hr', ARRAY['benefits', 'insurance'], ARRAY['福利厚生', '保険'], 'What benefits am I eligible for?', '私が受けられる福利厚生は何ですか？', 8),
('hr', ARRAY['training', 'development'], ARRAY['研修', '教育'], 'What training programs are available?', '利用可能な研修プログラムは何ですか？', 7),
('accounting', ARRAY['expense', 'reimbursement'], ARRAY['経費', '精算'], 'How do I submit an expense report?', '経費報告書の提出方法は？', 10),
('accounting', ARRAY['invoice', 'payment'], ARRAY['請求書', '支払い'], 'What is the invoice submission process?', '請求書の提出プロセスは？', 9),
('general_affairs', ARRAY['equipment', 'supplies'], ARRAY['備品', '消耗品'], 'How do I request office supplies?', '事務用品の申請方法は？', 8),
('general_affairs', ARRAY['meeting', 'room', 'booking'], ARRAY['会議', '予約'], 'How do I book a meeting room?', '会議室の予約方法は？', 9);

-- ============================================
-- GEN TASKS TABLE (for LLM task management)
-- ============================================
CREATE TABLE gen_tasks (
    id VARCHAR(50) PRIMARY KEY,
    user_id UUID REFERENCES users(id),
    task_type VARCHAR(50) DEFAULT 'chat',
    form_data TEXT,
    status VARCHAR(50) DEFAULT 'WAIT',
    category file_category,
    created_by VARCHAR(100),
    updated_by VARCHAR(100),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_gen_tasks_user ON gen_tasks(user_id);
CREATE INDEX idx_gen_tasks_status ON gen_tasks(status);
CREATE INDEX idx_gen_tasks_category ON gen_tasks(category);

-- ============================================
-- GEN TASK OUTPUTS TABLE
-- ============================================
CREATE TABLE gen_task_outputs (
    id SERIAL PRIMARY KEY,
    task_id VARCHAR(50) REFERENCES gen_tasks(id) ON DELETE CASCADE,
    metadata TEXT,
    sort_order INT,
    content TEXT,
    status VARCHAR(50) DEFAULT 'WAIT',
    feedback VARCHAR(50),
    created_by VARCHAR(100),
    updated_by VARCHAR(100),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_gen_task_outputs_task ON gen_task_outputs(task_id);
CREATE INDEX idx_gen_task_outputs_status ON gen_task_outputs(status);

-- ============================================
-- USER SESSIONS TABLE
-- ============================================
CREATE TABLE user_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    token_hash VARCHAR(255) NOT NULL,
    refresh_token_hash VARCHAR(255),
    expires_at TIMESTAMPTZ NOT NULL,
    ip_address INET,
    user_agent TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    last_activity_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_sessions_user ON user_sessions(user_id) WHERE is_active = true;
CREATE INDEX idx_sessions_token ON user_sessions(token_hash);
CREATE INDEX idx_sessions_expires ON user_sessions(expires_at);

-- ============================================
-- AUDIT LOG TABLE
-- ============================================
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(100),
    entity_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_audit_user ON audit_logs(user_id);
CREATE INDEX idx_audit_action ON audit_logs(action);
CREATE INDEX idx_audit_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_created ON audit_logs(created_at DESC);

-- ============================================
-- FUNCTIONS AND TRIGGERS
-- ============================================

-- Auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply trigger to all tables with updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_files_updated_at BEFORE UPDATE ON files FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_chat_history_updated_at BEFORE UPDATE ON chat_history FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_notifications_updated_at BEFORE UPDATE ON notifications FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_message_threads_updated_at BEFORE UPDATE ON message_threads FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_support_tickets_updated_at BEFORE UPDATE ON support_tickets FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_recommendations_updated_at BEFORE UPDATE ON recommendations FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_gen_tasks_updated_at BEFORE UPDATE ON gen_tasks FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER update_gen_task_outputs_updated_at BEFORE UPDATE ON gen_task_outputs FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Insert default admin user (password: admin123)
INSERT INTO users (user_name, email, password_hash, role, department, display_name) VALUES
('admin', 'admin@company.com', '$2a$10$7j7.uRiNoqQ9sNHllpnrLOnfwdo1W.XQo0h7GX/Fk1RcqL7Lt30j6', 'admin', 'IT', 'Administrator'),
('test_user', 'test@company.com', '$2a$10$7j7.uRiNoqQ9sNHllpnrLOnfwdo1W.XQo0h7GX/Fk1RcqL7Lt30j6', 'user', 'HR', 'Test User');

-- Row Level Security Policies
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE files ENABLE ROW LEVEL SECURITY;

-- Users can see their own data, admins can see all
CREATE POLICY users_select_policy ON users FOR SELECT USING (true);
CREATE POLICY users_update_policy ON users FOR UPDATE USING (id = current_setting('app.current_user_id')::uuid OR current_setting('app.current_user_role', true) = 'admin');

-- Notifications: users see their own, admins see admin-targeted
CREATE POLICY notifications_select_policy ON notifications FOR SELECT USING (
    recipient_id = current_setting('app.current_user_id', true)::uuid 
    OR sender_id = current_setting('app.current_user_id', true)::uuid
    OR is_broadcast = true
    OR current_setting('app.current_user_role', true) = 'admin'
);
