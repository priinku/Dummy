import { getSupabase } from '../client';
import bcrypt from 'bcryptjs';

export interface User {
  id: string;
  user_name: string;
  email: string;
  password_hash?: string;
  role: 'admin' | 'user' | 'manager';
  department?: string;
  display_name?: string;
  avatar_url?: string;
  is_active: boolean;
  last_login_at?: string;
  created_at: string;
  updated_at: string;
  deleted_at?: string;
  created_by?: string;
}

export interface CreateUserInput {
  user_name: string;
  email: string;
  password: string;
  role?: 'admin' | 'user' | 'manager';
  department?: string;
  display_name?: string;
}

export const userRepository = {
  async findByUsername(username: string): Promise<User | null> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('user_name', username)
      .is('deleted_at', null)
      .single();
    
    if (error) return null;
    return data;
  },

  async findByEmail(email: string): Promise<User | null> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('email', email)
      .is('deleted_at', null)
      .single();
    
    if (error) return null;
    return data;
  },

  async findById(id: string): Promise<User | null> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', id)
      .is('deleted_at', null)
      .single();
    
    if (error) return null;
    return data;
  },

  async findAll(filters?: { role?: string; department?: string; is_active?: boolean }): Promise<User[]> {
    const supabase = getSupabase();
    let query = supabase
      .from('users')
      .select('id, user_name, email, role, department, display_name, avatar_url, is_active, last_login_at, created_at, updated_at')
      .is('deleted_at', null);
    
    if (filters?.role) query = query.eq('role', filters.role);
    if (filters?.department) query = query.eq('department', filters.department);
    if (filters?.is_active !== undefined) query = query.eq('is_active', filters.is_active);
    
    const { data, error } = await query.order('created_at', { ascending: false });
    
    if (error) throw error;
    return data || [];
  },

  async create(input: CreateUserInput, createdBy?: string): Promise<User> {
    const supabase = getSupabase();
    const passwordHash = await bcrypt.hash(input.password, 10);
    
    const { data, error } = await supabase
      .from('users')
      .insert({
        user_name: input.user_name,
        email: input.email,
        password_hash: passwordHash,
        role: input.role || 'user',
        department: input.department,
        display_name: input.display_name || input.user_name,
        created_by: createdBy,
      })
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async update(id: string, updates: Partial<Omit<User, 'id' | 'created_at'>>): Promise<User> {
    const supabase = getSupabase();
    
    if (updates.password_hash) {
      updates.password_hash = await bcrypt.hash(updates.password_hash, 10);
    }
    
    const { data, error } = await supabase
      .from('users')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async softDelete(id: string): Promise<void> {
    const supabase = getSupabase();
    const { error } = await supabase
      .from('users')
      .update({ deleted_at: new Date().toISOString(), is_active: false })
      .eq('id', id);
    
    if (error) throw error;
  },

  async verifyPassword(user: User, password: string): Promise<boolean> {
    if (!user.password_hash) return false;
    return bcrypt.compare(password, user.password_hash);
  },

  async updateLastLogin(id: string): Promise<void> {
    const supabase = getSupabase();
    await supabase
      .from('users')
      .update({ last_login_at: new Date().toISOString() })
      .eq('id', id);
  },

  async getDepartments(): Promise<string[]> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('users')
      .select('department')
      .is('deleted_at', null)
      .not('department', 'is', null);
    
    if (error) throw error;
    const departments = [...new Set(data?.map(d => d.department).filter(Boolean))];
    return departments as string[];
  },
};
