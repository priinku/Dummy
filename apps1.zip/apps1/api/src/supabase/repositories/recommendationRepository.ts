import { getSupabase } from '../client';
import { FileCategory } from './fileRepository';

export interface Recommendation {
  id: string;
  category?: FileCategory;
  keywords: string[];
  keywords_ja?: string[];
  question_template: string;
  question_template_ja: string;
  priority: number;
  is_active: boolean;
  usage_count: number;
  created_at: string;
  updated_at: string;
}

export const recommendationRepository = {
  async getByKeywords(input: string, language: 'en' | 'ja' = 'en', limit = 5): Promise<Recommendation[]> {
    const supabase = getSupabase();
    const inputLower = input.toLowerCase();
    const words = inputLower.split(/\s+/).filter(w => w.length > 2);
    
    const { data, error } = await supabase
      .from('recommendations')
      .select('*')
      .eq('is_active', true)
      .order('priority', { ascending: false })
      .limit(20);
    
    if (error) throw error;
    if (!data) return [];
    
    // Score and rank recommendations
    const scored = data.map(rec => {
      let score = 0;
      const keywords = language === 'ja' ? [...(rec.keywords_ja || []), ...rec.keywords] : [...rec.keywords, ...(rec.keywords_ja || [])];
      
      for (const keyword of keywords) {
        if (inputLower.includes(keyword.toLowerCase())) {
          score += keyword.length * 2;
        }
        for (const word of words) {
          if (keyword.toLowerCase().includes(word)) {
            score += word.length;
          }
        }
      }
      return { ...rec, score };
    });
    
    return scored
      .filter(r => r.score > 0)
      .sort((a, b) => b.score - a.score || b.priority - a.priority)
      .slice(0, limit);
  },

  async getByCategory(category: FileCategory, language: 'en' | 'ja' = 'en', limit = 5): Promise<Recommendation[]> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('recommendations')
      .select('*')
      .eq('category', category)
      .eq('is_active', true)
      .order('priority', { ascending: false })
      .limit(limit);
    
    if (error) throw error;
    return data || [];
  },

  async getPopular(limit = 5): Promise<Recommendation[]> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('recommendations')
      .select('*')
      .eq('is_active', true)
      .order('usage_count', { ascending: false })
      .order('priority', { ascending: false })
      .limit(limit);
    
    if (error) throw error;
    return data || [];
  },

  async incrementUsage(id: string): Promise<void> {
    const supabase = getSupabase();
    const { data } = await supabase
      .from('recommendations')
      .select('usage_count')
      .eq('id', id)
      .single();
    
    if (data) {
      await supabase
        .from('recommendations')
        .update({ usage_count: (data.usage_count || 0) + 1 })
        .eq('id', id);
    }
  },

  async create(input: Omit<Recommendation, 'id' | 'created_at' | 'updated_at' | 'usage_count'>): Promise<Recommendation> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('recommendations')
      .insert({ ...input, usage_count: 0 })
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async update(id: string, updates: Partial<Recommendation>): Promise<Recommendation> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('recommendations')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async deactivate(id: string): Promise<void> {
    const supabase = getSupabase();
    await supabase
      .from('recommendations')
      .update({ is_active: false })
      .eq('id', id);
  },

  formatForDisplay(rec: Recommendation, language: 'en' | 'ja'): string {
    return language === 'ja' ? rec.question_template_ja : rec.question_template;
  },
};
