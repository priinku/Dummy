import { getSupabase } from '../client';

export interface Notification {
  id: string;
  sender_id?: string;
  recipient_id?: string;
  recipient_username?: string;
  notification_type: 'broadcast' | 'direct' | 'system' | 'reply';
  subject: string;
  content: string;
  is_broadcast: boolean;
  is_read: boolean;
  read_at?: string;
  parent_id?: string;
  metadata?: Record<string, any>;
  created_at: string;
  updated_at: string;
  deleted_at?: string;
  sender?: { user_name: string; display_name: string; role: string };
}

export interface CreateNotificationInput {
  sender_id?: string;
  recipient_id?: string;
  recipient_username?: string;
  notification_type?: 'broadcast' | 'direct' | 'system' | 'reply';
  subject: string;
  content: string;
  is_broadcast?: boolean;
  parent_id?: string;
  metadata?: Record<string, any>;
}

export const notificationRepository = {
  async getForUser(userId: string, username: string, isAdmin: boolean): Promise<Notification[]> {
    const supabase = getSupabase();
    
    let query = supabase
      .from('notifications')
      .select(`
        *,
        sender:users!notifications_sender_id_fkey(user_name, display_name, role)
      `)
      .is('deleted_at', null)
      .order('created_at', { ascending: false })
      .limit(50);
    
    if (isAdmin) {
      // Admin sees: messages sent TO admin (from users) + broadcasts they sent
      query = query.or(`recipient_id.eq.${userId},and(notification_type.eq.direct,recipient_username.is.null)`);
    } else {
      // User sees: direct messages to them + broadcasts + @username mentions
      query = query.or(`recipient_id.eq.${userId},is_broadcast.eq.true,recipient_username.eq.${username}`);
    }
    
    const { data, error } = await query;
    if (error) throw error;
    return data || [];
  },

  async getUnreadCount(userId: string, username: string, isAdmin: boolean): Promise<number> {
    const supabase = getSupabase();
    
    let query = supabase
      .from('notifications')
      .select('id', { count: 'exact', head: true })
      .is('deleted_at', null)
      .eq('is_read', false);
    
    if (isAdmin) {
      query = query.or(`recipient_id.eq.${userId},and(notification_type.eq.direct,recipient_username.is.null)`);
    } else {
      query = query.or(`recipient_id.eq.${userId},is_broadcast.eq.true,recipient_username.eq.${username}`);
    }
    
    const { count, error } = await query;
    if (error) throw error;
    return count || 0;
  },

  async create(input: CreateNotificationInput): Promise<Notification> {
    const supabase = getSupabase();
    
    // Parse @username from content if present
    const mentionMatch = input.content.match(/@(\w+)/);
    if (mentionMatch && !input.recipient_username) {
      input.recipient_username = mentionMatch[1];
      input.notification_type = 'direct';
    }
    
    const { data, error } = await supabase
      .from('notifications')
      .insert({
        sender_id: input.sender_id,
        recipient_id: input.recipient_id,
        recipient_username: input.recipient_username,
        notification_type: input.notification_type || 'direct',
        subject: input.subject,
        content: input.content,
        is_broadcast: input.is_broadcast || false,
        parent_id: input.parent_id,
        metadata: input.metadata || {},
      })
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async createBroadcast(senderId: string, subject: string, content: string): Promise<Notification> {
    return this.create({
      sender_id: senderId,
      notification_type: 'broadcast',
      subject,
      content,
      is_broadcast: true,
    });
  },

  async createTargeted(senderId: string, targetUsername: string, subject: string, content: string): Promise<Notification> {
    const supabase = getSupabase();
    
    // Find user by username
    const { data: targetUser } = await supabase
      .from('users')
      .select('id')
      .eq('user_name', targetUsername)
      .single();
    
    return this.create({
      sender_id: senderId,
      recipient_id: targetUser?.id,
      recipient_username: targetUsername,
      notification_type: 'direct',
      subject,
      content,
      is_broadcast: false,
    });
  },

  async markAsRead(id: string, userId: string): Promise<void> {
    const supabase = getSupabase();
    const { error } = await supabase
      .from('notifications')
      .update({ is_read: true, read_at: new Date().toISOString() })
      .eq('id', id);
    
    if (error) throw error;
  },

  async markAllAsRead(userId: string, username: string, isAdmin: boolean): Promise<void> {
    const supabase = getSupabase();
    
    let query = supabase
      .from('notifications')
      .update({ is_read: true, read_at: new Date().toISOString() })
      .eq('is_read', false)
      .is('deleted_at', null);
    
    if (isAdmin) {
      query = query.or(`recipient_id.eq.${userId},and(notification_type.eq.direct,recipient_username.is.null)`);
    } else {
      query = query.or(`recipient_id.eq.${userId},is_broadcast.eq.true,recipient_username.eq.${username}`);
    }
    
    const { error } = await query;
    if (error) throw error;
  },

  async reply(parentId: string, senderId: string, content: string): Promise<Notification> {
    const supabase = getSupabase();
    
    // Get parent notification
    const { data: parent } = await supabase
      .from('notifications')
      .select('sender_id, subject')
      .eq('id', parentId)
      .single();
    
    return this.create({
      sender_id: senderId,
      recipient_id: parent?.sender_id,
      notification_type: 'reply',
      subject: `Re: ${parent?.subject || 'No Subject'}`,
      content,
      parent_id: parentId,
    });
  },

  async softDelete(id: string): Promise<void> {
    const supabase = getSupabase();
    const { error } = await supabase
      .from('notifications')
      .update({ deleted_at: new Date().toISOString() })
      .eq('id', id);
    
    if (error) throw error;
  },
};
