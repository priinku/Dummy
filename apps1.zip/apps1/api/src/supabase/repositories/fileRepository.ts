import { getSupabase } from '../client';

export type FileCategory = 'general_affairs' | 'hr' | 'accounting' | 'others';

export interface FileRecord {
  id: string;
  filename: string;
  original_filename: string;
  storage_key: string;
  mime_type: string;
  size_bytes: number;
  category_id?: string;
  category: FileCategory;
  uploaded_by?: string;
  tags?: string[];
  metadata?: Record<string, any>;
  is_indexed: boolean;
  indexed_at?: string;
  created_at: string;
  updated_at: string;
  deleted_at?: string;
}

export interface FileCategoryRecord {
  id: string;
  name: string;
  name_ja: string;
  slug: string;
  description?: string;
  description_ja?: string;
  keywords: string[];
  keywords_ja: string[];
}

const CATEGORY_KEYWORDS: Record<FileCategory, { en: string[]; ja: string[] }> = {
  hr: {
    en: ['hr', 'human resources', 'leave', 'vacation', 'salary', 'benefits', 'training', 'promotion', 'employee', 'attendance', 'payroll', 'hiring', 'recruitment', 'performance', 'appraisal', 'holiday', 'bonus', 'insurance'],
    ja: ['人事', '休暇', '有給', '給与', '福利厚生', '研修', '昇進', '従業員', '出勤', '給与計算', '採用', '評価', 'ボーナス', '保険'],
  },
  accounting: {
    en: ['accounting', 'finance', 'invoice', 'expense', 'budget', 'reimbursement', 'tax', 'payment', 'receipt', 'audit', 'financial', 'cost', 'revenue'],
    ja: ['経理', '財務', '請求書', '経費', '予算', '精算', '税金', '支払い', '領収書', '監査', 'コスト', '収益'],
  },
  general_affairs: {
    en: ['general', 'office', 'facilities', 'equipment', 'supplies', 'maintenance', 'building', 'security', 'parking', 'cafeteria', 'meeting', 'room'],
    ja: ['総務', '事務', '設備', '備品', 'メンテナンス', '建物', 'セキュリティ', '駐車場', '食堂', '会議室'],
  },
  others: {
    en: ['other', 'misc', 'general'],
    ja: ['その他', '一般'],
  },
};

export const fileRepository = {
  async classifyQuestion(question: string): Promise<FileCategory> {
    const questionLower = question.toLowerCase();
    
    let maxScore = 0;
    let bestCategory: FileCategory = 'others';
    
    for (const [category, keywords] of Object.entries(CATEGORY_KEYWORDS)) {
      let score = 0;
      for (const keyword of [...keywords.en, ...keywords.ja]) {
        if (questionLower.includes(keyword.toLowerCase())) {
          score += keyword.length; // Longer matches get higher scores
        }
      }
      if (score > maxScore) {
        maxScore = score;
        bestCategory = category as FileCategory;
      }
    }
    
    return bestCategory;
  },

  async getByCategory(category: FileCategory): Promise<FileRecord[]> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('files')
      .select('*')
      .eq('category', category)
      .is('deleted_at', null)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data || [];
  },

  async getAll(filters?: { category?: FileCategory; uploaded_by?: string }): Promise<FileRecord[]> {
    const supabase = getSupabase();
    let query = supabase
      .from('files')
      .select('*')
      .is('deleted_at', null);
    
    if (filters?.category) query = query.eq('category', filters.category);
    if (filters?.uploaded_by) query = query.eq('uploaded_by', filters.uploaded_by);
    
    const { data, error } = await query.order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async create(input: Omit<FileRecord, 'id' | 'created_at' | 'updated_at' | 'deleted_at'>): Promise<FileRecord> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('files')
      .insert(input)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async updateCategory(id: string, category: FileCategory): Promise<FileRecord> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('files')
      .update({ category })
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async markIndexed(id: string): Promise<void> {
    const supabase = getSupabase();
    await supabase
      .from('files')
      .update({ is_indexed: true, indexed_at: new Date().toISOString() })
      .eq('id', id);
  },

  async softDelete(id: string): Promise<void> {
    const supabase = getSupabase();
    await supabase
      .from('files')
      .update({ deleted_at: new Date().toISOString() })
      .eq('id', id);
  },

  async getCategories(): Promise<FileCategoryRecord[]> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('file_categories')
      .select('*')
      .order('name');
    
    if (error) throw error;
    return data || [];
  },

  async getStorageKeysByCategory(category: FileCategory): Promise<string[]> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('files')
      .select('storage_key')
      .eq('category', category)
      .eq('is_indexed', true)
      .is('deleted_at', null);
    
    if (error) throw error;
    return data?.map(f => f.storage_key) || [];
  },
};
