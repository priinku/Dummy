import { getSupabase } from '../client';
import { FileCategory } from './fileRepository';

export interface ChatHistory {
  id: string;
  task_id: string;
  user_id?: string;
  title?: string;
  messages: any[];
  file_ids?: string[];
  category?: FileCategory;
  metadata?: Record<string, any>;
  is_archived: boolean;
  created_at: string;
  updated_at: string;
  deleted_at?: string;
}

export const chatRepository = {
  async getByTaskId(taskId: string): Promise<ChatHistory | null> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('chat_history')
      .select('*')
      .eq('task_id', taskId)
      .is('deleted_at', null)
      .single();
    
    if (error) return null;
    return data;
  },

  async getByUserId(userId: string, limit = 50): Promise<ChatHistory[]> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('chat_history')
      .select('*')
      .eq('user_id', userId)
      .is('deleted_at', null)
      .order('updated_at', { ascending: false })
      .limit(limit);
    
    if (error) throw error;
    return data || [];
  },

  async create(input: Omit<ChatHistory, 'id' | 'created_at' | 'updated_at' | 'deleted_at' | 'is_archived'>): Promise<ChatHistory> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('chat_history')
      .insert({ ...input, is_archived: false })
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  async updateMessages(taskId: string, messages: any[]): Promise<void> {
    const supabase = getSupabase();
    await supabase
      .from('chat_history')
      .update({ messages })
      .eq('task_id', taskId);
  },

  async updateTitle(taskId: string, title: string): Promise<void> {
    const supabase = getSupabase();
    await supabase
      .from('chat_history')
      .update({ title })
      .eq('task_id', taskId);
  },

  async updateCategory(taskId: string, category: FileCategory): Promise<void> {
    const supabase = getSupabase();
    await supabase
      .from('chat_history')
      .update({ category })
      .eq('task_id', taskId);
  },

  async archive(taskId: string): Promise<void> {
    const supabase = getSupabase();
    await supabase
      .from('chat_history')
      .update({ is_archived: true })
      .eq('task_id', taskId);
  },

  async softDelete(taskId: string): Promise<void> {
    const supabase = getSupabase();
    await supabase
      .from('chat_history')
      .update({ deleted_at: new Date().toISOString() })
      .eq('task_id', taskId);
  },
};
