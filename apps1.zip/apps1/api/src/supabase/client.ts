import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { config } from '@config/index';

let supabaseClient: SupabaseClient | null = null;

export const getSupabase = (): SupabaseClient => {
  if (!supabaseClient) {
    const cfg = config as any;
    const supabaseUrl = cfg.Supabase?.url || process.env.SUPABASE_URL;
    const supabaseKey = cfg.Supabase?.anonKey || process.env.SUPABASE_ANON_KEY;
    
    if (!supabaseUrl || !supabaseKey) {
      throw new Error('Supabase URL and Anon Key are required');
    }
    
    supabaseClient = createClient(supabaseUrl, supabaseKey, {
      auth: {
        autoRefreshToken: true,
        persistSession: false,
      },
      db: {
        schema: 'public',
      },
    });
  }
  return supabaseClient;
};

export const getSupabaseAdmin = (): SupabaseClient => {
  const cfg = config as any;
  const supabaseUrl = cfg.Supabase?.url || process.env.SUPABASE_URL;
  const serviceRoleKey = cfg.Supabase?.serviceRoleKey || process.env.SUPABASE_SERVICE_ROLE_KEY;
  
  if (!supabaseUrl || !serviceRoleKey) {
    throw new Error('Supabase URL and Service Role Key are required for admin operations');
  }
  
  return createClient(supabaseUrl, serviceRoleKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  });
};

export type { SupabaseClient };
