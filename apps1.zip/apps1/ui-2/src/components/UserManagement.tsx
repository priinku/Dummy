import React, { useState, useEffect } from 'react';
import { Users, Plus, Edit2, Trash2, X, Check, Search } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { getToken } from '../utils/auth';

interface User {
  id: string;
  user_name: string;
  email: string;
  role: 'admin' | 'user' | 'manager';
  department?: string;
  display_name?: string;
  is_active: boolean;
  last_login_at?: string;
  created_at: string;
}

interface UserManagementProps {
  isOpen: boolean;
  onClose: () => void;
}

const DEPARTMENTS = ['General Affairs', 'Human Resources', 'Accounting', 'IT', 'Sales', 'Marketing', 'Operations', 'Other'];
const ROLES = ['user', 'manager', 'admin'];

export const UserManagement: React.FC<UserManagementProps> = ({ isOpen, onClose }) => {
  const { t } = useTranslation();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [formData, setFormData] = useState({
    user_name: '',
    email: '',
    password: '',
    role: 'user' as 'admin' | 'user' | 'manager',
    department: '',
    display_name: '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    if (isOpen) fetchUsers();
  }, [isOpen]);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const token = getToken();
      const res = await fetch('/dev-api/api/users', {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      const data = await res.json();
      if (data.code === 200) {
        setUsers(data.result.users || []);
      }
    } catch (err) {
      console.error('Failed to fetch users:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async () => {
    if (!formData.user_name || !formData.email || !formData.password) {
      setError(t('userManagement.required', 'All required fields must be filled'));
      return;
    }

    try {
      const token = getToken();
      const res = await fetch('/dev-api/api/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      
      if (data.code === 200) {
        setSuccess(t('userManagement.userCreated', 'User created successfully'));
        setShowCreateForm(false);
        resetForm();
        fetchUsers();
        setTimeout(() => setSuccess(''), 3000);
      } else {
        setError(data.message || 'Failed to create user');
      }
    } catch (err) {
      setError('Failed to create user');
    }
  };

  const handleUpdate = async () => {
    if (!editingUser) return;

    try {
      const token = getToken();
      const updates: any = {
        email: formData.email,
        department: formData.department,
        display_name: formData.display_name,
        role: formData.role,
      };
      if (formData.password) updates.password = formData.password;

      const res = await fetch(`/dev-api/api/users/${editingUser.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(updates),
      });
      const data = await res.json();
      
      if (data.code === 200) {
        setSuccess(t('userManagement.userUpdated', 'User updated successfully'));
        setEditingUser(null);
        resetForm();
        fetchUsers();
        setTimeout(() => setSuccess(''), 3000);
      } else {
        setError(data.message || 'Failed to update user');
      }
    } catch (err) {
      setError('Failed to update user');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm(t('common.confirm', 'Are you sure?'))) return;

    try {
      const token = getToken();
      const res = await fetch(`/dev-api/api/users/${id}`, {
        method: 'DELETE',
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      const data = await res.json();
      
      if (data.code === 200) {
        setSuccess(t('userManagement.userDeleted', 'User deleted successfully'));
        fetchUsers();
        setTimeout(() => setSuccess(''), 3000);
      }
    } catch (err) {
      setError('Failed to delete user');
    }
  };

  const resetForm = () => {
    setFormData({
      user_name: '',
      email: '',
      password: '',
      role: 'user',
      department: '',
      display_name: '',
    });
    setError('');
  };

  const startEdit = (user: User) => {
    setEditingUser(user);
    setFormData({
      user_name: user.user_name,
      email: user.email,
      password: '',
      role: user.role,
      department: user.department || '',
      display_name: user.display_name || '',
    });
    setShowCreateForm(false);
  };

  const filteredUsers = users.filter(u =>
    u.user_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.display_name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 rounded-xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-gray-700 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Users className="w-6 h-6 text-blue-400" />
            <h2 className="text-xl font-semibold text-white">
              {t('userManagement.title', 'User Management')}
            </h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Success/Error Messages */}
        {success && (
          <div className="mx-4 mt-4 p-3 bg-green-600/20 border border-green-500 rounded text-green-400 text-sm">
            {success}
          </div>
        )}
        {error && (
          <div className="mx-4 mt-4 p-3 bg-red-600/20 border border-red-500 rounded text-red-400 text-sm">
            {error}
          </div>
        )}

        {/* Actions Bar */}
        <div className="p-4 border-b border-gray-700 flex items-center gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={t('common.search', 'Search...')}
              className="w-full bg-gray-700 text-white rounded-lg pl-10 pr-4 py-2 text-sm"
            />
          </div>
          <button
            onClick={() => { setShowCreateForm(true); setEditingUser(null); resetForm(); }}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 text-sm font-medium"
          >
            <Plus className="w-4 h-4" />
            {t('userManagement.createUser', 'Create User')}
          </button>
        </div>

        {/* Create/Edit Form */}
        {(showCreateForm || editingUser) && (
          <div className="p-4 border-b border-gray-700 bg-gray-750">
            <h3 className="text-lg font-medium text-white mb-4">
              {editingUser ? t('userManagement.editUser', 'Edit User') : t('userManagement.createUser', 'Create User')}
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">
                  {t('userManagement.username', 'Username')} *
                </label>
                <input
                  type="text"
                  value={formData.user_name}
                  onChange={(e) => setFormData({ ...formData, user_name: e.target.value })}
                  disabled={!!editingUser}
                  className="w-full bg-gray-700 text-white rounded px-3 py-2 text-sm disabled:opacity-50"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">
                  {t('userManagement.email', 'Email')} *
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-gray-700 text-white rounded px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">
                  {t('userManagement.password', 'Password')} {!editingUser && '*'}
                </label>
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder={editingUser ? 'Leave blank to keep current' : ''}
                  className="w-full bg-gray-700 text-white rounded px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">
                  {t('userManagement.displayName', 'Display Name')}
                </label>
                <input
                  type="text"
                  value={formData.display_name}
                  onChange={(e) => setFormData({ ...formData, display_name: e.target.value })}
                  className="w-full bg-gray-700 text-white rounded px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">
                  {t('userManagement.role', 'Role')}
                </label>
                <select
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value as any })}
                  className="w-full bg-gray-700 text-white rounded px-3 py-2 text-sm"
                >
                  {ROLES.map(r => (
                    <option key={r} value={r}>{r.charAt(0).toUpperCase() + r.slice(1)}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">
                  {t('userManagement.department', 'Department')}
                </label>
                <select
                  value={formData.department}
                  onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                  className="w-full bg-gray-700 text-white rounded px-3 py-2 text-sm"
                >
                  <option value="">{t('userManagement.selectDepartment', 'Select Department')}</option>
                  {DEPARTMENTS.map(d => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-4">
              <button
                onClick={() => { setShowCreateForm(false); setEditingUser(null); resetForm(); }}
                className="px-4 py-2 text-gray-400 hover:text-white text-sm"
              >
                {t('common.cancel', 'Cancel')}
              </button>
              <button
                onClick={editingUser ? handleUpdate : handleCreate}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 text-sm"
              >
                <Check className="w-4 h-4" />
                {editingUser ? t('common.save', 'Save') : t('userManagement.createUser', 'Create')}
              </button>
            </div>
          </div>
        )}

        {/* Users List */}
        <div className="flex-1 overflow-y-auto">
          {loading ? (
            <div className="p-8 text-center text-gray-400">{t('common.loading', 'Loading...')}</div>
          ) : filteredUsers.length === 0 ? (
            <div className="p-8 text-center text-gray-400">{t('common.noData', 'No users found')}</div>
          ) : (
            <table className="w-full">
              <thead className="bg-gray-750 sticky top-0">
                <tr className="text-left text-sm text-gray-400">
                  <th className="px-4 py-3">{t('userManagement.username', 'Username')}</th>
                  <th className="px-4 py-3">{t('userManagement.email', 'Email')}</th>
                  <th className="px-4 py-3">{t('userManagement.role', 'Role')}</th>
                  <th className="px-4 py-3">{t('userManagement.department', 'Department')}</th>
                  <th className="px-4 py-3">{t('userManagement.status', 'Status')}</th>
                  <th className="px-4 py-3 text-right">{t('common.actions', 'Actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {filteredUsers.map((user) => (
                  <tr key={user.id} className="hover:bg-gray-750">
                    <td className="px-4 py-3">
                      <div>
                        <div className="text-white font-medium">{user.user_name}</div>
                        {user.display_name && (
                          <div className="text-sm text-gray-400">{user.display_name}</div>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-gray-300">{user.email}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        user.role === 'admin' ? 'bg-purple-600/20 text-purple-400' :
                        user.role === 'manager' ? 'bg-blue-600/20 text-blue-400' :
                        'bg-gray-600/20 text-gray-400'
                      }`}>
                        {user.role}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-300">{user.department || '-'}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        user.is_active ? 'bg-green-600/20 text-green-400' : 'bg-red-600/20 text-red-400'
                      }`}>
                        {user.is_active ? t('userManagement.active', 'Active') : t('userManagement.inactive', 'Inactive')}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => startEdit(user)}
                          className="p-1.5 text-gray-400 hover:text-blue-400 hover:bg-blue-600/10 rounded"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(user.id)}
                          className="p-1.5 text-gray-400 hover:text-red-400 hover:bg-red-600/10 rounded"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};

export default UserManagement;
