import React, { useState, useEffect } from 'react';
import { Sparkles, ChevronRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { getToken } from '../utils/auth';

interface Recommendation {
  id: string;
  text: string;
  text_alt: string;
  category?: string;
  priority: number;
}

interface RecommendationPopupProps {
  inputValue: string;
  onSelectRecommendation: (text: string) => void;
  visible: boolean;
  language?: 'en' | 'ja';
}

export const RecommendationPopup: React.FC<RecommendationPopupProps> = ({
  inputValue,
  onSelectRecommendation,
  visible,
  language = 'en',
}) => {
  const { t } = useTranslation();
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchRecommendations = async () => {
      if (!visible) return;
      
      setLoading(true);
      try {
        const token = getToken();
        const query = inputValue.trim() ? `q=${encodeURIComponent(inputValue)}` : '';
        const res = await fetch(`/dev-api/api/recommendations?${query}&lang=${language}`, {
          headers: token ? { Authorization: `Bearer ${token}` } : {},
        });
        const data = await res.json();
        if (data.code === 200) {
          setRecommendations(data.result.recommendations || []);
        }
      } catch (err) {
        console.error('Failed to fetch recommendations:', err);
      } finally {
        setLoading(false);
      }
    };

    const debounce = setTimeout(fetchRecommendations, 300);
    return () => clearTimeout(debounce);
  }, [inputValue, visible, language]);

  const handleSelect = async (rec: Recommendation) => {
    onSelectRecommendation(rec.text);
    
    // Track usage
    try {
      const token = getToken();
      await fetch(`/dev-api/api/recommendations/track/${rec.id}`, {
        method: 'POST',
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
    } catch (err) {
      // Ignore tracking errors
    }
  };

  if (!visible || recommendations.length === 0) return null;

  return (
    <div className="absolute bottom-full left-0 right-0 mb-2 bg-gray-800 rounded-lg shadow-xl border border-gray-700 overflow-hidden z-50">
      <div className="px-3 py-2 border-b border-gray-700 flex items-center gap-2">
        <Sparkles className="w-4 h-4 text-yellow-400" />
        <span className="text-sm font-medium text-gray-300">
          {inputValue.trim() 
            ? t('recommendations.basedOnInput', 'Based on your input')
            : t('recommendations.popular', 'Popular Questions')}
        </span>
      </div>
      
      <div className="max-h-48 overflow-y-auto">
        {loading ? (
          <div className="px-3 py-4 text-center text-gray-400 text-sm">
            {t('common.loading', 'Loading...')}
          </div>
        ) : (
          recommendations.map((rec) => (
            <button
              key={rec.id}
              onClick={() => handleSelect(rec)}
              className="w-full px-3 py-2.5 text-left hover:bg-gray-700 transition-colors flex items-center justify-between group"
            >
              <span className="text-sm text-gray-200 group-hover:text-white">
                {rec.text}
              </span>
              <ChevronRight className="w-4 h-4 text-gray-500 group-hover:text-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" />
            </button>
          ))
        )}
      </div>
      
      <div className="px-3 py-1.5 border-t border-gray-700 bg-gray-800/50">
        <span className="text-xs text-gray-500">
          {t('recommendations.clickToAsk', 'Click to ask')}
        </span>
      </div>
    </div>
  );
};

export default RecommendationPopup;
