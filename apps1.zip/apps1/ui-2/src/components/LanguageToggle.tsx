import React from 'react';
import { Globe } from 'lucide-react';
import { useTranslation } from 'react-i18next';

interface LanguageToggleProps {
  className?: string;
}

export const LanguageToggle: React.FC<LanguageToggleProps> = ({ className = '' }) => {
  const { i18n, t } = useTranslation();
  
  const toggleLanguage = () => {
    const newLang = i18n.language === 'ja' ? 'en' : 'ja';
    i18n.changeLanguage(newLang);
    localStorage.setItem('language', newLang);
  };

  return (
    <button
      onClick={toggleLanguage}
      className={`flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/10 transition-colors ${className}`}
      title={t('common.language', 'Language')}
    >
      <Globe className="w-5 h-5 text-slate-300" />
      <span className="text-sm font-medium text-slate-300">
        {i18n.language === 'ja' ? 'EN' : '日本語'}
      </span>
    </button>
  );
};

export default LanguageToggle;
