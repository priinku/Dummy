export interface IuserTokenType {
  userId: number;
  userName: string;
  session: string;
  exp: number;
  iat: number;
}
