import path from 'path';
import { env } from './env';
import fs from 'fs';

export const UPLOAD_ROOT = path.resolve(process.cwd(), `../${env.UPLOAD_ROOT}` || '../uploads');
export const FILE_UPLOAD_DIR = path.join(UPLOAD_ROOT, 'files');

if (!fs.existsSync(FILE_UPLOAD_DIR)) {
  fs.mkdirSync(FILE_UPLOAD_DIR, { recursive: true });
}