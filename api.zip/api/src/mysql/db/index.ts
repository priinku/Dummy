import seq from './seq.db';
import dayjs from 'dayjs';

const initDB = () =>
  new Promise(() => {
    try {
      seq.authenticate();
      console.log(`[${dayjs().format('YYYY-MM-DD HH:mm:ss')}] 🚀 データベース接続が成功しました`);
      seq.sync();
    } catch (error) {
      console.log(`[${dayjs().format('YYYY-MM-DD HH:mm:ss')}] データベース接続に失敗しました`, error);
    }

    process.on('unhandledRejection', (error) => {
      console.log(`[${dayjs().format('YYYY-MM-DD HH:mm:ss')}] データベース接続に失敗しました`, error);
    });
  });

export default initDB;
