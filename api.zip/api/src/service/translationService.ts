/**
 * Translation Service
 * Handles translation between English and Japanese
 * Uses Ollama API for LLM-based translation
 */

import axios from 'axios';

const OLLAMA_API = process.env.OLLAMA_API || 'http://localhost:11435/api/generate';
const MODEL = process.env.OLLAMA_MODEL || 'gpt-oss:120b';

interface TranslationRequest {
  text: string;
  sourceLang: 'en' | 'ja';
  targetLang: 'en' | 'ja';
}

interface TranslationResult {
  original: string;
  translated: string;
  sourceLang: 'en' | 'ja';
  targetLang: 'en' | 'ja';
  success: boolean;
  error?: string;
}

/**
 * Translate text using Ollama LLM
 */
export async function translateText(req: TranslationRequest): Promise<TranslationResult> {
  const { text, sourceLang, targetLang } = req;
  
  console.log('🌐 [Translation Service] Starting translation', {
    sourceLang,
    targetLang,
    textPreview: text.substring(0, 50),
  });
  
  if (sourceLang === targetLang) {
    console.log('ℹ️ [Translation] Source and target language same, returning original');
    return {
      original: text,
      translated: text,
      sourceLang,
      targetLang,
      success: true,
    };
  }
  
  try {
    const sourceLabel = sourceLang === 'en' ? 'English' : 'Japanese';
    const targetLabel = targetLang === 'en' ? 'English' : 'Japanese';
    
    const prompt = `Translate the following text from ${sourceLabel} to ${targetLabel}. 
Return ONLY the translated text, nothing else.

Text: ${text}

Translated:`;

    console.log('🔄 [Translation] Calling Ollama API', {
      model: MODEL,
      endpoint: OLLAMA_API,
    });
    
    const response = await axios.post(OLLAMA_API, {
      model: MODEL,
      prompt: prompt,
      stream: false,
      temperature: 0.7,
    }, {
      timeout: 30000,
    });
    
    const translatedText = response.data.response?.trim() || '';
    
    console.log('✅ [Translation] Success', {
      sourceLang,
      targetLang,
      originalLength: text.length,
      translatedLength: translatedText.length,
      translatedPreview: translatedText.substring(0, 50),
    });
    
    return {
      original: text,
      translated: translatedText,
      sourceLang,
      targetLang,
      success: true,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error('❌ [Translation] Error', {
      sourceLang,
      targetLang,
      error: errorMessage,
    });
    
    return {
      original: text,
      translated: text, // Return original if translation fails
      sourceLang,
      targetLang,
      success: false,
      error: errorMessage,
    };
  }
}

/**
 * Translate from English to Japanese
 */
export async function translateENtoJA(text: string): Promise<string> {
  const result = await translateText({
    text,
    sourceLang: 'en',
    targetLang: 'ja',
  });
  return result.translated;
}

/**
 * Translate from Japanese to English
 */
export async function translateJAtoEN(text: string): Promise<string> {
  const result = await translateText({
    text,
    sourceLang: 'ja',
    targetLang: 'en',
  });
  return result.translated;
}

/**
 * Batch translate multiple texts
 */
export async function batchTranslate(
  texts: string[],
  sourceLang: 'en' | 'ja',
  targetLang: 'en' | 'ja'
): Promise<TranslationResult[]> {
  console.log('📦 [Translation] Batch translating', {
    count: texts.length,
    sourceLang,
    targetLang,
  });
  
  const results = await Promise.all(
    texts.map(text => translateText({ text, sourceLang, targetLang }))
  );
  
  console.log('✅ [Translation] Batch complete', {
    total: texts.length,
    successful: results.filter(r => r.success).length,
    failed: results.filter(r => !r.success).length,
  });
  
  return results;
}
