/**
 * Translation utility for dual-language chat pipeline
 * Flow: user_query → translate to JP → retrieve JP → generate JP → translate back
 */

import { config } from '@config/index';
import { getNextApiUrl } from './redis';

// Language detection patterns
const japanesePattern = /[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FAF]/;
const koreanPattern = /[\uAC00-\uD7AF]/;
const chinesePattern = /[\u4E00-\u9FFF]/;

export type LanguageCode = 'ja' | 'en' | 'ko' | 'zh' | 'unknown';

/**
 * Detect the primary language of the input text
 */
export function detectLanguage(text: string): LanguageCode {
  const hasJapanese = japanesePattern.test(text);
  const hasKorean = koreanPattern.test(text);
  const hasChinese = chinesePattern.test(text);
  
  // Check for Japanese-specific characters (hiragana/katakana)
  const hasKana = /[\u3040-\u309F\u30A0-\u30FF]/.test(text);
  
  if (hasKana || (hasJapanese && !hasKorean)) {
    return 'ja';
  }
  if (hasKorean) {
    return 'ko';
  }
  if (hasChinese) {
    return 'zh';
  }
  
  // Default to English for non-CJK text
  return 'en';
}

/**
 * Get language name for prompts
 */
export function getLanguageName(code: LanguageCode): string {
  const names: Record<LanguageCode, string> = {
    ja: 'Japanese',
    en: 'English',
    ko: 'Korean',
    zh: 'Chinese',
    unknown: 'English',
  };
  return names[code];
}

/**
 * Translate text using Ollama LLM with retry logic
 */
export async function translateText(
  text: string,
  targetLang: LanguageCode,
  preserveCitations: boolean = false,
  maxRetries: number = 2
): Promise<string> {
  const url = await getNextApiUrl('ollama');
  const targetLangName = getLanguageName(targetLang);
  
  let systemPrompt = `You are a professional translator. Translate the following text to ${targetLangName}. 
Output ONLY the translation, no explanations or notes.`;

  if (preserveCitations) {
    systemPrompt += `
IMPORTANT: Keep all citation strings exactly as they are (document names, page numbers, file references like "Document: xxx", "Page: xxx", "出典:", "ページ:"). 
Do NOT translate citation markers or document names.`;
  }

  const messages = [
    { role: 'system', content: systemPrompt },
    { role: 'user', content: text },
  ];

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 60000); // 60s timeout

      const modelName = config.Models.chatModel.name;
      const apiUrl = `${url}/api/chat`;
      console.log(`[Translation] Attempt ${attempt + 1}: Calling ${apiUrl} with model: ${modelName}`);

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          stream: false,
          model: modelName,
          messages,
          options: { temperature: 0.3 },
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorText = await response.text().catch(() => 'Unable to read error response');
        console.error(`[Translation] HTTP ${response.status} error: ${errorText}`);
        throw new Error(`HTTP error: ${response.status} - ${errorText.substring(0, 200)}`);
      }

      const responseText = await response.text();
      if (!responseText || responseText.trim() === '') {
        throw new Error('Empty response from Ollama');
      }

      const data = JSON.parse(responseText);
      let content = data.message?.content?.trim();
      
      if (content) {
        // Clean any markers the LLM might have added
        content = content
          .replace(/\[EN\]\s*/gi, '')
          .replace(/\[JA\]\s*/gi, '')
          .replace(/\[\/EN\]\s*/gi, '')
          .replace(/\[\/JA\]\s*/gi, '')
          .replace(/^(English|Japanese|Translation):\s*/gim, '')
          .replace(/- Source:.*$/gm, '') // Remove source markers from translation
          .trim();
        return content;
      }
      
      throw new Error('No content in response');
    } catch (error) {
      console.error(`Translation attempt ${attempt + 1} failed:`, error);
      if (attempt === maxRetries) {
        console.error('Translation failed after all retries, returning original text');
        return text; // Return original on final failure
      }
      // Wait before retry
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }
  
  return text;
}

/**
 * Translate query to Japanese for RAG retrieval
 */
export async function translateQueryToJapanese(query: string): Promise<{ 
  originalQuery: string;
  translatedQuery: string;
  sourceLanguage: LanguageCode;
}> {
  const sourceLanguage = detectLanguage(query);
  
  if (sourceLanguage === 'ja') {
    return {
      originalQuery: query,
      translatedQuery: query,
      sourceLanguage: 'ja',
    };
  }

  const translatedQuery = await translateText(query, 'ja');
  
  return {
    originalQuery: query,
    translatedQuery,
    sourceLanguage,
  };
}

/**
 * Create dual-language response
 * Translates Japanese answer back to user's language while preserving citations
 */
export async function createDualLanguageResponse(
  japaneseAnswer: string,
  targetLanguage: LanguageCode
): Promise<{
  japanese: string;
  translated: string;
  targetLanguage: LanguageCode;
}> {
  if (targetLanguage === 'ja') {
    return {
      japanese: japaneseAnswer,
      translated: japaneseAnswer,
      targetLanguage: 'ja',
    };
  }

  const translatedAnswer = await translateText(japaneseAnswer, targetLanguage, true);

  return {
    japanese: japaneseAnswer,
    translated: translatedAnswer,
    targetLanguage,
  };
}

/**
 * Format dual-language output for storage
 * Returns a structured JSON that can be parsed by the frontend
 */
export function formatDualLanguageOutput(
  japaneseAnswer: string,
  translatedAnswer: string,
  targetLanguage: LanguageCode
): string {
  const output = {
    dualLanguage: true,
    japanese: japaneseAnswer,
    translated: translatedAnswer,
    targetLanguage,
  };
  
  return `<!--DUAL_LANG_START-->${JSON.stringify(output)}<!--DUAL_LANG_END-->`;
}

/**
 * Parse dual-language output from stored content
 */
export function parseDualLanguageOutput(content: string): {
  isDualLanguage: boolean;
  japanese?: string;
  translated?: string;
  targetLanguage?: LanguageCode;
  rawContent: string;
} {
  const dualLangMatch = content.match(/<!--DUAL_LANG_START-->(.+?)<!--DUAL_LANG_END-->/s);
  
  if (dualLangMatch) {
    try {
      const parsed = JSON.parse(dualLangMatch[1]);
      return {
        isDualLanguage: true,
        japanese: parsed.japanese,
        translated: parsed.translated,
        targetLanguage: parsed.targetLanguage,
        rawContent: content,
      };
    } catch {
      return { isDualLanguage: false, rawContent: content };
    }
  }
  
  return { isDualLanguage: false, rawContent: content };
}
